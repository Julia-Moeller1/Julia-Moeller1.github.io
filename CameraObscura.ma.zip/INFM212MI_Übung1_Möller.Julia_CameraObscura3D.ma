//Maya ASCII 2027 scene
//Name: INFM212MI_Übung1_Möller.Julia_CameraObscura3D.ma
//Last modified: Tue, Jun 30, 2026 08:16:33 AM
//Codeset: UTF-8
requires maya "2027";
requires -nodeType "materialxStack" -nodeType "MaterialXSurfaceShader" -dataType "MxDocumentStackData"
		 "LookdevXMaya" "2.0.0";
requires -nodeType "polyBoolean" "polyBoolean" "1.1";
requires -nodeType "aiOptions" -nodeType "aiAOVDriver" -nodeType "aiAOVFilter" -nodeType "aiImagerDenoiserOidn"
		 -nodeType "aiStandardSurface" "mtoa" "5.6.0";
requires "stereoCamera" "10.0";
currentUnit -l centimeter -a degree -t film;
fileInfo "application" "maya";
fileInfo "product" "Maya 2027";
fileInfo "version" "2027";
fileInfo "cutIdentifier" "202603302215-e16e754b0e";
fileInfo "osv" "Mac OS X 20.5.1";
fileInfo "UUID" "2A7A0E89-D648-E793-03E2-28B48FDBBD81";
createNode transform -s -n "persp";
	rename -uid "92117A3A-5F41-E512-636F-16AC937A549E";
	setAttr ".t" -type "double3" 0.05006836927013314 3.5575212563875978 -7.5349323888130515 ;
	setAttr ".r" -type "double3" -13.799999999998835 -178.79999999998884 0 ;
	setAttr ".rp" -type "double3" -4.4408920985006262e-16 6.9388939039072284e-18 8.8817841970012523e-16 ;
	setAttr ".rpt" -type "double3" -6.9362051404752059e-17 -1.2272419916442418e-15 -1.5277796651832333e-15 ;
createNode camera -s -n "perspShape" -p "persp";
	rename -uid "77CB1FED-7549-724F-FCC5-E3878F813A17";
	setAttr -k off ".v";
	setAttr ".rnd" no;
	setAttr ".fl" 34.999999999999986;
	setAttr ".coi" 14.147583511659736;
	setAttr ".imn" -type "string" "persp";
	setAttr ".den" -type "string" "persp_depth";
	setAttr ".man" -type "string" "persp_mask";
	setAttr ".tp" -type "double3" 8.8817841970012523e-16 -0.048871218271623995 3.465831738577521 ;
	setAttr ".hc" -type "string" "viewSet -p %camera";
createNode transform -s -n "top";
	rename -uid "2189F6DE-6444-49B7-6E2E-23BB2A3A8537";
	setAttr ".v" no;
	setAttr ".t" -type "double3" 0 1000.1 0 ;
	setAttr ".r" -type "double3" -89.999999999999986 0 0 ;
createNode camera -s -n "topShape" -p "top";
	rename -uid "52FCAD71-1E40-79A3-8884-81ABEAA541BA";
	setAttr -k off ".v" no;
	setAttr ".rnd" no;
	setAttr ".coi" 1000.1;
	setAttr ".ow" 30;
	setAttr ".imn" -type "string" "top";
	setAttr ".den" -type "string" "top_depth";
	setAttr ".man" -type "string" "top_mask";
	setAttr ".hc" -type "string" "viewSet -t %camera";
	setAttr ".o" yes;
	setAttr ".ai_translator" -type "string" "orthographic";
createNode transform -s -n "front";
	rename -uid "578DCA51-284C-F002-AD9A-C3BCDFABA05C";
	setAttr ".v" no;
	setAttr ".t" -type "double3" 0 0 1000.1 ;
createNode camera -s -n "frontShape" -p "front";
	rename -uid "0A7C66A1-5F44-4FFE-E9F9-99BA332F77CC";
	setAttr -k off ".v" no;
	setAttr ".rnd" no;
	setAttr ".coi" 1000.1;
	setAttr ".ow" 30;
	setAttr ".imn" -type "string" "front";
	setAttr ".den" -type "string" "front_depth";
	setAttr ".man" -type "string" "front_mask";
	setAttr ".hc" -type "string" "viewSet -f %camera";
	setAttr ".o" yes;
	setAttr ".ai_translator" -type "string" "orthographic";
createNode transform -s -n "side";
	rename -uid "FC556A49-AC42-347C-A021-E186508B1539";
	setAttr ".v" no;
	setAttr ".t" -type "double3" 1000.1 0 0 ;
	setAttr ".r" -type "double3" 0 89.999999999999986 0 ;
createNode camera -s -n "sideShape" -p "side";
	rename -uid "68619506-D84E-0D93-A775-A9A1E474093A";
	setAttr -k off ".v" no;
	setAttr ".rnd" no;
	setAttr ".coi" 1000.1;
	setAttr ".ow" 30;
	setAttr ".imn" -type "string" "side";
	setAttr ".den" -type "string" "side_depth";
	setAttr ".man" -type "string" "side_mask";
	setAttr ".hc" -type "string" "viewSet -s %camera";
	setAttr ".o" yes;
	setAttr ".ai_translator" -type "string" "orthographic";
createNode transform -n "nurbsCube1";
	rename -uid "78646BBA-B24E-9A05-B33F-06B62642FD77";
createNode transform -n "polySurface1";
	rename -uid "C0C766E5-CA47-E290-CF7E-828096BA0E0C";
createNode mesh -n "polySurfaceShape1" -p "polySurface1";
	rename -uid "9EEBA916-E647-82C2-8621-D5A8AD9FF596";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode transform -n "polySurface2";
	rename -uid "6A5192A0-CC4A-CC3D-6CE6-19904063C9A7";
createNode mesh -n "polySurfaceShape2" -p "polySurface2";
	rename -uid "C0D197F2-2540-1329-4E54-A0AA3B14FB27";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode transform -n "polySurface3";
	rename -uid "DBD84252-3C43-4B27-B4B4-6F8E0863ADE8";
createNode mesh -n "polySurfaceShape3" -p "polySurface3";
	rename -uid "EAB87F70-F946-D949-1647-CCA79EC14E87";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode transform -n "polySurface4";
	rename -uid "B8821699-C041-678A-A1A2-C29A4C9A34ED";
createNode mesh -n "polySurfaceShape4" -p "polySurface4";
	rename -uid "664DD7BB-E248-75D1-5427-56881DB20271";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode transform -n "polySurface5";
	rename -uid "679ED78F-2547-DFD2-513A-4599E9926594";
createNode mesh -n "polySurfaceShape5" -p "polySurface5";
	rename -uid "A9F3294E-394B-249C-5890-3F9A8E5EADAC";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode transform -n "polySurface6";
	rename -uid "0F88A3A6-FD4F-79EB-967A-B8A2A6785603";
createNode mesh -n "polySurfaceShape6" -p "polySurface6";
	rename -uid "69B37F45-9D4F-90FE-CCDC-DD9C4B97D3FD";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode transform -n "pCube1";
	rename -uid "8FA48BB5-0A42-5A99-8F14-A89DDE68909E";
	setAttr ".v" no;
	setAttr ".ovrgbf" yes;
	setAttr ".ovrgb" -type "float3" 0.85882354 0.58039218 0.33725491 ;
createNode mesh -n "pCubeShape1" -p "pCube1";
	rename -uid "15DBAFE6-E547-71D0-A212-6ABB528F9F13";
	setAttr -k off ".v";
	setAttr -s 2 ".iog[0].og";
	setAttr ".ovrgbf" yes;
	setAttr ".ovrgb" -type "float3" 0.89969999 0.1575 0.1946 ;
	setAttr ".ovca" 0.30000001192092896;
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode transform -n "pCylinder1";
	rename -uid "A7684769-9646-8D7A-0EC0-E7844742F030";
	setAttr ".v" no;
	setAttr ".ovrgbf" yes;
	setAttr ".ovrgb" -type "float3" 0.74117649 0.74117649 0.74117649 ;
	setAttr ".t" -type "double3" 0 0 0.49388283874988892 ;
	setAttr ".s" -type "double3" 0.04 0.5 0.04 ;
	setAttr ".ra" -type "double3" 90 0 0 ;
createNode mesh -n "pCylinderShape1" -p "pCylinder1";
	rename -uid "F50A3666-A341-4A79-82C9-9FA84D643891";
	setAttr -k off ".v";
	setAttr -s 2 ".iog[0].og";
	setAttr ".ovrgbf" yes;
	setAttr ".ovrgb" -type "float3" 0.89969999 0.1575 0.1946 ;
	setAttr ".ovca" 0.30000001192092896;
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode transform -n "polySurface7";
	rename -uid "1F9EEEA1-D645-2793-7DDD-3E9A09625E83";
	setAttr ".t" -type "double3" -0.0037720094046393982 -3.7747582837255322e-15 0.01532430236340776 ;
	setAttr -av ".tx";
	setAttr -av ".ty";
	setAttr -av ".tz";
createNode mesh -n "polySurfaceShape7" -p "polySurface7";
	rename -uid "D594FE20-984E-4066-B1D1-32A66DC1F1F6";
	setAttr -k off ".v";
	setAttr -s 4 ".iog[0].og";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.50000001490116119 0.125 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 22 ".pt";
	setAttr ".pt[2]" -type "float3" -2.4614393e-09 0.0090091089 -2.6077032e-08 ;
	setAttr ".pt[3]" -type "float3" 0.0023940457 0.0085682543 -2.6077032e-08 ;
	setAttr ".pt[4]" -type "float3" 0.0045537702 0.0072884224 -2.6077032e-08 ;
	setAttr ".pt[5]" -type "float3" 0.0062676682 0.005295522 -2.6077032e-08 ;
	setAttr ".pt[6]" -type "float3" 0.0073681413 0.002783895 -2.6077032e-08 ;
	setAttr ".pt[7]" -type "float3" 0.0077473465 4.9229079e-08 -2.6077032e-08 ;
	setAttr ".pt[14]" -type "float3" -0.0077473577 4.9229079e-08 -2.6077032e-08 ;
	setAttr ".pt[15]" -type "float3" -0.0073681371 0.0027838992 -2.6077032e-08 ;
	setAttr ".pt[16]" -type "float3" -0.0062676989 0.0052955239 -2.6077032e-08 ;
	setAttr ".pt[17]" -type "float3" -0.0045537669 0.0072884457 -2.6077032e-08 ;
	setAttr ".pt[18]" -type "float3" -0.0023940618 0.0085682515 -2.6077032e-08 ;
	setAttr ".pt[19]" -type "float3" 0.0073681413 -0.0027839711 -2.6077032e-08 ;
	setAttr ".pt[20]" -type "float3" 0.0062676682 -0.0052952874 -2.6077032e-08 ;
	setAttr ".pt[21]" -type "float3" 0.0045537679 -0.0072885286 -2.6077032e-08 ;
	setAttr ".pt[22]" -type "float3" 0.002394048 -0.0085682152 -2.6077032e-08 ;
	setAttr ".pt[23]" -type "float3" -2.576876e-09 -0.0090091536 -2.6077032e-08 ;
	setAttr ".pt[29]" -type "float3" 4.4408921e-15 4.0978193e-08 2.6077032e-08 ;
	setAttr ".pt[32]" -type "float3" -0.0023940608 -0.008568218 -2.6077032e-08 ;
	setAttr ".pt[33]" -type "float3" -0.0045537697 -0.0072885389 -2.6077032e-08 ;
	setAttr ".pt[34]" -type "float3" -0.0062676887 -0.005295373 -2.6077032e-08 ;
	setAttr ".pt[35]" -type "float3" -0.0073681511 -0.0027838252 -2.6077032e-08 ;
	setAttr ".pt[40]" -type "float3" -7.4505806e-09 0 0 ;
createNode transform -n "directionalLight1";
	rename -uid "8DE3CCDA-A740-F0C1-F017-3BA1E0696B8B";
	setAttr ".t" -type "double3" 2.2530631889765642 2.5046709431357215 2.6124648142189821 ;
	setAttr ".r" -type "double3" 204.03010630689175 -21.165534757967379 -8.7061255710489256 ;
createNode directionalLight -n "directionalLightShape1" -p "directionalLight1";
	rename -uid "94E79454-B54E-70F3-D450-238C83EC6097";
	setAttr -k off ".v";
	setAttr ".in" 10;
	setAttr ".ai_exposure" 10;
createNode transform -n "directionalLight2";
	rename -uid "528E5885-294A-0C76-5BDC-D1B2D5723A8C";
	setAttr ".t" -type "double3" -1.1630981448844491 2.1963263698922773 2.710523717637717 ;
	setAttr ".r" -type "double3" 152.12583321870883 -17.67762916296012 -170.56983620957902 ;
createNode directionalLight -n "directionalLightShape2" -p "directionalLight2";
	rename -uid "B71E7B0F-A446-3EFB-82F7-9F823BCB7B46";
	setAttr -k off ".v";
	setAttr ".in" 10;
	setAttr ".ai_exposure" 10;
createNode transform -n "directionalLight3";
	rename -uid "9CBD7639-9C42-B896-B2A5-6EBF8A0968AE";
	setAttr ".t" -type "double3" 0.1577883217756928 3.8177064640653313 5.6189781142226787 ;
	setAttr ".r" -type "double3" -130.61285428874652 60.080256176313029 -55.051922542284572 ;
createNode directionalLight -n "directionalLightShape3" -p "directionalLight3";
	rename -uid "EEE85018-0E43-7DF5-7600-03BB2F61C691";
	setAttr -k off ".v";
	setAttr ".in" 10;
	setAttr ".ai_exposure" 10;
	setAttr ".ai_normalize" no;
createNode transform -n "materialXStack1";
	rename -uid "95110BF3-CE4D-9E8E-6964-2C83CD2CB8A4";
createNode materialxStack -n "materialXStackShape1" -p "materialXStack1";
	rename -uid "CBC7A600-C242-4D1E-81BC-E1B3882B1152";
	setAttr -k off ".v";
	setAttr ".docs" -type "string" (
		"[\n    {\n        \"document\": \"AAABgHicdVDLCoMwELz7Fct+QK30VPBBwWOxUD9AgomtoElIYrF/39g0RQNeFnZndmZ202IeB3gxpXvBM0wORyzyKB2JYaonw7yGTmeEVgxCaUlalqEtun1gHgGk2hBOiaKNnlRnAeBktJRwnCCYt1wA1+snoUwhcEEZZV2Gl3t1u5ZNVTbhKkLsnFzrE/6Mas+uAyPPW3ks4luR7w1Wu+dyMj76NuFu7N1DXdw4sLLPjf/fzaMP3D+Faw==\",\n        \"name\": \"document1\"\n    },\n    {\n        \"document\": \"AAAB13icdVFbC4IwFH73VxzOc3ihlwIvBD2GQf0AOblZgk7ZVOzft7RFjoQxdi77LueEyVhXMHCpykZEGLg+JrET1tRxWVI1/pa2e4S8qRqpWsp5hPpS+R1jByBUHQlGkmWql4UugKBat9jpAKF7tu/CHKsHMS4RRMM440WEh0t6Ph2z9JjZXycezVSKtu8+8DdSPJskGdwp2CIMVPU6DDbg6+PuAl8nvUmqZyPPBua3Mf4huJrWq6Xf9P1If2tegvyTbBlfncbq/IyJJZXemfddWuy8AMp7oBw=\",\n        \"name\": \"document2\"\n    },\n    {\n        \"document\": \"AAACGnicdVHBasMwDL3nK4zOI4lxt1JIUgY9lg7WDwha7GwBxw62U9q/n5vEpTXtxUiW9J7eU7E995KchLGdViXQNIdtlRQ9OmE6lOf7EtsAabTUxg7YiBL8Y5tfqBJCCutQcTS8tqNpfYEo7H1L/E2BuMtwLcy5/UMuDBClueCiLeHz+/C139WHXR2PTjyeqVPD6Bb4H7SinlYKuFPCgJxQjj6lbyRPV2v2sZminK2AZE+AeuFQKmFtwGmlRneDydM1Ze+ULcNFFi83ezDHwbsF+hhaj5EFoe9O/VX2I8gz1ZF3Lw19eYIg4pHKnz273b1K/gHh6LOt\",\n"
		+ "        \"name\": \"document3\"\n    },\n    {\n        \"document\": \"AAACGnicdVHLasMwELz7K5Y9Fz+w6yZgOxRyLCk0H2C2ttwaZMlIckj/vopthUQkF6HV7sxoZovdeeBwYkr3UpSYhDHuqqAYyDDVEz/fttItQiO5VHqkhpVoD938YBUAFNqQaEm1tZ5UZxsgaLAj/nOCYP7GS2Op9S+1TCEI2bKWdSW+fx0+P/b1YV/70FnHKvVinMxKPzBDXDCtHW3HJRmEE/HJVnG4ybNN/ooQPQB/k2b17Meh5yK9wpMXiMPsLc238y1Os5WoiPzPLRksd5fdKnN0o0cvAjd34/5i+57kkWsvu6eBPl2BM3EvZdceXfdeBf9Fn7O+\",\n        \"name\": \"document4\"\n    },\n    {\n        \"document\": \"AAACH3icdVHBboMwDL3zFZHPE4RStlYCqkk9Tp20fgDySNiQQoKSUHV/vxRI1UZtDpEd+70XPxe7cy/IiWvTKVlCGlPYVVHRo+W6Q3G+LWVbII0SSpsBG16Cu0zzA1VESGEsSoaa1WbUrSsQib1rCZ9TIPZvuBTm3Pwi4xqIVIwz3pbw/nX4/NjXh30dQicdp9TJYbQLfc8tCsmN8bStUGiBnFCMLqPxJl/TfA0keQD+RsPraR6PnpLsCk9fCI3zzWr1OkWUvlF3soWtSMIfzkbMsTdw0Tr61mPgg++7seAy+z3Jo9EDA5+6+nQPfoh7Kbf75Lr8KvoH/720oA==\",\n        \"name\": \"document5\"\n    },\n    {\n        \"document\": \"AAACH3icdVHBboMwDL3zFVbOEwTQRicB1aQep05aPwB5JHRIIUFJqLq/XwqkaqM2h8iO/d6Ln8vteRBw4tr0SlYkjSnZ1lE5oOW6R3G+LeXvBFollDYjtrwi7jLtkdQRQGksSoaaNWbSnSuAxMG1hM8pAfs3XgpLbn6RcU1AKsYZ7yry8b3/+tw1+10TQmcdp9TLcbIr/cAtCsmN8bSdUGgJnFBMLqPxJitoVhBIHoB/0PBmnsej5yS/wtMXoPHrJsve5ojSgrqTr2xlEv5wMWKJvYGr1sG3HgIffN+NBZfZ70kejR4Y+NTVp3vwQ9xLud0n1+XX0T//t7Sg\",\n"
		+ "        \"name\": \"document6\"\n    },\n    {\n        \"document\": \"AAAB5XicdVHLCsIwELz3K5Y9i20UkUIfCB5FQT+grE3UQpuWpBX9e2NqRINewr4yszOb5LemhqtQumplimwaYZ4FSUO9UBXVt8/WPEYo27pVuqNSpGgeXZ4xCwAS3ZPkpHihB3UyDZDUmBG/zBD6e/dsjLm+EBcKQbZccHFKcbXf7jbrYrsu/K+WxzBVshv6F/yRtCjsSg7XJnOEK9WDSaNpxBYsnrEJ2DCKZzZaLhFCu3jo84xyxtjZ8KI7uNGDp8bNfQh5KvgG+SXAs+GvN3/ddCK+qcwFw/cJs+ABtmWi3Q==\",\n        \"name\": \"document7\"\n    },\n    {\n        \"document\": \"AAAB0nicdZHNCoMwDMfvPkXIeczJTgM/GHgcG2wPIJmtm1CrtCru7Vd1HVo2KKVpkn9+ScJkqAT0XOmylhEG2x0msRdW1HJVkhiWrv0BIa9FrXRDOY/QXDp/YOwBhLolyUixTHeqMA6QVJkQ9ztAaF/N6Jht/STGFYKsGWe8iPB4PV9OaXZOMzd1qmMqlbLp2o/8nTTPJiSrOxl7hJ5EZ8xgA+NB8CdK3xWd2ee37fmjfbOhNwfdxi2oR9y1yC9ap+e/g/g7OtvEupRZl//dV+y9AV89nyQ=\",\n        \"name\": \"document8\"\n    },\n    {\n        \"document\": \"AAAB43icdVHbCoJAEH33K4Z5Di+VWKBG0GMU1AfI5G4l6Cq7GvX3rdpGLfWyzG3nXCZe3asSblyqohYJBq6Pq9SJK2q5LKi8f7ZmS4S8LmupGsp5gvpR+QVTByBWLQlGkmWqk2fdAEGVHrHLAUL7aPrGmKsrMS4RRM044+cE14fdfrvJdpvM/jrgaKRCNF37Wn8ixbOBktk7JDOEG5WdTn3XD6NpNAHfnS4X0SLso3kQIngDbc9GGcWMsTHhBXY0o0dLi5n7kNHz/17yi75lwl9n/nppRHxD6ft57wOmzhPPA6KR\",\n"
		+ "        \"name\": \"document9\"\n    },\n    {\n        \"document\": \"AAAB3XicdVHdCoIwFL73KQ7nOlIxisAfgi7DoB5ATm6VoFM2lXr71mxRo27G+dv3c06c3ZoaRi5V1YoEw3mAWerFDfVcVlTfPlvRGqFs61aqjkqeoH5UecHUA4hVT4KRZIUa5Fk3QFCjR9xyiNDfu2djytWVGJcIomWc8XOCm0O+322LfFu4Xw2PZqpEN/Qv+BMpXhhJFtckEcJI9aDTcAbBfLGKlmsTBdECwTeCfRd/sjHF1v6L5mhHj44LO/dh4Kn8G+SXcMf+35383aI18U2lL+e/T5d6D8WeoVM=\",\n        \"name\": \"document10\"\n    },\n    {\n        \"document\": \"AAAB3XicdVHdCoIwFL73KQ7nOlIxisAfgi7DoB5ATm6VoFM2lXr71mxRo27G+dv3c06c3ZoaRi5V1YoEw3mAWerFDfVcVlTfPlvRGqFs61aqjkqeoH5UecHUA4hVT4KRZIUa5Fk3QFCjR9xyiNDfu2djytWVGJcIomWc8XOCm0O+322LfFu4Xw2PZqpEN/Qv+BMpXhhJFtckEcJI9aDTcAbBfLGKlmsTBdECwTeCfRd/sjHF1v6L5mhHj44LO/dh4Kn8G+SXcMf+35383aI18U2lL+e/T5d6D8WeoVM=\",\n        \"name\": \"document11\"\n    },\n    {\n        \"document\": \"AAAB3XicdVHdCoIwFL73KQ7nOlIxisAfgi7DoB5ATm6VoFM2lXr71mxRo27G+dv3c06c3ZoaRi5V1YoEw3mAWerFDfVcVlTfPlvRGqFs61aqjkqeoH5UecHUA4hVT4KRZIUa5Fk3QFCjR9xyiNDfu2djytWVGJcIomWc8XOCm0O+322LfFu4Xw2PZqpEN/Qv+BMpXhhJFtckEcJI9aDTcAbBfLGKlmsTBdECwTeCfRd/sjHF1v6L5mhHj44LO/dh4Kn8G+SXcMf+35383aI18U2lL+e/T5d6D8WeoVM=\",\n"
		+ "        \"name\": \"document12\"\n    },\n    {\n        \"document\": \"AAAB3XicdVHdCoIwFL73KQ7nOlIxisAfgi7DoB5ATm6VoFM2lXr71mxRo27G+dv3c06c3ZoaRi5V1YoEw3mAWerFDfVcVlTfPlvRGqFs61aqjkqeoH5UecHUA4hVT4KRZIUa5Fk3QFCjR9xyiNDfu2djytWVGJcIomWc8XOCm0O+322LfFu4Xw2PZqpEN/Qv+BMpXhhJFtckEcJI9aDTcAbBfLGKlmsTBdECwTeCfRd/sjHF1v6L5mhHj44LO/dh4Kn8G+SXcMf+35383aI18U2lL+e/T5d6D8WeoVM=\",\n        \"name\": \"document13\"\n    },\n    {\n        \"document\": \"AAABgHicdVDLCoMwELz7Fct+QK30VPBBwWOxUD9AgomtoElIYrF/39g0RQNeFnZndmZ202IeB3gxpXvBM0wORyzyKB2JYaonw7yGTmeEVgxCaUlalqEtun1gHgGk2hBOiaKNnlRnAeBktJRwnCCYt1wA1+snoUwhcEEZZV2Gl3t1u5ZNVTbhKkLsnFzrE/6Mas+uAyPPW3ks4luR7w1Wu+dyMj76NuFu7N1DXdw4sLLPjf/fzaMP3D+Faw==\",\n        \"name\": \"document14\"\n    },\n    {\n        \"document\": \"AAAB0nicdZHNCoMwDMfvPkXIeczJTgM/GHgcG2wPIJmtm1CrtCru7Vd1HVo2KKVpkn9+ScJkqAT0XOmylhEG2x0msRdW1HJVkhiWrv0BIa9FrXRDOY/QXDp/YOwBhLolyUixTHeqMA6QVJkQ9ztAaF/N6Jht/STGFYKsGWe8iPB4PV9OaXZOMzd1qmMqlbLp2o/8nTTPJiSrOxl7hJ5EZ8xgA+NB8CdK3xWd2ee37fmjfbOhNwfdxi2oR9y1yC9ap+e/g/g7OtvEupRZl//dV+y9AV89nyQ=\",\n"
		+ "        \"name\": \"document15\"\n    },\n    {\n        \"document\": \"AAAB0nicdZHNCoMwDMfvPkXIeczJTgM/GHgcG2wPIJmtm1CrtCru7Vd1HVo2KKVpkn9+ScJkqAT0XOmylhEG2x0msRdW1HJVkhiWrv0BIa9FrXRDOY/QXDp/YOwBhLolyUixTHeqMA6QVJkQ9ztAaF/N6Jht/STGFYKsGWe8iPB4PV9OaXZOMzd1qmMqlbLp2o/8nTTPJiSrOxl7hJ5EZ8xgA+NB8CdK3xWd2ee37fmjfbOhNwfdxi2oR9y1yC9ap+e/g/g7OtvEupRZl//dV+y9AV89nyQ=\",\n        \"name\": \"document16\"\n    },\n    {\n        \"document\": \"AAACXXicpZLNasMwDMfveQqh81ja9RRIUgo9jg7WBzCa7WwBxw7+KN3bz/lwaUJ7GhhjWfJP1l8q99dOwUVa1xpd4fZ1g/s6Kzvy0rakrveuXYHAjTLW9cRlhXFz/BvrDKB0nrQgK5gLtokO0NTFkPX1FsH/9oNjst0PCWkRtBFSyKbCw+fp4/3ITke2fjrmiZla3Qef8L3kQZFl47cSezR2CBdSIZqbFxgWQv6IEL5mPrMk2uD+CXGclEyMRhnyN0TUtngrZkKZr+ubZJzOSf6Zf06h55WKKe5OwEG5JeShcEv5n/bkaRdTEctUcXLy2+jU2R83Msso\",\n        \"name\": \"document17\"\n    },\n    {\n        \"document\": \"AAAB2HicdVFLC4JAEL77K4Y5RxpeCnwQdAyD+gEyuVsJusquiv371seGLnUZdh77PWaCuC8L6LhUeSVC3G09jCMnKKnhMqeiX7b8A0JWFZVUNWU8RB1U9sTIAQhUQ4KRZKlq5UM3QFCpR+zyDqF510NjytWLGJcIomKc8UeIx2tyOZ/S5JTaX0cezZSLum1m+Dspno6SDO6Y+AgdFa1Ove1+AyYguKNW14aeHExv43xmuJnRm2XAzC20D6LXIL80W87/ruPvAo2JNZU+mvu9WuR8AEyYoFM=\",\n"
		+ "        \"name\": \"document18\"\n    },\n    {\n        \"document\": \"AAAB0nicdZHNCoMwDMfvPkXIeczJTgM/GHgcG2wPIJmtm1CrtCru7Vd1HVo2KKVpkn9+ScJkqAT0XOmylhEG2x0msRdW1HJVkhiWrv0BIa9FrXRDOY/QXDp/YOwBhLolyUixTHeqMA6QVJkQ9ztAaF/N6Jht/STGFYKsGWe8iPB4PV9OaXZOMzd1qmMqlbLp2o/8nTTPJiSrOxl7hJ5EZ8xgA+NB8CdK3xWd2ee37fmjfbOhNwfdxi2oR9y1yC9ap+e/g/g7OtvEupRZl//dV+y9AV89nyQ=\",\n        \"name\": \"document19\"\n    },\n    {\n        \"document\": \"AAAB2XicdVHdCoIwFL73KQ7nOtLoKvCHwMsoqAeQk5s10Cmbi3r7prbIkTDGzr6z7+cszp5NDQ+utGhlgpt1hFkaxA31XAmqn7/QdodQtnWrdEclT9BuurxhGgDEuifJSLFCG1VZACQ1tsW/3iD0r24AplrfiXGFIFvGGa8S3J+Pp0NeHPPCfzrqWCUhO9M7enP9oIUiJox29KPNLcKDamPLaAXDQghHs6HPPUWYzi76R+LiWi9eAtf3Y35wPSf5b3oWfXEeixN0IeZS9tfC77elwRtrxqIi\",\n        \"name\": \"document20\"\n    },\n    {\n        \"document\": \"AAACt3ichVLbasMwDH3PVwg/l1zIylpIUgZ9HB2sHxC02FkDjhMsp3R/P+fi0oaEgjGWpXOO5aPkcKslXIWmqlEpi/yQHTIvqdEIXaG8PabiPYOikY2mFguRMrtR8csyDyAhg4qj5jl1urQJUFjbkvl1xMD8tX1ijOmCXGgGquGCizJlH9+nr89jfjrmc+igY5Uq1XZmojcaFdUV9S/MuWjNxfGXskHD4Iqys1HIIFiAU/czkedDXw48BPEdHW2gXy85NPKqoxWS0A/f9tEujDewdHxJTgVKsdxd7L9H2912okiC+c+NBo1nZ+wkcHal55k/ru7Bmt6TZ5IlS2bGrrq9Oh+uiWcpO5PBfSgz7x/fCuXG\",\n"
		+ "        \"name\": \"document21\"\n    },\n    {\n        \"document\": \"AAABgHicdVDLCoMwELz7Fct+QK30VPBBwWOxUD9AgomtoElIYrF/39g0RQNeFnZndmZ202IeB3gxpXvBM0wORyzyKB2JYaonw7yGTmeEVgxCaUlalqEtun1gHgGk2hBOiaKNnlRnAeBktJRwnCCYt1wA1+snoUwhcEEZZV2Gl3t1u5ZNVTbhKkLsnFzrE/6Mas+uAyPPW3ks4luR7w1Wu+dyMj76NuFu7N1DXdw4sLLPjf/fzaMP3D+Faw==\",\n        \"name\": \"document22\"\n    }\n]\n");
createNode transform -n "RenderCamera";
	rename -uid "0B85058C-D841-B902-FDAE-31BB2685BB45";
	setAttr ".t" -type "double3" 0 0 0.25363947233724282 ;
createNode camera -n "RenderCameraShape" -p "RenderCamera";
	rename -uid "16408B5C-8A48-4437-42D3-49B1DC3A037F";
	setAttr -k off ".v";
	setAttr ".cap" -type "double2" 1.41732 0.94488 ;
	setAttr ".ff" 0;
	setAttr ".coi" 4.7981735496915423;
	setAttr ".ow" 30;
	setAttr ".imn" -type "string" "camera1";
	setAttr ".den" -type "string" "camera1_depth";
	setAttr ".man" -type "string" "camera1_mask";
	setAttr ".ai_exposure" 1;
createNode transform -n "group";
	rename -uid "0E806517-CE40-26C6-C004-468A856D0CD6";
	setAttr ".rp" -type "double3" -0.075943857961454975 0.25725986062195583 0.025667107766365493 ;
	setAttr ".sp" -type "double3" -0.075943857961454975 0.25725986062195583 0.025667107766365493 ;
createNode transform -n "group1";
	rename -uid "F97FCF04-6441-B999-7E35-B1B3E56EF515";
	setAttr ".rp" -type "double3" 0 0 2.9686726315481273 ;
	setAttr ".sp" -type "double3" 0 0 2.9686726315481273 ;
createNode transform -n "pasted__materialXStack1" -p "group1";
	rename -uid "E8DC59B1-E94B-7A4D-5A85-22A5C1B7EAA0";
createNode materialxStack -n "pasted__materialXStackShape1" -p "pasted__materialXStack1";
	rename -uid "B3CE8446-F64D-B450-C457-03B1EA909B47";
	setAttr -k off ".v";
	setAttr ".docs" -type "string" (
		"[\n    {\n        \"document\": \"AAABgHicdVDLCoMwELz7Fct+QK30VPBBwWOxUD9AgomtoElIYrF/39g0RQNeFnZndmZ202IeB3gxpXvBM0wORyzyKB2JYaonw7yGTmeEVgxCaUlalqEtun1gHgGk2hBOiaKNnlRnAeBktJRwnCCYt1wA1+snoUwhcEEZZV2Gl3t1u5ZNVTbhKkLsnFzrE/6Mas+uAyPPW3ks4luR7w1Wu+dyMj76NuFu7N1DXdw4sLLPjf/fzaMP3D+Faw==\",\n        \"name\": \"document1\"\n    },\n    {\n        \"document\": \"AAAB13icdVFbC4IwFH73VxzOc3ihlwIvBD2GQf0AOblZgk7ZVOzft7RFjoQxdi77LueEyVhXMHCpykZEGLg+JrET1tRxWVI1/pa2e4S8qRqpWsp5hPpS+R1jByBUHQlGkmWql4UugKBat9jpAKF7tu/CHKsHMS4RRMM440WEh0t6Ph2z9JjZXycezVSKtu8+8DdSPJskGdwp2CIMVPU6DDbg6+PuAl8nvUmqZyPPBua3Mf4huJrWq6Xf9P1If2tegvyTbBlfncbq/IyJJZXemfddWuy8AMp7oBw=\",\n        \"name\": \"document2\"\n    },\n    {\n        \"document\": \"AAACGnicdVHBasMwDL3nK4zOI4lxt1JIUgY9lg7WDwha7GwBxw62U9q/n5vEpTXtxUiW9J7eU7E995KchLGdViXQNIdtlRQ9OmE6lOf7EtsAabTUxg7YiBL8Y5tfqBJCCutQcTS8tqNpfYEo7H1L/E2BuMtwLcy5/UMuDBClueCiLeHz+/C139WHXR2PTjyeqVPD6Bb4H7SinlYKuFPCgJxQjj6lbyRPV2v2sZminK2AZE+AeuFQKmFtwGmlRneDydM1Ze+ULcNFFi83ezDHwbsF+hhaj5EFoe9O/VX2I8gz1ZF3Lw19eYIg4pHKnz273b1K/gHh6LOt\",\n"
		+ "        \"name\": \"document3\"\n    },\n    {\n        \"document\": \"AAACGnicdVHLasMwELz7K5Y9Fz+w6yZgOxRyLCk0H2C2ttwaZMlIckj/vopthUQkF6HV7sxoZovdeeBwYkr3UpSYhDHuqqAYyDDVEz/fttItQiO5VHqkhpVoD938YBUAFNqQaEm1tZ5UZxsgaLAj/nOCYP7GS2Op9S+1TCEI2bKWdSW+fx0+P/b1YV/70FnHKvVinMxKPzBDXDCtHW3HJRmEE/HJVnG4ybNN/ooQPQB/k2b17Meh5yK9wpMXiMPsLc238y1Os5WoiPzPLRksd5fdKnN0o0cvAjd34/5i+57kkWsvu6eBPl2BM3EvZdceXfdeBf9Fn7O+\",\n        \"name\": \"document4\"\n    },\n    {\n        \"document\": \"AAACH3icdVHBboMwDL3zFZHPE4RStlYCqkk9Tp20fgDySNiQQoKSUHV/vxRI1UZtDpEd+70XPxe7cy/IiWvTKVlCGlPYVVHRo+W6Q3G+LWVbII0SSpsBG16Cu0zzA1VESGEsSoaa1WbUrSsQib1rCZ9TIPZvuBTm3Pwi4xqIVIwz3pbw/nX4/NjXh30dQicdp9TJYbQLfc8tCsmN8bStUGiBnFCMLqPxJl/TfA0keQD+RsPraR6PnpLsCk9fCI3zzWr1OkWUvlF3soWtSMIfzkbMsTdw0Tr61mPgg++7seAy+z3Jo9EDA5+6+nQPfoh7Kbf75Lr8KvoH/720oA==\",\n        \"name\": \"document5\"\n    },\n    {\n        \"document\": \"AAACH3icdVHBboMwDL3zFVbOEwTQRicB1aQep05aPwB5JHRIIUFJqLq/XwqkaqM2h8iO/d6Ln8vteRBw4tr0SlYkjSnZ1lE5oOW6R3G+LeXvBFollDYjtrwi7jLtkdQRQGksSoaaNWbSnSuAxMG1hM8pAfs3XgpLbn6RcU1AKsYZ7yry8b3/+tw1+10TQmcdp9TLcbIr/cAtCsmN8bSdUGgJnFBMLqPxJitoVhBIHoB/0PBmnsej5yS/wtMXoPHrJsve5ojSgrqTr2xlEv5wMWKJvYGr1sG3HgIffN+NBZfZ70kejR4Y+NTVp3vwQ9xLud0n1+XX0T//t7Sg\",\n"
		+ "        \"name\": \"document6\"\n    },\n    {\n        \"document\": \"AAAB5XicdVHLCsIwELz3K5Y9i20UkUIfCB5FQT+grE3UQpuWpBX9e2NqRINewr4yszOb5LemhqtQumplimwaYZ4FSUO9UBXVt8/WPEYo27pVuqNSpGgeXZ4xCwAS3ZPkpHihB3UyDZDUmBG/zBD6e/dsjLm+EBcKQbZccHFKcbXf7jbrYrsu/K+WxzBVshv6F/yRtCjsSg7XJnOEK9WDSaNpxBYsnrEJ2DCKZzZaLhFCu3jo84xyxtjZ8KI7uNGDp8bNfQh5KvgG+SXAs+GvN3/ddCK+qcwFw/cJs+ABtmWi3Q==\",\n        \"name\": \"document7\"\n    },\n    {\n        \"document\": \"AAAB0nicdZHNCoMwDMfvPkXIeczJTgM/GHgcG2wPIJmtm1CrtCru7Vd1HVo2KKVpkn9+ScJkqAT0XOmylhEG2x0msRdW1HJVkhiWrv0BIa9FrXRDOY/QXDp/YOwBhLolyUixTHeqMA6QVJkQ9ztAaF/N6Jht/STGFYKsGWe8iPB4PV9OaXZOMzd1qmMqlbLp2o/8nTTPJiSrOxl7hJ5EZ8xgA+NB8CdK3xWd2ee37fmjfbOhNwfdxi2oR9y1yC9ap+e/g/g7OtvEupRZl//dV+y9AV89nyQ=\",\n        \"name\": \"document8\"\n    },\n    {\n        \"document\": \"AAAB43icdVHbCoJAEH33K4Z5Di+VWKBG0GMU1AfI5G4l6Cq7GvX3rdpGLfWyzG3nXCZe3asSblyqohYJBq6Pq9SJK2q5LKi8f7ZmS4S8LmupGsp5gvpR+QVTByBWLQlGkmWqk2fdAEGVHrHLAUL7aPrGmKsrMS4RRM044+cE14fdfrvJdpvM/jrgaKRCNF37Wn8ixbOBktk7JDOEG5WdTn3XD6NpNAHfnS4X0SLso3kQIngDbc9GGcWMsTHhBXY0o0dLi5n7kNHz/17yi75lwl9n/nppRHxD6ft57wOmzhPPA6KR\",\n"
		+ "        \"name\": \"document9\"\n    },\n    {\n        \"document\": \"AAAB3XicdVHdCoIwFL73KQ7nOlIxisAfgi7DoB5ATm6VoFM2lXr71mxRo27G+dv3c06c3ZoaRi5V1YoEw3mAWerFDfVcVlTfPlvRGqFs61aqjkqeoH5UecHUA4hVT4KRZIUa5Fk3QFCjR9xyiNDfu2djytWVGJcIomWc8XOCm0O+322LfFu4Xw2PZqpEN/Qv+BMpXhhJFtckEcJI9aDTcAbBfLGKlmsTBdECwTeCfRd/sjHF1v6L5mhHj44LO/dh4Kn8G+SXcMf+35383aI18U2lL+e/T5d6D8WeoVM=\",\n        \"name\": \"document10\"\n    },\n    {\n        \"document\": \"AAAB3XicdVHdCoIwFL73KQ7nOlIxisAfgi7DoB5ATm6VoFM2lXr71mxRo27G+dv3c06c3ZoaRi5V1YoEw3mAWerFDfVcVlTfPlvRGqFs61aqjkqeoH5UecHUA4hVT4KRZIUa5Fk3QFCjR9xyiNDfu2djytWVGJcIomWc8XOCm0O+322LfFu4Xw2PZqpEN/Qv+BMpXhhJFtckEcJI9aDTcAbBfLGKlmsTBdECwTeCfRd/sjHF1v6L5mhHj44LO/dh4Kn8G+SXcMf+35383aI18U2lL+e/T5d6D8WeoVM=\",\n        \"name\": \"document11\"\n    },\n    {\n        \"document\": \"AAAB3XicdVHdCoIwFL73KQ7nOlIxisAfgi7DoB5ATm6VoFM2lXr71mxRo27G+dv3c06c3ZoaRi5V1YoEw3mAWerFDfVcVlTfPlvRGqFs61aqjkqeoH5UecHUA4hVT4KRZIUa5Fk3QFCjR9xyiNDfu2djytWVGJcIomWc8XOCm0O+322LfFu4Xw2PZqpEN/Qv+BMpXhhJFtckEcJI9aDTcAbBfLGKlmsTBdECwTeCfRd/sjHF1v6L5mhHj44LO/dh4Kn8G+SXcMf+35383aI18U2lL+e/T5d6D8WeoVM=\",\n"
		+ "        \"name\": \"document12\"\n    },\n    {\n        \"document\": \"AAAB3XicdVHdCoIwFL73KQ7nOlIxisAfgi7DoB5ATm6VoFM2lXr71mxRo27G+dv3c06c3ZoaRi5V1YoEw3mAWerFDfVcVlTfPlvRGqFs61aqjkqeoH5UecHUA4hVT4KRZIUa5Fk3QFCjR9xyiNDfu2djytWVGJcIomWc8XOCm0O+322LfFu4Xw2PZqpEN/Qv+BMpXhhJFtckEcJI9aDTcAbBfLGKlmsTBdECwTeCfRd/sjHF1v6L5mhHj44LO/dh4Kn8G+SXcMf+35383aI18U2lL+e/T5d6D8WeoVM=\",\n        \"name\": \"document13\"\n    },\n    {\n        \"document\": \"AAABgHicdVDLCoMwELz7Fct+QK30VPBBwWOxUD9AgomtoElIYrF/39g0RQNeFnZndmZ202IeB3gxpXvBM0wORyzyKB2JYaonw7yGTmeEVgxCaUlalqEtun1gHgGk2hBOiaKNnlRnAeBktJRwnCCYt1wA1+snoUwhcEEZZV2Gl3t1u5ZNVTbhKkLsnFzrE/6Mas+uAyPPW3ks4luR7w1Wu+dyMj76NuFu7N1DXdw4sLLPjf/fzaMP3D+Faw==\",\n        \"name\": \"document14\"\n    },\n    {\n        \"document\": \"AAAB0nicdZHNCoMwDMfvPkXIeczJTgM/GHgcG2wPIJmtm1CrtCru7Vd1HVo2KKVpkn9+ScJkqAT0XOmylhEG2x0msRdW1HJVkhiWrv0BIa9FrXRDOY/QXDp/YOwBhLolyUixTHeqMA6QVJkQ9ztAaF/N6Jht/STGFYKsGWe8iPB4PV9OaXZOMzd1qmMqlbLp2o/8nTTPJiSrOxl7hJ5EZ8xgA+NB8CdK3xWd2ee37fmjfbOhNwfdxi2oR9y1yC9ap+e/g/g7OtvEupRZl//dV+y9AV89nyQ=\",\n"
		+ "        \"name\": \"document15\"\n    },\n    {\n        \"document\": \"AAAB0nicdZHNCoMwDMfvPkXIeczJTgM/GHgcG2wPIJmtm1CrtCru7Vd1HVo2KKVpkn9+ScJkqAT0XOmylhEG2x0msRdW1HJVkhiWrv0BIa9FrXRDOY/QXDp/YOwBhLolyUixTHeqMA6QVJkQ9ztAaF/N6Jht/STGFYKsGWe8iPB4PV9OaXZOMzd1qmMqlbLp2o/8nTTPJiSrOxl7hJ5EZ8xgA+NB8CdK3xWd2ee37fmjfbOhNwfdxi2oR9y1yC9ap+e/g/g7OtvEupRZl//dV+y9AV89nyQ=\",\n        \"name\": \"document16\"\n    },\n    {\n        \"document\": \"AAACXXicpZLNasMwDMfveQqh81ja9RRIUgo9jg7WBzCa7WwBxw7+KN3bz/lwaUJ7GhhjWfJP1l8q99dOwUVa1xpd4fZ1g/s6Kzvy0rakrveuXYHAjTLW9cRlhXFz/BvrDKB0nrQgK5gLtokO0NTFkPX1FsH/9oNjst0PCWkRtBFSyKbCw+fp4/3ITke2fjrmiZla3Qef8L3kQZFl47cSezR2CBdSIZqbFxgWQv6IEL5mPrMk2uD+CXGclEyMRhnyN0TUtngrZkKZr+ubZJzOSf6Zf06h55WKKe5OwEG5JeShcEv5n/bkaRdTEctUcXLy2+jU2R83Msso\",\n        \"name\": \"document17\"\n    },\n    {\n        \"document\": \"AAAB2HicdVFLC4JAEL77K4Y5RxpeCnwQdAyD+gEyuVsJusquiv371seGLnUZdh77PWaCuC8L6LhUeSVC3G09jCMnKKnhMqeiX7b8A0JWFZVUNWU8RB1U9sTIAQhUQ4KRZKlq5UM3QFCpR+zyDqF510NjytWLGJcIomKc8UeIx2tyOZ/S5JTaX0cezZSLum1m+Dspno6SDO6Y+AgdFa1Ove1+AyYguKNW14aeHExv43xmuJnRm2XAzC20D6LXIL80W87/ruPvAo2JNZU+mvu9WuR8AEyYoFM=\",\n"
		+ "        \"name\": \"document18\"\n    },\n    {\n        \"document\": \"AAAB0nicdZHNCoMwDMfvPkXIeczJTgM/GHgcG2wPIJmtm1CrtCru7Vd1HVo2KKVpkn9+ScJkqAT0XOmylhEG2x0msRdW1HJVkhiWrv0BIa9FrXRDOY/QXDp/YOwBhLolyUixTHeqMA6QVJkQ9ztAaF/N6Jht/STGFYKsGWe8iPB4PV9OaXZOMzd1qmMqlbLp2o/8nTTPJiSrOxl7hJ5EZ8xgA+NB8CdK3xWd2ee37fmjfbOhNwfdxi2oR9y1yC9ap+e/g/g7OtvEupRZl//dV+y9AV89nyQ=\",\n        \"name\": \"document19\"\n    },\n    {\n        \"document\": \"AAAB2XicdVHdCoIwFL73KQ7nOtLoKvCHwMsoqAeQk5s10Cmbi3r7prbIkTDGzr6z7+cszp5NDQ+utGhlgpt1hFkaxA31XAmqn7/QdodQtnWrdEclT9BuurxhGgDEuifJSLFCG1VZACQ1tsW/3iD0r24AplrfiXGFIFvGGa8S3J+Pp0NeHPPCfzrqWCUhO9M7enP9oIUiJox29KPNLcKDamPLaAXDQghHs6HPPUWYzi76R+LiWi9eAtf3Y35wPSf5b3oWfXEeixN0IeZS9tfC77elwRtrxqIi\",\n        \"name\": \"document20\"\n    },\n    {\n        \"document\": \"AAACt3ichVLbasMwDH3PVwg/l1zIylpIUgZ9HB2sHxC02FkDjhMsp3R/P+fi0oaEgjGWpXOO5aPkcKslXIWmqlEpi/yQHTIvqdEIXaG8PabiPYOikY2mFguRMrtR8csyDyAhg4qj5jl1urQJUFjbkvl1xMD8tX1ijOmCXGgGquGCizJlH9+nr89jfjrmc+igY5Uq1XZmojcaFdUV9S/MuWjNxfGXskHD4Iqys1HIIFiAU/czkedDXw48BPEdHW2gXy85NPKqoxWS0A/f9tEujDewdHxJTgVKsdxd7L9H2912okiC+c+NBo1nZ+wkcHal55k/ru7Bmt6TZ5IlS2bGrrq9Oh+uiWcpO5PBfSgz7x/fCuXG\",\n"
		+ "        \"name\": \"document21\"\n    },\n    {\n        \"document\": \"AAABgHicdVDLCoMwELz7Fct+QK30VPBBwWOxUD9AgomtoElIYrF/39g0RQNeFnZndmZ202IeB3gxpXvBM0wORyzyKB2JYaonw7yGTmeEVgxCaUlalqEtun1gHgGk2hBOiaKNnlRnAeBktJRwnCCYt1wA1+snoUwhcEEZZV2Gl3t1u5ZNVTbhKkLsnFzrE/6Mas+uAyPPW3ks4luR7w1Wu+dyMj76NuFu7N1DXdw4sLLPjf/fzaMP3D+Faw==\",\n        \"name\": \"document22\"\n    }\n]\n");
createNode transform -n "Bob_Omb";
	rename -uid "F9FD11DB-404A-0253-44E9-84937AF7E5CC";
	setAttr ".t" -type "double3" 0 0.040885543236105049 0 ;
	setAttr ".r" -type "double3" 0 -89.999999999999972 0 ;
	setAttr ".rp" -type "double3" 0.016341540040125557 -0.048871218271624439 6.7183809405168695 ;
	setAttr ".rpt" -type "double3" 0 0 -4.4408920985006262e-15 ;
	setAttr ".sp" -type "double3" 0.016341540040125557 -0.048871218271624439 6.7183809405168695 ;
createNode transform -n "pSphere2" -p "Bob_Omb";
	rename -uid "B1A0EA7B-904C-B42F-362B-9497C5A088BF";
	setAttr ".t" -type "double3" -0.25597627572404669 0.39665346175753158 6.226279745793466 ;
	setAttr ".r" -type "double3" 34.188006036771334 -4.6229645962976873 -0.94881367187632082 ;
	setAttr ".s" -type "double3" 0.10619523549188552 0.17900901341538886 0.076482035895967124 ;
createNode mesh -n "pSphereShape2" -p "pSphere2";
	rename -uid "F081F548-9844-C70A-7513-339EB939EF22";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode transform -n "pCube3" -p "Bob_Omb";
	rename -uid "5FB1132D-5142-83F8-1B20-FD9A4E3C6AAA";
	setAttr ".t" -type "double3" -0.30304851484204964 -0.97949977409644939 6.6625520491586165 ;
	setAttr ".r" -type "double3" -3.3197334178140161 -1.7662525828403257 -2.6582823862421394 ;
	setAttr ".s" -type "double3" 0.46934763304226917 0.34143362144610284 0.41431624003057566 ;
createNode mesh -n "pCubeShape3" -p "pCube3";
	rename -uid "9E303761-1243-1831-5D1F-D983F5BDCA0A";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr -s 6 ".gtag";
	setAttr ".gtag[0].gtagnm" -type "string" "back";
	setAttr ".gtag[0].gtagcmp" -type "componentList" 1 "f[8:11]";
	setAttr ".gtag[1].gtagnm" -type "string" "bottom";
	setAttr ".gtag[1].gtagcmp" -type "componentList" 2 "f[12:15]" "f[40:45]";
	setAttr ".gtag[2].gtagnm" -type "string" "front";
	setAttr ".gtag[2].gtagcmp" -type "componentList" 3 "f[0:3]" "f[24:39]" "f[46:51]";
	setAttr ".gtag[3].gtagnm" -type "string" "left";
	setAttr ".gtag[3].gtagcmp" -type "componentList" 1 "f[20:23]";
	setAttr ".gtag[4].gtagnm" -type "string" "right";
	setAttr ".gtag[4].gtagcmp" -type "componentList" 1 "f[16:19]";
	setAttr ".gtag[5].gtagnm" -type "string" "top";
	setAttr ".gtag[5].gtagcmp" -type "componentList" 1 "f[4:7]";
	setAttr ".pv" -type "double2" 0.5 0.125 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr -s 69 ".uvst[0].uvsp[0:68]" -type "float2" 0.375 0 0.375 1 0.625
		 0 0.625 1 0.375 0.25 0.625 0.25 0.375 0.5 0.125 0.25 0.625 0.5 0.875 0.25 0.375 0.75
		 0.125 0 0.625 0.75 0.875 0 0.5 0.125 0.5 0.375 0.5 0.625 0.5 0.875 0.75 0.125 0.25
		 0.125 0.5 0 0.5 1 0.625 0.125 0.5 0.25 0.375 0.125 0.625 0.375 0.75 0.25 0.5 0.5
		 0.375 0.375 0.25 0.25 0.625 0.625 0.875 0.125 0.5 0.75 0.375 0.625 0.125 0.125 0.625
		 0.875 0.75 0 0.375 0.875 0.25 0 0.375 0 0.5 0 0.375 0.125 0.625 0 0.625 0.125 0.625
		 0.25 0.5 0.25 0.375 0.25 0.375 0 0.5 0 0.375 0.125 0.625 0 0.625 0.125 0.625 0.25
		 0.5 0.25 0.375 0.25 0.375 0.75 0.5 0.75 0.375 0.875 0.625 0.75 0.625 0.875 0.625
		 1 0.375 1 0.375 0 0.375 0 0.625 0 0.625 0 0.5 0 0.375 0 0.625 0;
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 14 ".pt";
	setAttr ".pt[2]" -type "float3" 0 -0.098316528 0 ;
	setAttr ".pt[3]" -type "float3" 0 -0.098316528 0 ;
	setAttr ".pt[15]" -type "float3" 0 -0.098316528 0 ;
	setAttr ".pt[27]" -type "float3" 0 2.2351742e-08 0 ;
	setAttr ".pt[28]" -type "float3" 0 2.2351742e-08 0 ;
	setAttr ".pt[29]" -type "float3" 0 2.2351742e-08 0 ;
	setAttr ".pt[30]" -type "float3" 0.046962298 0.3523955 0.24699387 ;
	setAttr ".pt[31]" -type "float3" -5.1222742e-09 -4.4703484e-08 1.3969839e-08 ;
	setAttr ".pt[32]" -type "float3" 0.040766343 0.42628106 -0.020912452 ;
	setAttr ".pt[33]" -type "float3" 0.029314773 0.35866877 0.12457506 ;
	setAttr ".pt[36]" -type "float3" -0.057692792 0.29833868 -0.19263238 ;
	setAttr ".pt[37]" -type "float3" -0.034381606 0.32803676 -0.15011312 ;
	setAttr ".pt[38]" -type "float3" -0.031927604 0.28588203 -0.0035559665 ;
	setAttr ".pt[52]" -type "float3" 4.6566129e-10 -2.9802322e-08 2.8871e-08 ;
	setAttr -s 54 ".vt[0:53]"  -0.27777767 -0.36111164 0.27777767 0.27777767 -0.27777779 0.27777767
		 -0.27777767 0.27777779 0.27777767 0.27777767 0.27777779 0.27777767 -0.27777767 0.27777776 -0.27777791
		 0.27777767 0.27777779 -0.27777791 -0.27777767 -0.36111107 -0.27777767 0.27777767 -0.33333379 -0.27777791
		 -0.375 0.375 0 0.375 0 -0.375 0 -0.36111107 -0.375 -0.375 0 -0.375 0.375 -0.33333397 0
		 -0.375 -0.36111164 0 0.375 0 0.375 0 0.375 0.375 -0.375 0 0.375 0.375 0.375 0 0 0.375 -0.375
		 0 0.5 0 0 0 -0.5 0.5 0 0 -0.5 0 0 -0.27777767 -0.36111164 0.27777767 -0.375 0 0.375
		 0.27777767 -0.27777779 0.27777767 0.375 0 0.375 0.27777767 0.27777779 0.27777767
		 0 0.375 0.375 -0.27777767 0.27777779 0.27777767 -0.27777767 -0.36111164 0.83895326
		 0 -0.36111164 0.93617558 0 0 1.061175585 -0.375 0 0.93617558 0.27777767 -0.27777779 0.83895326
		 0.375 0 0.93617558 0.27777767 0.27777779 0.83895326 0 0.375 0.93617558 -0.27777767 0.27777779 0.83895326
		 -0.27385616 -0.43954435 -0.27385616 0.0034146309 -0.43958846 -0.37158513 0.0053634644 -0.41175559 0.001957655
		 -0.37107849 -0.43954492 0 0.28068542 -0.41185528 -0.27486968 0.3817811 -0.41146967 0.0039019585
		 0.2831049 -0.31665275 0.31954002 0.0072951317 -0.43940017 0.3754735 -0.27581692 -0.40032828 0.31513143
		 0.011378288 -0.43891314 0.375 -0.27777767 -0.40042621 0.31709218 0.2890749 -0.31543431 0.31709218
		 0.011297226 -0.43808272 0.93617558 -0.27777767 -0.43974078 0.83895326 0.30037212 -0.35309082 0.83895326;
	setAttr -s 104 ".ed[0:103]"  2 15 0 15 3 0 4 18 1 18 5 1 6 10 1 10 7 1
		 0 16 0 16 2 0 1 14 0 14 3 0 2 8 1 8 4 1 3 17 1 17 5 1 4 11 1 11 6 1 5 9 1 9 7 1 6 13 1
		 13 0 1 7 12 1 12 1 0 15 19 1 19 8 1 17 19 1 18 19 1 18 20 1 20 11 1 9 20 1 10 20 1
		 12 21 1 21 14 1 9 21 1 17 21 1 13 22 1 22 11 1 16 22 1 8 22 1 0 23 0 16 24 0 23 24 0
		 1 25 0 14 26 0 25 26 0 3 27 0 26 27 0 15 28 0 28 27 0 2 29 0 29 28 0 24 29 0 23 30 1
		 30 31 1 31 32 1 24 33 0 32 33 1 30 33 0 25 34 0 31 34 1 26 35 0 34 35 0 35 32 1 27 36 0
		 35 36 0 28 37 0 37 36 0 37 32 1 29 38 0 38 37 0 33 38 0 6 39 0 10 40 0 39 40 0 40 41 1
		 13 42 0 41 42 1 39 42 0 7 43 0 40 43 0 12 44 0 43 44 0 44 41 1 1 45 0 44 45 0 46 45 0
		 46 41 1 0 47 0 47 46 0 42 47 0 46 48 0 23 49 0 49 48 0 47 49 0 25 50 0 45 50 0 48 50 0
		 31 51 0 48 51 0 30 52 0 52 51 0 49 52 0 34 53 0 50 53 0 51 53 0;
	setAttr -s 52 -ch 208 ".fc[0:51]" -type "polyFaces" 
		f 4 52 53 55 -57
		mu 0 4 47 48 14 49
		f 4 58 60 61 -54
		mu 0 4 48 50 51 14
		f 4 -62 63 -66 66
		mu 0 4 14 51 52 53
		f 4 -56 -67 -69 -70
		mu 0 4 49 14 53 54
		f 4 0 22 23 -11
		mu 0 4 4 23 15 28
		f 4 1 12 24 -23
		mu 0 4 23 5 25 15
		f 4 -25 13 -4 25
		mu 0 4 15 25 8 27
		f 4 -24 -26 -3 -12
		mu 0 4 28 15 27 6
		f 4 2 26 27 -15
		mu 0 4 6 27 16 33
		f 4 3 16 28 -27
		mu 0 4 27 8 30 16
		f 4 -29 17 -6 29
		mu 0 4 16 30 12 32
		f 4 -28 -30 -5 -16
		mu 0 4 33 16 32 10
		f 4 72 73 75 -77
		mu 0 4 55 56 17 57
		f 4 78 80 81 -74
		mu 0 4 56 58 59 17
		f 4 -82 83 -85 85
		mu 0 4 17 59 60 21
		f 4 -76 -86 -88 -89
		mu 0 4 57 17 21 61
		f 4 -22 30 31 -9
		mu 0 4 2 36 18 22
		f 4 -21 -18 32 -31
		mu 0 4 36 13 31 18
		f 4 -33 -17 -14 33
		mu 0 4 18 31 9 26
		f 4 -32 -34 -13 -10
		mu 0 4 22 18 26 5
		f 4 18 34 35 15
		mu 0 4 11 38 19 34
		f 4 19 6 36 -35
		mu 0 4 38 0 24 19
		f 4 -37 7 10 37
		mu 0 4 19 24 4 29
		f 4 -36 -38 11 14
		mu 0 4 34 19 29 7
		f 4 87 89 -92 -93
		mu 0 4 63 20 40 62
		f 4 -7 38 40 -40
		mu 0 4 24 0 39 41
		f 4 84 94 -96 -90
		mu 0 4 20 64 65 40
		f 4 8 42 -44 -42
		mu 0 4 2 22 43 42
		f 4 9 44 -46 -43
		mu 0 4 22 5 44 43
		f 4 -2 46 47 -45
		mu 0 4 5 23 45 44
		f 4 -1 48 49 -47
		mu 0 4 23 4 46 45
		f 4 -8 39 50 -49
		mu 0 4 4 24 41 46
		f 4 91 97 -100 -101
		mu 0 4 62 40 66 67
		f 4 -41 51 56 -55
		mu 0 4 41 39 47 49
		f 4 95 102 -104 -98
		mu 0 4 40 65 68 66
		f 4 43 59 -61 -58
		mu 0 4 42 43 51 50
		f 4 45 62 -64 -60
		mu 0 4 43 44 52 51
		f 4 -48 64 65 -63
		mu 0 4 44 45 53 52
		f 4 -50 67 68 -65
		mu 0 4 45 46 54 53
		f 4 -51 54 69 -68
		mu 0 4 46 41 49 54
		f 4 4 71 -73 -71
		mu 0 4 10 32 56 55
		f 4 -19 70 76 -75
		mu 0 4 37 10 55 57
		f 4 5 77 -79 -72
		mu 0 4 32 12 58 56
		f 4 20 79 -81 -78
		mu 0 4 12 35 59 58
		f 4 21 82 -84 -80
		mu 0 4 35 3 60 59
		f 4 -20 74 88 -87
		mu 0 4 1 37 57 61
		f 4 -39 86 92 -91
		mu 0 4 39 0 63 62
		f 4 41 93 -95 -83
		mu 0 4 2 42 65 64
		f 4 -53 98 99 -97
		mu 0 4 48 47 67 66
		f 4 -52 90 100 -99
		mu 0 4 47 39 62 67
		f 4 57 101 -103 -94
		mu 0 4 42 50 68 65
		f 4 -59 96 103 -102
		mu 0 4 50 48 66 68;
	setAttr ".cd" -type "dataPolyComponent" Index_Data Edge 0 ;
	setAttr ".cvd" -type "dataPolyComponent" Index_Data Vertex 0 ;
	setAttr ".pd[0]" -type "dataPolyComponent" Index_Data UV 0 ;
	setAttr ".hfd" -type "dataPolyComponent" Index_Data Face 0 ;
	setAttr ".dr" 3;
	setAttr ".dsm" 2;
createNode transform -n "pCube2" -p "Bob_Omb";
	rename -uid "E5A99FC2-FE4C-827C-6E4B-7D8038F3503C";
	setAttr ".t" -type "double3" 0.29932589132236692 -0.23692585972408448 5.7838677218529533 ;
	setAttr ".r" -type "double3" 56.274842875588874 -5.6184413073002322 -4.2269521839106625 ;
	setAttr ".s" -type "double3" 0.46934763304226917 0.3882915639453961 0.41431624003057566 ;
createNode mesh -n "pCubeShape2" -p "pCube2";
	rename -uid "FE64FD1C-2345-0542-8E86-34AA8F2BB4AB";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.5 0.25 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 6 ".pt";
	setAttr ".pt[2]" -type "float3" 0 -0.098316528 0 ;
	setAttr ".pt[3]" -type "float3" 0 -0.098316528 0 ;
	setAttr ".pt[15]" -type "float3" 0 -0.098316528 0 ;
	setAttr ".pt[27]" -type "float3" 0 2.2351742e-08 0 ;
	setAttr ".pt[28]" -type "float3" 0 2.2351742e-08 0 ;
	setAttr ".pt[29]" -type "float3" 0 2.2351742e-08 0 ;
	setAttr ".dr" 3;
	setAttr ".dsm" 2;
createNode transform -n "pCylinder2" -p "Bob_Omb";
	rename -uid "9BA2F3E1-D84E-A5CE-7CC9-8DA451C70DF7";
	setAttr ".t" -type "double3" 0.00071107635494384314 0.64293692773533062 6.8524802103099738 ;
	setAttr ".r" -type "double3" 11.692009321288698 3.3313978247646827 2.153946941310362 ;
	setAttr ".s" -type "double3" 0.35 0.07 0.35 ;
createNode mesh -n "pCylinderShape2" -p "pCylinder2";
	rename -uid "96D2A587-F349-0C50-4B9B-5F8D3693CF68";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.41319864988327026 0.18845426291227341 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode transform -n "pCylinder7" -p "Bob_Omb";
	rename -uid "72659D0A-7443-A612-F1A7-2AAF86516990";
	setAttr ".t" -type "double3" -0.29531376991857317 -0.70500126398997587 6.8094019758088074 ;
	setAttr ".r" -type "double3" -10.517502212371024 -48.968028247398259 3.6571403944913827 ;
	setAttr ".s" -type "double3" 0.07 0.25 0.07 ;
createNode mesh -n "pCylinderShape7" -p "pCylinder7";
	rename -uid "7C023507-E541-F807-A30C-99B65A785E61";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr -s 10 ".gtag";
	setAttr ".gtag[0].gtagnm" -type "string" "bottom";
	setAttr ".gtag[0].gtagcmp" -type "componentList" 21 "f[80:99]" "f[121:122]" "f[124:125]" "f[127:128]" "f[130:131]" "f[133:134]" "f[136:137]" "f[139:140]" "f[142:143]" "f[145:146]" "f[148:149]" "f[151:152]" "f[154:155]" "f[157:158]" "f[160:161]" "f[163:164]" "f[166:167]" "f[169:170]" "f[172:173]" "f[175:176]" "f[178:179]";
	setAttr ".gtag[1].gtagnm" -type "string" "bottomRing";
	setAttr ".gtag[1].gtagcmp" -type "componentList" 0;
	setAttr ".gtag[2].gtagnm" -type "string" "cylBottomCap";
	setAttr ".gtag[2].gtagcmp" -type "componentList" 1 "vtx[0]";
	setAttr ".gtag[3].gtagnm" -type "string" "cylBottomRing";
	setAttr ".gtag[3].gtagcmp" -type "componentList" 0;
	setAttr ".gtag[4].gtagnm" -type "string" "cylSides";
	setAttr ".gtag[4].gtagcmp" -type "componentList" 0;
	setAttr ".gtag[5].gtagnm" -type "string" "cylTopCap";
	setAttr ".gtag[5].gtagcmp" -type "componentList" 1 "vtx[1]";
	setAttr ".gtag[6].gtagnm" -type "string" "cylTopRing";
	setAttr ".gtag[6].gtagcmp" -type "componentList" 0;
	setAttr ".gtag[7].gtagnm" -type "string" "sides";
	setAttr ".gtag[7].gtagcmp" -type "componentList" 40 "f[21:22]" "f[24:25]" "f[27:28]" "f[30:31]" "f[33:34]" "f[36:37]" "f[39:40]" "f[42:43]" "f[45:46]" "f[48:49]" "f[51:52]" "f[54:55]" "f[57:58]" "f[60:61]" "f[63:64]" "f[66:67]" "f[69:70]" "f[72:73]" "f[75:76]" "f[78:79]" "f[100:120]" "f[123]" "f[126]" "f[129]" "f[132]" "f[135]" "f[138]" "f[141]" "f[144]" "f[147]" "f[150]" "f[153]" "f[156]" "f[159]" "f[162]" "f[165]" "f[168]" "f[171]" "f[174]" "f[177]";
	setAttr ".gtag[8].gtagnm" -type "string" "top";
	setAttr ".gtag[8].gtagcmp" -type "componentList" 20 "f[0:20]" "f[23]" "f[26]" "f[29]" "f[32]" "f[35]" "f[38]" "f[41]" "f[44]" "f[47]" "f[50]" "f[53]" "f[56]" "f[59]" "f[62]" "f[65]" "f[68]" "f[71]" "f[74]" "f[77]";
	setAttr ".gtag[9].gtagnm" -type "string" "topRing";
	setAttr ".gtag[9].gtagcmp" -type "componentList" 0;
	setAttr ".pv" -type "double2" 0.49999998509883881 0.75 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr -s 207 ".uvst[0].uvsp[0:206]" -type "float2" 0.60113001 0.9172256
		 0.57347572 0.94488066 0.53862858 0.9626357 0.5 0.96875435 0.46137205 0.96263564 0.42652476
		 0.94488031 0.39887053 0.91722554 0.38111496 0.88237834 0.37499657 0.84375 0.38111493
		 0.80512172 0.39887059 0.77027476 0.42652467 0.74261987 0.46137178 0.72486454 0.5000006
		 0.71874642 0.53862864 0.72486448 0.57347572 0.7426194 0.60113019 0.77027464 0.61888582
		 0.80512166 0.62500405 0.84375 0.61888564 0.88237834 0.5000006 0.84375 0.62499976
		 0.67268634 0.375 0.67827874 0.62499976 0.67827886 0.375 0.6875 0.6486026 0.89203393
		 0.62499976 0.6875 0.38749999 0.67812508 0.38749999 0.6875 0.62640893 0.93559146 0.39999989
		 0.6781224 0.39999998 0.6875 0.59184146 0.97015893 0.4124999 0.67811972 0.41249996
		 0.6875 0.54828387 0.9923526 0.42499986 0.67812234 0.42499995 0.6875 0.5 1 0.4375
		 0.67812234 0.43749994 0.6875 0.4517161 0.9923526 0.4499999 0.67812246 0.44999993
		 0.6875 0.40815854 0.97015893 0.46249989 0.6781224 0.46249992 0.6875 0.37359107 0.93559146
		 0.47499982 0.67812222 0.4749999 0.6875 0.3513974 0.89203393 0.48749989 0.6781227
		 0.48749989 0.6875 0.34374997 0.84375 0.49999994 0.67812258 0.49999988 0.6875 0.3513974
		 0.79546607 0.51249981 0.67812246 0.51249987 0.6875 0.37359107 0.75190854 0.5249998
		 0.67812246 0.52499986 0.6875 0.40815851 0.71734107 0.53749979 0.67812228 0.53749985
		 0.6875 0.45171607 0.69514734 0.54999977 0.67812246 0.54999983 0.6875 0.5 0.68749994
		 0.56249988 0.67812246 0.56249982 0.6875 0.54828393 0.69514734 0.57499987 0.67812246
		 0.57499981 0.6875 0.59184152 0.71734101 0.58749986 0.6781224 0.5874998 0.6875 0.62640899
		 0.75190848 0.59999973 0.67812252 0.59999979 0.6875 0.64860266 0.79546607 0.61249977
		 0.67812508 0.65625 0.84375 0.61249977 0.6875 0.61888599 0.11762159 0.60113043 0.082774177
		 0.5734759 0.055119108 0.53862846 0.037363473 0.5 0.031244891 0.46137112 0.037363544
		 0.42652407 0.055119094 0.39886948 0.082773924 0.38111392 0.11762176 0.37499532 0.15625
		 0.38111359 0.19487853 0.39886937 0.22972615 0.42652398 0.25738108 0.46137121 0.27513635
		 0.5 0.28125489 0.53862846 0.27513641 0.5734759 0.2573812 0.60113031 0.22972547 0.61888587
		 0.19487871 0.5000006 0.15625 0.62500429 0.15625 0.38749999 0.32731274 0.375 0.67268616
		 0.39999998 0.32731321 0.38750002 0.67268634 0.41249979 0.32731193 0.39999995 0.67268628
		 0.42499983 0.32731274 0.41249996 0.67268193 0.43749994 0.32731318 0.4249998 0.67268628
		 0.44999993 0.32731244 0.43749994 0.67268628 0.4624998 0.32731318 0.44999993 0.67268634
		 0.47499985 0.32731268 0.46249983 0.67268628 0.48749989 0.32731318 0.4749999 0.67268568
		 0.49999982 0.3273133 0.48749986 0.67268628 0.51249987 0.32731259 0.49999982 0.67268628
		 0.52499974 0.32731321 0.51249987 0.67268634 0.53749979 0.32731295 0.52499974 0.67268628
		 0.54999983 0.32731736 0.53749985 0.67268628 0.56249982 0.32731324 0.54999995 0.6726864
		 0.57499981 0.32731301 0.56249982 0.67268652 0.5874998 0.3273133 0.57499981 0.67268646
		 0.59999979 0.32731321 0.5874998 0.67268628 0.61249977 0.32731271 0.59999985 0.67268634
		 0.62499976 0.32731318 0.61249977 0.67268634 0.375 0.3273136 0.63559598 0.11219232
		 0.64860266 0.10796607 0.375 0.3125 0.62499976 0.3125 0.61534488 0.072446577 0.62640899
		 0.064408496 0.38749999 0.3125 0.583803 0.040904559 0.59184152 0.029841021 0.39999998
		 0.3125 0.54405755 0.02065379 0.54828393 0.0076473355 0.41249979 0.3125 0.50000012
		 0.013675098 0.5 -7.4505806e-08 0.42499983 0.3125 0.45594218 0.020653818 0.45171607
		 0.0076473504 0.43749994 0.3125 0.41619697 0.040904406 0.40815851 0.029841051 0.44999993
		 0.3125 0.38465515 0.072446615 0.37359107 0.064408526 0.4624998 0.3125 0.36440277
		 0.11219238 0.3513974 0.1079661 0.47499985 0.3125 0.35742497 0.15625001 0.34374997
		 0.15625 0.48749989 0.3125 0.36440262 0.20030776 0.3513974 0.2045339 0.49999982 0.3125
		 0.38465509 0.2400533 0.37359107 0.24809146 0.51249987 0.3125 0.41619694 0.27159584
		 0.40815854 0.28265893 0.52499974 0.3125 0.45594221 0.29184628 0.4517161 0.3048526
		 0.53749979 0.3125 0.50000012 0.29882473 0.5 0.3125 0.54999983 0.3125 0.54405749 0.29184631
		 0.54828387 0.3048526 0.56249982 0.3125 0.583803 0.27159587 0.59184146 0.28265893
		 0.57499981 0.3125 0.61534482 0.24005328 0.62640893 0.24809146 0.5874998 0.3125 0.63559586
		 0.20030782 0.6486026 0.2045339 0.59999979 0.3125 0.64257389 0.15625001 0.61249977
		 0.3125 0.65625 0.15625;
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 162 ".vt[0:161]"  1.1444092e-05 -1 0 1.1444092e-05 0.99999976 0
		 0.95105743 0.92099357 -0.30901718 0.92557526 0.96049666 -0.30073929 0.85596085 0.98941493 -0.27811813
		 0.76087189 0.99999976 -0.24722099 0.80901718 0.92099357 -0.58778572 0.78734589 0.96049666 -0.57203865
		 0.72812271 0.98941493 -0.5290184 0.64723206 0.99999976 -0.47024345 0.58778763 0.92099357 -0.80901909
		 0.57204437 0.96049666 -0.78734398 0.52901459 0.98941493 -0.72812843 0.47024918 0.99999976 -0.64723587
		 0.309021 0.92099357 -0.95105743 0.3007431 0.96049666 -0.92557716 0.27812195 0.98941493 -0.85596275
		 0.2472229 0.99999976 -0.76086807 1.1444092e-05 0.92099357 -1.000001907349 1.1444092e-05 0.96049666 -0.97321129
		 1.1444092e-05 0.98941493 -0.90001678 1.1444092e-05 0.99999976 -0.80002594 -0.30901718 0.92099357 -0.95105743
		 -0.30073929 0.96049666 -0.92557716 -0.27811813 0.98941493 -0.85596275 -0.24721909 0.99999976 -0.76086807
		 -0.58778763 0.92099357 -0.80901718 -0.57203674 0.96049666 -0.78734207 -0.52901077 0.98941493 -0.72812653
		 -0.47024155 0.99999976 -0.64723587 -0.80900955 0.92099357 -0.58778572 -0.78733826 0.96049666 -0.57203865
		 -0.7281189 0.98941493 -0.5290184 -0.64722824 0.99999976 -0.47024345 -0.9510498 0.92099357 -0.30901718
		 -0.92556763 0.96049666 -0.30073929 -0.85596085 0.98941493 -0.27811813 -0.76086426 0.99999976 -0.24722099
		 -0.99999237 0.92099357 0 -0.97319412 0.96049666 0 -0.90000916 0.98941493 0 -0.80002213 0.99999976 0
		 -0.9510498 0.92099357 0.30901337 -0.92556763 0.96049666 0.30073547 -0.85596085 0.98941493 0.27811432
		 -0.76086426 0.99999976 0.24722099 -0.80900955 0.92099357 0.58778572 -0.78733826 0.96049666 0.57203674
		 -0.7281189 0.98941493 0.52901459 -0.64722824 0.99999976 0.47024155 -0.58778763 0.92099357 0.80901527
		 -0.57203674 0.96049666 0.78733826 -0.52901077 0.98941493 0.72812271 -0.47024155 0.99999976 0.64723206
		 -0.30901718 0.92099357 0.95105553 -0.30073929 0.96049666 0.92557716 -0.27811813 0.98941493 0.85596275
		 -0.24721909 0.99999976 0.76086426 1.1444092e-05 0.92099357 0.99999809 1.1444092e-05 0.96049666 0.97320747
		 1.1444092e-05 0.98941493 0.90001106 1.1444092e-05 0.99999976 0.80002213 0.309021 0.92099357 0.95105553
		 0.3007431 0.96049666 0.92557716 0.27812195 0.98941493 0.85596275 0.2472229 0.99999976 0.76086426
		 0.58778763 0.92099357 0.80901527 0.57204437 0.96049666 0.78733826 0.52901459 0.98941493 0.72812271
		 0.47024918 0.99999976 0.64723206 0.80901718 0.92099357 0.58778572 0.78734589 0.96049666 0.57203674
		 0.72812271 0.98941493 0.52901459 0.64723206 0.99999976 0.47024155 0.95105743 0.92099357 0.30901337
		 0.92557526 0.96049666 0.30073547 0.85596085 0.98941493 0.27811432 0.76087189 0.99999976 0.24722099
		 1 0.92099357 0 0.97321701 0.96049666 0 0.90001297 0.98941493 0 0.80002975 0.99999976 0
		 0.76087189 -1 -0.24722099 0.85596085 -0.98941541 -0.27811813 0.92557526 -0.96049809 -0.30073929
		 0.95105743 -0.92099619 -0.30901718 0.64723587 -1 -0.47024536 0.72812653 -0.98941541 -0.5290184
		 0.78734589 -0.96049809 -0.57203865 0.80901718 -0.92099619 -0.58778572 0.47024918 -1 -0.64723778
		 0.5290184 -0.98941541 -0.72812843 0.57204437 -0.96049809 -0.78734398 0.58778763 -0.92099619 -0.80901909
		 0.24722672 -1 -0.7608757 0.27812195 -0.98941541 -0.85596275 0.3007431 -0.96049809 -0.92557716
		 0.309021 -0.92099619 -0.95105743 1.1444092e-05 -1 -0.80003357 1.1444092e-05 -0.98941541 -0.90001678
		 1.1444092e-05 -0.96049809 -0.97321129 1.1444092e-05 -0.92099619 -1.000001907349 -0.24721909 -1 -0.7608757
		 -0.27811813 -0.98941541 -0.85596275 -0.30073929 -0.96049809 -0.92557716 -0.30901718 -0.92099619 -0.95105743
		 -0.47024536 -1 -0.64723778 -0.52901077 -0.98941541 -0.72812843 -0.57204056 -0.96049809 -0.78734207
		 -0.58778763 -0.92099619 -0.80901718 -0.64722824 -1 -0.47024727 -0.7281189 -0.98941541 -0.5290184
		 -0.78733826 -0.96049809 -0.57203865 -0.80900955 -0.92099619 -0.58778572 -0.76086426 -1 -0.24722099
		 -0.85596085 -0.98941541 -0.27811813 -0.92556763 -0.96049809 -0.30073929 -0.9510498 -0.92099619 -0.30901718
		 -0.80002213 -1 0 -0.90000916 -0.98941541 0 -0.97319794 -0.96049809 0 -0.99999237 -0.92099619 0
		 -0.76086426 -1 0.24722099 -0.85596085 -0.98941541 0.27811432 -0.92556763 -0.96049809 0.30073547
		 -0.9510498 -0.92099619 0.30901337 -0.64722824 -1 0.47024727 -0.7281189 -0.98941541 0.52901459
		 -0.78733826 -0.96049809 0.57203674 -0.80900955 -0.92099619 0.58778572 -0.47024536 -1 0.64723778
		 -0.52901077 -0.98941541 0.72812843 -0.57204056 -0.96049809 0.78733826 -0.58778763 -0.92099619 0.80901527
		 -0.24721909 -1 0.76087189 -0.27811813 -0.98941541 0.85596275 -0.30073929 -0.96049809 0.92557716
		 -0.30901718 -0.92099619 0.95105553 1.1444092e-05 -1 0.80002785 1.1444092e-05 -0.98941541 0.90001297
		 1.1444092e-05 -0.96049809 0.97320747 1.1444092e-05 -0.92099619 0.99999809 0.24722672 -1 0.76087189
		 0.27812195 -0.98941541 0.85596275 0.3007431 -0.96049809 0.92557716 0.309021 -0.92099619 0.95105553
		 0.47024918 -1 0.64723778 0.5290184 -0.98941541 0.72812843 0.57204437 -0.96049809 0.78733826
		 0.58778763 -0.92099619 0.80901527 0.64723587 -1 0.47024155 0.72812653 -0.98941541 0.52901459
		 0.78734589 -0.96049809 0.57203674 0.80901718 -0.92099619 0.58778572 0.76087189 -1 0.24722099
		 0.85596085 -0.98941541 0.27811432 0.92557526 -0.96049809 0.30073547 0.95105743 -0.92099619 0.30901337
		 0.80002975 -1 0 0.90001297 -0.98941541 0 0.97321701 -0.96049809 0 1 -0.92099619 0;
	setAttr -s 340 ".ed";
	setAttr ".ed[0:165]"  79 78 1 78 2 1 80 79 1 5 81 1 81 80 1 5 4 1 9 5 1 4 3 1
		 3 2 1 2 6 1 9 8 1 13 9 1 8 7 1 7 6 1 6 10 1 13 12 1 17 13 1 12 11 1 11 10 1 10 14 1
		 17 16 1 21 17 1 16 15 1 15 14 1 14 18 1 21 20 1 25 21 1 20 19 1 19 18 1 18 22 1 25 24 1
		 29 25 1 24 23 1 23 22 1 22 26 1 29 28 1 33 29 1 28 27 1 27 26 1 26 30 1 33 32 1 37 33 1
		 32 31 1 31 30 1 30 34 1 37 36 1 41 37 1 36 35 1 35 34 1 34 38 1 41 40 1 45 41 1 40 39 1
		 39 38 1 38 42 1 45 44 1 49 45 1 44 43 1 43 42 1 42 46 1 49 48 1 53 49 1 48 47 1 47 46 1
		 46 50 1 53 52 1 57 53 1 52 51 1 51 50 1 50 54 1 57 56 1 61 57 1 56 55 1 55 54 1 54 58 1
		 61 60 1 65 61 1 60 59 1 59 58 1 58 62 1 65 64 1 69 65 1 64 63 1 63 62 1 62 66 1 69 68 1
		 73 69 1 68 67 1 67 66 1 66 70 1 73 72 1 77 73 1 72 71 1 71 70 1 70 74 1 77 76 1 81 77 1
		 76 75 1 75 74 1 74 78 1 9 1 1 1 5 1 13 1 1 17 1 1 21 1 1 25 1 1 29 1 1 33 1 1 37 1 1
		 41 1 1 45 1 1 49 1 1 53 1 1 57 1 1 61 1 1 65 1 1 69 1 1 73 1 1 77 1 1 81 1 1 4 80 0
		 3 79 1 4 8 1 3 7 1 8 12 1 7 11 1 12 16 0 11 15 0 16 20 0 15 19 0 20 24 0 19 23 0
		 24 28 1 23 27 0 28 32 1 27 31 1 32 36 1 31 35 1 36 40 0 35 39 1 40 44 0 39 43 1 44 48 1
		 43 47 1 48 52 1 47 51 1 52 56 1 51 55 0 56 60 0 55 59 0 60 64 0 59 63 0 64 68 1 63 67 0
		 68 72 1 67 71 1 72 76 1 71 75 1 76 80 0 75 79 1 159 158 1 158 82 1 160 159 1 85 161 1
		 161 160 1 85 84 1;
	setAttr ".ed[166:331]" 89 85 1 84 83 1 83 82 1 82 86 1 89 88 1 93 89 1 88 87 1
		 87 86 1 86 90 1 93 92 1 97 93 1 92 91 1 91 90 1 90 94 1 97 96 1 101 97 1 96 95 1
		 95 94 1 94 98 1 101 100 1 105 101 1 100 99 1 99 98 1 98 102 1 105 104 1 109 105 1
		 104 103 1 103 102 1 102 106 1 109 108 1 113 109 1 108 107 1 107 106 1 106 110 1 113 112 1
		 117 113 1 112 111 1 111 110 1 110 114 1 117 116 1 121 117 1 116 115 1 115 114 1 114 118 1
		 121 120 1 125 121 1 120 119 1 119 118 1 118 122 1 125 124 1 129 125 1 124 123 1 123 122 1
		 122 126 1 129 128 1 133 129 1 128 127 1 127 126 1 126 130 1 133 132 1 137 133 1 132 131 1
		 131 130 1 130 134 1 137 136 1 141 137 1 136 135 1 135 134 1 134 138 1 141 140 1 145 141 1
		 140 139 1 139 138 1 138 142 1 145 144 1 149 145 1 144 143 1 143 142 1 142 146 1 149 148 1
		 153 149 1 148 147 1 147 146 1 146 150 1 153 152 1 157 153 1 152 151 1 151 150 1 150 154 1
		 157 156 1 161 157 1 156 155 1 155 154 1 154 158 1 82 0 1 0 86 1 0 90 1 0 94 1 0 98 1
		 0 102 1 0 106 1 0 110 1 0 114 1 0 118 1 0 122 1 0 126 1 0 130 1 0 134 1 0 138 1 0 142 1
		 0 146 1 0 150 1 0 154 1 0 158 1 89 6 1 2 85 1 93 10 1 97 14 1 101 18 1 105 22 1 109 26 1
		 113 30 1 117 34 1 121 38 1 125 42 1 129 46 1 133 50 1 137 54 1 141 58 1 145 62 1
		 149 66 1 153 70 1 157 74 1 161 78 1 84 160 0 83 159 1 84 88 0 83 87 1 88 92 0 87 91 1
		 92 96 0 91 95 1 96 100 0 95 99 1 100 104 0 99 103 1 104 108 0 103 107 1 108 112 0
		 107 111 1 112 116 0 111 115 1 116 120 1 115 119 0 120 124 1 119 123 0 124 128 0 123 127 0
		 128 132 0 127 131 1 132 136 0 131 135 1 136 140 0 135 139 1 140 144 0 139 143 1;
	setAttr ".ed[332:339]" 144 148 0 143 147 1 148 152 0 147 151 1 152 156 0 151 155 1
		 156 160 0 155 159 1;
	setAttr -s 180 -ch 680 ".fc[0:179]" -type "polyFaces" 
		f 3 -7 100 101
		mu 0 3 19 0 20
		f 3 -12 102 -101
		mu 0 3 0 1 20
		f 3 -17 103 -103
		mu 0 3 1 2 20
		f 3 -22 104 -104
		mu 0 3 2 3 20
		f 3 -27 105 -105
		mu 0 3 3 4 20
		f 3 -32 106 -106
		mu 0 3 4 5 20
		f 3 -37 107 -107
		mu 0 3 5 6 20
		f 3 -42 108 -108
		mu 0 3 6 7 20
		f 3 -47 109 -109
		mu 0 3 7 8 20
		f 3 -52 110 -110
		mu 0 3 8 9 20
		f 3 -57 111 -111
		mu 0 3 9 10 20
		f 3 -62 112 -112
		mu 0 3 10 11 20
		f 3 -67 113 -113
		mu 0 3 11 12 20
		f 3 -72 114 -114
		mu 0 3 12 13 20
		f 3 -77 115 -115
		mu 0 3 13 14 20
		f 3 -82 116 -116
		mu 0 3 14 15 20
		f 3 -87 117 -117
		mu 0 3 15 16 20
		f 3 -92 118 -118
		mu 0 3 16 17 20
		f 3 -97 119 -119
		mu 0 3 17 18 20
		f 3 -4 -102 -120
		mu 0 3 18 19 20
		f 4 -6 3 4 -121
		mu 0 4 25 19 18 82
		f 4 -9 121 0 1
		mu 0 4 21 23 81 144
		f 4 -8 120 2 -122
		mu 0 4 23 26 83 81
		f 4 5 122 -11 6
		mu 0 4 19 25 29 0
		f 4 7 123 -13 -123
		mu 0 4 24 22 27 28
		f 4 8 9 -14 -124
		mu 0 4 22 106 108 27
		f 4 10 124 -16 11
		mu 0 4 0 29 32 1
		f 4 12 125 -18 -125
		mu 0 4 28 27 30 31
		f 4 13 14 -19 -126
		mu 0 4 27 108 110 30
		f 4 15 126 -21 16
		mu 0 4 1 32 35 2
		f 4 17 127 -23 -127
		mu 0 4 31 30 33 34
		f 4 18 19 -24 -128
		mu 0 4 30 110 112 33
		f 4 20 128 -26 21
		mu 0 4 2 35 38 3
		f 4 22 129 -28 -129
		mu 0 4 34 33 36 37
		f 4 23 24 -29 -130
		mu 0 4 33 112 114 36
		f 4 25 130 -31 26
		mu 0 4 3 38 41 4
		f 4 27 131 -33 -131
		mu 0 4 37 36 39 40
		f 4 28 29 -34 -132
		mu 0 4 36 114 116 39
		f 4 30 132 -36 31
		mu 0 4 4 41 44 5
		f 4 32 133 -38 -133
		mu 0 4 40 39 42 43
		f 4 33 34 -39 -134
		mu 0 4 39 116 118 42
		f 4 35 134 -41 36
		mu 0 4 5 44 47 6
		f 4 37 135 -43 -135
		mu 0 4 43 42 45 46
		f 4 38 39 -44 -136
		mu 0 4 42 118 120 45
		f 4 40 136 -46 41
		mu 0 4 6 47 50 7
		f 4 42 137 -48 -137
		mu 0 4 46 45 48 49
		f 4 43 44 -49 -138
		mu 0 4 45 120 122 48
		f 4 45 138 -51 46
		mu 0 4 7 50 53 8
		f 4 47 139 -53 -139
		mu 0 4 49 48 51 52
		f 4 48 49 -54 -140
		mu 0 4 48 122 124 51
		f 4 50 140 -56 51
		mu 0 4 8 53 56 9
		f 4 52 141 -58 -141
		mu 0 4 52 51 54 55
		f 4 53 54 -59 -142
		mu 0 4 51 124 126 54
		f 4 55 142 -61 56
		mu 0 4 9 56 59 10
		f 4 57 143 -63 -143
		mu 0 4 55 54 57 58
		f 4 58 59 -64 -144
		mu 0 4 54 126 128 57
		f 4 60 144 -66 61
		mu 0 4 10 59 62 11
		f 4 62 145 -68 -145
		mu 0 4 58 57 60 61
		f 4 63 64 -69 -146
		mu 0 4 57 128 130 60
		f 4 65 146 -71 66
		mu 0 4 11 62 65 12
		f 4 67 147 -73 -147
		mu 0 4 61 60 63 64
		f 4 68 69 -74 -148
		mu 0 4 60 130 132 63
		f 4 70 148 -76 71
		mu 0 4 12 65 68 13
		f 4 72 149 -78 -149
		mu 0 4 64 63 66 67
		f 4 73 74 -79 -150
		mu 0 4 63 132 134 66
		f 4 75 150 -81 76
		mu 0 4 13 68 71 14
		f 4 77 151 -83 -151
		mu 0 4 67 66 69 70
		f 4 78 79 -84 -152
		mu 0 4 66 134 136 69
		f 4 80 152 -86 81
		mu 0 4 14 71 74 15
		f 4 82 153 -88 -153
		mu 0 4 70 69 72 73
		f 4 83 84 -89 -154
		mu 0 4 69 136 138 72
		f 4 85 154 -91 86
		mu 0 4 15 74 77 16
		f 4 87 155 -93 -155
		mu 0 4 73 72 75 76
		f 4 88 89 -94 -156
		mu 0 4 72 138 140 75
		f 4 90 156 -96 91
		mu 0 4 16 77 80 17
		f 4 92 157 -98 -157
		mu 0 4 76 75 78 79
		f 4 93 94 -99 -158
		mu 0 4 75 140 142 78
		f 4 95 158 -5 96
		mu 0 4 17 80 82 18
		f 4 97 159 -3 -159
		mu 0 4 79 78 81 83
		f 4 98 99 -1 -160
		mu 0 4 78 142 144 81
		f 3 -170 260 261
		mu 0 3 85 84 103
		f 3 -175 -262 262
		mu 0 3 86 85 103
		f 3 -180 -263 263
		mu 0 3 87 86 103
		f 3 -185 -264 264
		mu 0 3 88 87 103
		f 3 -190 -265 265
		mu 0 3 89 88 103
		f 3 -195 -266 266
		mu 0 3 90 89 103
		f 3 -200 -267 267
		mu 0 3 91 90 103
		f 3 -205 -268 268
		mu 0 3 92 91 103
		f 3 -210 -269 269
		mu 0 3 93 92 103
		f 3 -215 -270 270
		mu 0 3 94 93 103
		f 3 -220 -271 271
		mu 0 3 95 94 103
		f 3 -225 -272 272
		mu 0 3 96 95 103
		f 3 -230 -273 273
		mu 0 3 97 96 103
		f 3 -235 -274 274
		mu 0 3 98 97 103
		f 3 -240 -275 275
		mu 0 3 99 98 103
		f 3 -245 -276 276
		mu 0 3 100 99 103
		f 3 -250 -277 277
		mu 0 3 101 100 103
		f 3 -255 -278 278
		mu 0 3 102 101 103
		f 3 -260 -279 279
		mu 0 3 104 102 103
		f 3 -162 -280 -261
		mu 0 3 84 104 103
		f 4 -167 280 -10 281
		mu 0 4 145 105 108 106
		f 4 -172 282 -15 -281
		mu 0 4 105 107 110 108
		f 4 -177 283 -20 -283
		mu 0 4 107 109 112 110
		f 4 -182 284 -25 -284
		mu 0 4 109 111 114 112
		f 4 -187 285 -30 -285
		mu 0 4 111 113 116 114
		f 4 -192 286 -35 -286
		mu 0 4 113 115 118 116
		f 4 -197 287 -40 -287
		mu 0 4 115 117 120 118
		f 4 -202 288 -45 -288
		mu 0 4 117 119 122 120
		f 4 -207 289 -50 -289
		mu 0 4 119 121 124 122
		f 4 -212 290 -55 -290
		mu 0 4 121 123 126 124
		f 4 -217 291 -60 -291
		mu 0 4 123 125 128 126
		f 4 -222 292 -65 -292
		mu 0 4 125 127 130 128
		f 4 -227 293 -70 -293
		mu 0 4 127 129 132 130
		f 4 -232 294 -75 -294
		mu 0 4 129 131 134 132
		f 4 -237 295 -80 -295
		mu 0 4 131 133 136 134
		f 4 -242 296 -85 -296
		mu 0 4 133 135 138 136
		f 4 -247 297 -90 -297
		mu 0 4 135 137 140 138
		f 4 -252 298 -95 -298
		mu 0 4 137 139 142 140
		f 4 -257 299 -100 -299
		mu 0 4 139 141 144 142
		f 4 -164 -282 -2 -300
		mu 0 4 141 143 21 144
		f 4 -166 163 164 -301
		mu 0 4 149 143 141 205
		f 4 -169 301 160 161
		mu 0 4 84 146 204 104
		f 4 -168 300 162 -302
		mu 0 4 146 147 206 204
		f 4 165 302 -171 166
		mu 0 4 145 148 152 105
		f 4 167 303 -173 -303
		mu 0 4 147 146 150 151
		f 4 168 169 -174 -304
		mu 0 4 146 84 85 150
		f 4 170 304 -176 171
		mu 0 4 105 152 155 107
		f 4 172 305 -178 -305
		mu 0 4 151 150 153 154
		f 4 173 174 -179 -306
		mu 0 4 150 85 86 153
		f 4 175 306 -181 176
		mu 0 4 107 155 158 109
		f 4 177 307 -183 -307
		mu 0 4 154 153 156 157
		f 4 178 179 -184 -308
		mu 0 4 153 86 87 156
		f 4 180 308 -186 181
		mu 0 4 109 158 161 111
		f 4 182 309 -188 -309
		mu 0 4 157 156 159 160
		f 4 183 184 -189 -310
		mu 0 4 156 87 88 159
		f 4 185 310 -191 186
		mu 0 4 111 161 164 113
		f 4 187 311 -193 -311
		mu 0 4 160 159 162 163
		f 4 188 189 -194 -312
		mu 0 4 159 88 89 162
		f 4 190 312 -196 191
		mu 0 4 113 164 167 115
		f 4 192 313 -198 -313
		mu 0 4 163 162 165 166
		f 4 193 194 -199 -314
		mu 0 4 162 89 90 165
		f 4 195 314 -201 196
		mu 0 4 115 167 170 117
		f 4 197 315 -203 -315
		mu 0 4 166 165 168 169
		f 4 198 199 -204 -316
		mu 0 4 165 90 91 168
		f 4 200 316 -206 201
		mu 0 4 117 170 173 119
		f 4 202 317 -208 -317
		mu 0 4 169 168 171 172
		f 4 203 204 -209 -318
		mu 0 4 168 91 92 171
		f 4 205 318 -211 206
		mu 0 4 119 173 176 121
		f 4 207 319 -213 -319
		mu 0 4 172 171 174 175
		f 4 208 209 -214 -320
		mu 0 4 171 92 93 174
		f 4 210 320 -216 211
		mu 0 4 121 176 179 123
		f 4 212 321 -218 -321
		mu 0 4 175 174 177 178
		f 4 213 214 -219 -322
		mu 0 4 174 93 94 177
		f 4 215 322 -221 216
		mu 0 4 123 179 182 125
		f 4 217 323 -223 -323
		mu 0 4 178 177 180 181
		f 4 218 219 -224 -324
		mu 0 4 177 94 95 180
		f 4 220 324 -226 221
		mu 0 4 125 182 185 127
		f 4 222 325 -228 -325
		mu 0 4 181 180 183 184
		f 4 223 224 -229 -326
		mu 0 4 180 95 96 183
		f 4 225 326 -231 226
		mu 0 4 127 185 188 129
		f 4 227 327 -233 -327
		mu 0 4 184 183 186 187
		f 4 228 229 -234 -328
		mu 0 4 183 96 97 186
		f 4 230 328 -236 231
		mu 0 4 129 188 191 131
		f 4 232 329 -238 -329
		mu 0 4 187 186 189 190
		f 4 233 234 -239 -330
		mu 0 4 186 97 98 189
		f 4 235 330 -241 236
		mu 0 4 131 191 194 133
		f 4 237 331 -243 -331
		mu 0 4 190 189 192 193
		f 4 238 239 -244 -332
		mu 0 4 189 98 99 192
		f 4 240 332 -246 241
		mu 0 4 133 194 197 135
		f 4 242 333 -248 -333
		mu 0 4 193 192 195 196
		f 4 243 244 -249 -334
		mu 0 4 192 99 100 195
		f 4 245 334 -251 246
		mu 0 4 135 197 200 137
		f 4 247 335 -253 -335
		mu 0 4 196 195 198 199
		f 4 248 249 -254 -336
		mu 0 4 195 100 101 198
		f 4 250 336 -256 251
		mu 0 4 137 200 203 139
		f 4 252 337 -258 -337
		mu 0 4 199 198 201 202
		f 4 253 254 -259 -338
		mu 0 4 198 101 102 201
		f 4 255 338 -165 256
		mu 0 4 139 203 205 141
		f 4 257 339 -163 -339
		mu 0 4 202 201 204 206
		f 4 258 259 -161 -340
		mu 0 4 201 102 104 204;
	setAttr ".cd" -type "dataPolyComponent" Index_Data Edge 0 ;
	setAttr ".cvd" -type "dataPolyComponent" Index_Data Vertex 0 ;
	setAttr ".pd[0]" -type "dataPolyComponent" Index_Data UV 0 ;
	setAttr ".hfd" -type "dataPolyComponent" Index_Data Face 0 ;
	setAttr ".dr" 1;
createNode transform -n "pSphere1" -p "Bob_Omb";
	rename -uid "94A00D65-3D4F-5A58-43F4-C1A40BB9F73A";
	setAttr ".t" -type "double3" 0.016341623486628265 -0.011451235170545138 6.7259572342894138 ;
	setAttr ".s" -type "double3" 0.7 0.7 0.7 ;
createNode mesh -n "pSphereShape1" -p "pSphere1";
	rename -uid "D348DB97-3148-6E1A-B522-C89404D260E5";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode transform -n "pCylinder4" -p "Bob_Omb";
	rename -uid "7914E417-4142-31AD-9D61-50ACE706D56F";
	setAttr ".t" -type "double3" 0.047199454889458592 -0.058435981475601945 7.5556682623871314 ;
	setAttr ".r" -type "double3" 85.78164791574946 7.1696618633050555 -110.79460248718969 ;
	setAttr ".s" -type "double3" 0.13 0.17 0.13 ;
createNode mesh -n "pCylinderShape4" -p "pCylinder4";
	rename -uid "A1F97EFD-614F-1013-503D-9EA199C2D624";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.44929546117782593 0.719704270362854 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode transform -n "pCylinder5" -p "Bob_Omb";
	rename -uid "9625254A-0A4D-12C3-E25C-7BBA99F6FEC0";
	setAttr ".t" -type "double3" 0.039996865592568764 0.18558928588386564 7.6671740479082899 ;
	setAttr ".r" -type "double3" -9.6261728809331082 83.090445836507271 81.237260523695468 ;
	setAttr ".s" -type "double3" 0.11550194817050076 0.079205424696518117 0.11550194817050076 ;
createNode mesh -n "pCylinderShape5" -p "pCylinder5";
	rename -uid "2961B09B-D74B-A729-49BF-918E8E0BBED7";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.49999988079071045 0.5 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr -s 46 ".pt";
	setAttr ".pt[20]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[21]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[22]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[23]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[24]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[25]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[26]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[27]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[28]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[29]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[30]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[31]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[32]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[33]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[34]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[35]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[36]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[37]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[38]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[39]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[53]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[55]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[57]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[59]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[61]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[63]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[65]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[67]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[69]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[71]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[73]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[75]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[77]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[79]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[93]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[95]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[149]" -type "float3" 0 4.7683716e-07 0 ;
	setAttr ".pt[151]" -type "float3" 0 -1.1920929e-07 0 ;
	setAttr ".pt[153]" -type "float3" 0 -1.1920929e-07 0 ;
	setAttr ".pt[155]" -type "float3" 0 -1.1920929e-07 0 ;
	setAttr ".pt[157]" -type "float3" 0 -1.1920929e-07 0 ;
	setAttr ".pt[159]" -type "float3" 0 -1.1920929e-07 0 ;
	setAttr ".pt[161]" -type "float3" 0 -1.1920929e-07 0 ;
	setAttr ".pt[163]" -type "float3" 0 -1.1920929e-07 0 ;
	setAttr ".pt[165]" -type "float3" 0 -1.1920929e-07 0 ;
	setAttr ".pt[175]" -type "float3" 0 4.7683716e-07 0 ;
createNode transform -n "pCylinder8" -p "Bob_Omb";
	rename -uid "2D980963-4929-0F97-2F56-88B3A7928B4E";
	setAttr ".t" -type "double3" 0.0044127317335124761 0.77863630487550251 6.8901601303090043 ;
	setAttr ".s" -type "double3" 0.06 0.23364535125876285 0.06 ;
createNode mesh -n "pCylinderShape8" -p "pCylinder8";
	rename -uid "1484FF9E-46C5-1468-6BAE-0C96D944809C";
	setAttr -k off ".v";
	setAttr -s 6 ".iog[0].og";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.5419166088104248 0.87636357545852661 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode mesh -n "pCylinderShape8Orig" -p "pCylinder8";
	rename -uid "20D9A494-4B18-859A-840E-3A8A27D351E8";
	setAttr -k off ".v";
	setAttr ".io" yes;
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode transform -n "pCylinder6" -p "Bob_Omb";
	rename -uid "41213292-B940-7CBB-EDD8-5FB6D0DC90A8";
	setAttr ".t" -type "double3" 0.18490968405779995 -0.29861497285529537 6.1635198737671217 ;
	setAttr ".r" -type "double3" 75.189277693786153 -36.333563737283441 -29.133209824750161 ;
	setAttr ".s" -type "double3" 0.07 0.25 0.07 ;
createNode mesh -n "pCylinderShape6" -p "pCylinder6";
	rename -uid "CF8E388E-274E-7EB5-F8D3-C4AD460DE533";
	setAttr -k off ".v";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.49999998509883881 0.75 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr ".dr" 1;
createNode transform -n "bend1Handle" -p "Bob_Omb";
	rename -uid "BF6120E5-4BD0-C58A-F4B3-D5B2DB4FEE59";
	setAttr ".t" -type "double3" 0.0044127245809551033 0.71851819662969585 6.9202206652927334 ;
	setAttr ".r" -type "double3" -31.396964729147491 -114.4789982662988 31.282659513840457 ;
	setAttr ".s" -type "double3" 0.25 0.25 0.25 ;
	setAttr ".smd" 7;
createNode deformBend -n "bend1HandleShape" -p "bend1Handle";
	rename -uid "FCDF7A77-441E-7539-69B5-96AF9CB3D97F";
	setAttr -k off ".v";
	setAttr ".dd" -type "doubleArray" 3 -1 1 0.69813170079773179 ;
	setAttr ".hw" 0.06600001966953313;
createNode lightLinker -s -n "lightLinker1";
	rename -uid "1AC4C2F1-ED4C-A63F-0CB3-878DB70093B9";
	setAttr -s 30 ".lnk";
	setAttr -s 30 ".slnk";
createNode shapeEditorManager -n "shapeEditorManager";
	rename -uid "0DB4653A-D349-8368-23C5-718698A3E72D";
createNode poseInterpolatorManager -n "poseInterpolatorManager";
	rename -uid "537AF358-A545-06E6-4A5C-0CB65523E96B";
createNode displayLayerManager -n "layerManager";
	rename -uid "21EFA51B-3644-17A6-7C74-219E02BCD391";
createNode displayLayer -n "defaultLayer";
	rename -uid "8651C55F-A247-D529-249D-1D98693D67F6";
	setAttr ".ufem" -type "stringArray" 0  ;
createNode renderLayerManager -n "renderLayerManager";
	rename -uid "3585A4A9-E74C-A404-25B4-149A3F709E03";
createNode renderLayer -n "defaultRenderLayer";
	rename -uid "94F6C942-7040-4D3C-F6C5-77886B8360D7";
	setAttr ".g" yes;
createNode polyBoolean -n "polyBoolean1";
	rename -uid "4FC66709-B842-171D-5872-8E97F16B9A3C";
	setAttr ".nio" 4;
	setAttr ".vs" 1.0750000476837158;
	setAttr ".mg" -type "Int32Array" 0 ;
createNode polyBoolean -n "polyBoolean2";
	rename -uid "E1D9BD33-D54C-DE71-6993-2F9E873DECC2";
	setAttr ".nio" 4;
	setAttr ".vs" 1.0750000476837158;
	setAttr ".mg" -type "Int32Array" 0 ;
createNode polyBoolean -n "polyBoolean3";
	rename -uid "619A797A-E148-8E88-BF7D-62AF52586561";
	setAttr ".nio" 4;
	setAttr ".nid" 4;
	setAttr ".vs" 1.0750000476837158;
	setAttr ".mg" -type "Int32Array" 0 ;
createNode polyBoolean -n "polyBoolean4";
	rename -uid "89CBE7E2-8C43-1BD8-7A63-59ADB86EEE72";
	setAttr ".nio" 4;
	setAttr ".nid" 4;
	setAttr ".vs" 1.0750000476837158;
	setAttr ".mg" -type "Int32Array" 0 ;
createNode polyBoolean -n "polyBoolean5";
	rename -uid "8E962670-5043-FF02-541F-C2A01F8A3E9D";
	setAttr ".nio" 4;
	setAttr ".nid" 4;
	setAttr ".vs" 1.0750000476837158;
	setAttr ".mg" -type "Int32Array" 0 ;
createNode polyBoolean -n "polyBoolean6";
	rename -uid "A65B7E0C-3944-87AB-A590-F487E8B83C3C";
	setAttr ".nio" 4;
	setAttr ".nid" 4;
	setAttr ".vs" 1.0750000476837158;
	setAttr ".mg" -type "Int32Array" 0 ;
createNode script -n "uiConfigurationScriptNode";
	rename -uid "9F9B819B-D047-F93C-8A56-13AE44EC60C0";
	setAttr ".b" -type "string" (
		"// Maya Mel UI Configuration File.\n//\n//  This script is machine generated.  Edit at your own risk.\n//\n//\n\nglobal string $gMainPane;\nif (`paneLayout -exists $gMainPane`) {\n\n\tglobal int $gUseScenePanelConfig;\n\tint    $useSceneConfig = $gUseScenePanelConfig;\n\tint    $nodeEditorPanelVisible = stringArrayContains(\"nodeEditorPanel1\", `getPanel -vis`);\n\tint    $nodeEditorWorkspaceControlOpen = (`workspaceControl -exists nodeEditorPanel1Window` && `workspaceControl -q -visible nodeEditorPanel1Window`);\n\tint    $menusOkayInPanels = `optionVar -q allowMenusInPanels`;\n\tint    $nVisPanes = `paneLayout -q -nvp $gMainPane`;\n\tint    $nPanes = 0;\n\tstring $editorName;\n\tstring $panelName;\n\tstring $itemFilterName;\n\tstring $panelConfig;\n\n\t//\n\t//  get current state of the UI\n\t//\n\tsceneUIReplacement -update $gMainPane;\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"modelPanel\" (localizedPanelLabel(\"Top View\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tmodelPanel -edit -l (localizedPanelLabel(\"Top View\")) -mbv $menusOkayInPanels  $panelName;\n"
		+ "\t\t$editorName = $panelName;\n        modelEditor -e \n            -camera \"|top\" \n            -useInteractiveMode 0\n            -displayLights \"default\" \n            -displayAppearance \"smoothShaded\" \n            -activeOnly 0\n            -ignorePanZoom 0\n            -wireframeOnShaded 0\n            -headsUpDisplay 1\n            -holdOuts 1\n            -selectionHiliteDisplay 1\n            -useDefaultMaterial 0\n            -bufferMode \"double\" \n            -twoSidedLighting 0\n            -backfaceCulling 0\n            -xray 0\n            -jointXray 0\n            -activeComponentsXray 0\n            -displayTextures 0\n            -smoothWireframe 0\n            -lineWidth 1\n            -textureAnisotropic 0\n            -textureHilight 1\n            -textureSampling 2\n            -textureDisplay \"modulate\" \n            -textureMaxSize 16384\n            -fogging 0\n            -fogSource \"fragment\" \n            -fogMode \"linear\" \n            -fogStart 0\n            -fogEnd 100\n            -fogDensity 0.1\n            -fogColor 0.5 0.5 0.5 1 \n"
		+ "            -depthOfFieldPreview 1\n            -maxConstantTransparency 1\n            -rendererName \"vp2Renderer\" \n            -objectFilterShowInHUD 1\n            -isFiltered 0\n            -colorResolution 256 256 \n            -bumpResolution 512 512 \n            -textureCompression 0\n            -transparencyAlgorithm \"frontAndBackCull\" \n            -transpInShadows 0\n            -cullingOverride \"none\" \n            -lowQualityLighting 0\n            -maximumNumHardwareLights 1\n            -occlusionCulling 0\n            -shadingModel 0\n            -useBaseRenderer 0\n            -useReducedRenderer 0\n            -smallObjectCulling 0\n            -smallObjectThreshold -1 \n            -interactiveDisableShadows 0\n            -interactiveBackFaceCull 0\n            -sortTransparent 1\n            -controllers 1\n            -nurbsCurves 1\n            -nurbsSurfaces 1\n            -polymeshes 1\n            -subdivSurfaces 1\n            -planes 1\n            -lights 1\n            -cameras 1\n            -controlVertices 1\n"
		+ "            -hulls 1\n            -grid 1\n            -imagePlane 1\n            -joints 1\n            -ikHandles 1\n            -deformers 1\n            -dynamics 1\n            -particleInstancers 1\n            -fluids 1\n            -hairSystems 1\n            -follicles 1\n            -nCloths 1\n            -nParticles 1\n            -nRigids 1\n            -dynamicConstraints 1\n            -locators 1\n            -manipulators 1\n            -pluginShapes 1\n            -dimensions 1\n            -handles 1\n            -pivots 1\n            -textures 1\n            -strokes 1\n            -motionTrails 1\n            -clipGhosts 1\n            -bluePencil 1\n            -greasePencils 0\n            -excludeObjectPreset \"All\" \n            -shadows 0\n            -captureSequenceNumber -1\n            -width 1\n            -height 1\n            -sceneRenderFilter 0\n            $editorName;\n        modelEditor -e -viewSelected 0 $editorName;\n        modelEditor -e \n            -pluginObjects \"gpuCacheDisplayFilter\" 1 \n            -pluginObjects \"mayaUsdProxyShapeBaseDisplayFilter\" 1 \n"
		+ "            $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"modelPanel\" (localizedPanelLabel(\"Side View\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tmodelPanel -edit -l (localizedPanelLabel(\"Side View\")) -mbv $menusOkayInPanels  $panelName;\n\t\t$editorName = $panelName;\n        modelEditor -e \n            -camera \"|side\" \n            -useInteractiveMode 0\n            -displayLights \"default\" \n            -displayAppearance \"smoothShaded\" \n            -activeOnly 0\n            -ignorePanZoom 0\n            -wireframeOnShaded 0\n            -headsUpDisplay 1\n            -holdOuts 1\n            -selectionHiliteDisplay 1\n            -useDefaultMaterial 0\n            -bufferMode \"double\" \n            -twoSidedLighting 0\n            -backfaceCulling 0\n            -xray 0\n            -jointXray 0\n            -activeComponentsXray 0\n            -displayTextures 0\n            -smoothWireframe 0\n            -lineWidth 1\n"
		+ "            -textureAnisotropic 0\n            -textureHilight 1\n            -textureSampling 2\n            -textureDisplay \"modulate\" \n            -textureMaxSize 16384\n            -fogging 0\n            -fogSource \"fragment\" \n            -fogMode \"linear\" \n            -fogStart 0\n            -fogEnd 100\n            -fogDensity 0.1\n            -fogColor 0.5 0.5 0.5 1 \n            -depthOfFieldPreview 1\n            -maxConstantTransparency 1\n            -rendererName \"vp2Renderer\" \n            -objectFilterShowInHUD 1\n            -isFiltered 0\n            -colorResolution 256 256 \n            -bumpResolution 512 512 \n            -textureCompression 0\n            -transparencyAlgorithm \"frontAndBackCull\" \n            -transpInShadows 0\n            -cullingOverride \"none\" \n            -lowQualityLighting 0\n            -maximumNumHardwareLights 1\n            -occlusionCulling 0\n            -shadingModel 0\n            -useBaseRenderer 0\n            -useReducedRenderer 0\n            -smallObjectCulling 0\n            -smallObjectThreshold -1 \n"
		+ "            -interactiveDisableShadows 0\n            -interactiveBackFaceCull 0\n            -sortTransparent 1\n            -controllers 1\n            -nurbsCurves 1\n            -nurbsSurfaces 1\n            -polymeshes 1\n            -subdivSurfaces 1\n            -planes 1\n            -lights 1\n            -cameras 1\n            -controlVertices 1\n            -hulls 1\n            -grid 1\n            -imagePlane 1\n            -joints 1\n            -ikHandles 1\n            -deformers 1\n            -dynamics 1\n            -particleInstancers 1\n            -fluids 1\n            -hairSystems 1\n            -follicles 1\n            -nCloths 1\n            -nParticles 1\n            -nRigids 1\n            -dynamicConstraints 1\n            -locators 1\n            -manipulators 1\n            -pluginShapes 1\n            -dimensions 1\n            -handles 1\n            -pivots 1\n            -textures 1\n            -strokes 1\n            -motionTrails 1\n            -clipGhosts 1\n            -bluePencil 1\n            -greasePencils 0\n"
		+ "            -excludeObjectPreset \"All\" \n            -shadows 0\n            -captureSequenceNumber -1\n            -width 1\n            -height 1\n            -sceneRenderFilter 0\n            $editorName;\n        modelEditor -e -viewSelected 0 $editorName;\n        modelEditor -e \n            -pluginObjects \"gpuCacheDisplayFilter\" 1 \n            -pluginObjects \"mayaUsdProxyShapeBaseDisplayFilter\" 1 \n            $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"modelPanel\" (localizedPanelLabel(\"Front View\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tmodelPanel -edit -l (localizedPanelLabel(\"Front View\")) -mbv $menusOkayInPanels  $panelName;\n\t\t$editorName = $panelName;\n        modelEditor -e \n            -camera \"|front\" \n            -useInteractiveMode 0\n            -displayLights \"default\" \n            -displayAppearance \"smoothShaded\" \n            -activeOnly 0\n            -ignorePanZoom 0\n            -wireframeOnShaded 0\n"
		+ "            -headsUpDisplay 1\n            -holdOuts 1\n            -selectionHiliteDisplay 1\n            -useDefaultMaterial 0\n            -bufferMode \"double\" \n            -twoSidedLighting 0\n            -backfaceCulling 0\n            -xray 0\n            -jointXray 0\n            -activeComponentsXray 0\n            -displayTextures 0\n            -smoothWireframe 0\n            -lineWidth 1\n            -textureAnisotropic 0\n            -textureHilight 1\n            -textureSampling 2\n            -textureDisplay \"modulate\" \n            -textureMaxSize 16384\n            -fogging 0\n            -fogSource \"fragment\" \n            -fogMode \"linear\" \n            -fogStart 0\n            -fogEnd 100\n            -fogDensity 0.1\n            -fogColor 0.5 0.5 0.5 1 \n            -depthOfFieldPreview 1\n            -maxConstantTransparency 1\n            -rendererName \"vp2Renderer\" \n            -objectFilterShowInHUD 1\n            -isFiltered 0\n            -colorResolution 256 256 \n            -bumpResolution 512 512 \n            -textureCompression 0\n"
		+ "            -transparencyAlgorithm \"frontAndBackCull\" \n            -transpInShadows 0\n            -cullingOverride \"none\" \n            -lowQualityLighting 0\n            -maximumNumHardwareLights 1\n            -occlusionCulling 0\n            -shadingModel 0\n            -useBaseRenderer 0\n            -useReducedRenderer 0\n            -smallObjectCulling 0\n            -smallObjectThreshold -1 \n            -interactiveDisableShadows 0\n            -interactiveBackFaceCull 0\n            -sortTransparent 1\n            -controllers 1\n            -nurbsCurves 1\n            -nurbsSurfaces 1\n            -polymeshes 1\n            -subdivSurfaces 1\n            -planes 1\n            -lights 1\n            -cameras 1\n            -controlVertices 1\n            -hulls 1\n            -grid 1\n            -imagePlane 1\n            -joints 1\n            -ikHandles 1\n            -deformers 1\n            -dynamics 1\n            -particleInstancers 1\n            -fluids 1\n            -hairSystems 1\n            -follicles 1\n            -nCloths 1\n"
		+ "            -nParticles 1\n            -nRigids 1\n            -dynamicConstraints 1\n            -locators 1\n            -manipulators 1\n            -pluginShapes 1\n            -dimensions 1\n            -handles 1\n            -pivots 1\n            -textures 1\n            -strokes 1\n            -motionTrails 1\n            -clipGhosts 1\n            -bluePencil 1\n            -greasePencils 0\n            -excludeObjectPreset \"All\" \n            -shadows 0\n            -captureSequenceNumber -1\n            -width 1\n            -height 1\n            -sceneRenderFilter 0\n            $editorName;\n        modelEditor -e -viewSelected 0 $editorName;\n        modelEditor -e \n            -pluginObjects \"gpuCacheDisplayFilter\" 1 \n            -pluginObjects \"mayaUsdProxyShapeBaseDisplayFilter\" 1 \n            $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"modelPanel\" (localizedPanelLabel(\"Persp View\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n"
		+ "\t\tmodelPanel -edit -l (localizedPanelLabel(\"Persp View\")) -mbv $menusOkayInPanels  $panelName;\n\t\t$editorName = $panelName;\n        modelEditor -e \n            -camera \"|persp\" \n            -useInteractiveMode 0\n            -displayLights \"all\" \n            -displayAppearance \"smoothShaded\" \n            -activeOnly 0\n            -ignorePanZoom 0\n            -wireframeOnShaded 0\n            -headsUpDisplay 1\n            -holdOuts 1\n            -selectionHiliteDisplay 1\n            -useDefaultMaterial 0\n            -bufferMode \"double\" \n            -twoSidedLighting 0\n            -backfaceCulling 0\n            -xray 0\n            -jointXray 0\n            -activeComponentsXray 0\n            -displayTextures 1\n            -smoothWireframe 0\n            -lineWidth 1\n            -textureAnisotropic 0\n            -textureHilight 1\n            -textureSampling 2\n            -textureDisplay \"modulate\" \n            -textureMaxSize 16384\n            -fogging 0\n            -fogSource \"fragment\" \n            -fogMode \"linear\" \n"
		+ "            -fogStart 0\n            -fogEnd 100\n            -fogDensity 0.1\n            -fogColor 0.5 0.5 0.5 1 \n            -depthOfFieldPreview 1\n            -maxConstantTransparency 1\n            -rendererName \"vp2Renderer\" \n            -objectFilterShowInHUD 1\n            -isFiltered 0\n            -colorResolution 256 256 \n            -bumpResolution 512 512 \n            -textureCompression 0\n            -transparencyAlgorithm \"frontAndBackCull\" \n            -transpInShadows 0\n            -cullingOverride \"none\" \n            -lowQualityLighting 0\n            -maximumNumHardwareLights 1\n            -occlusionCulling 0\n            -shadingModel 0\n            -useBaseRenderer 0\n            -useReducedRenderer 0\n            -smallObjectCulling 0\n            -smallObjectThreshold -1 \n            -interactiveDisableShadows 0\n            -interactiveBackFaceCull 0\n            -sortTransparent 1\n            -controllers 1\n            -nurbsCurves 1\n            -nurbsSurfaces 1\n            -polymeshes 1\n            -subdivSurfaces 1\n"
		+ "            -planes 1\n            -lights 1\n            -cameras 1\n            -controlVertices 1\n            -hulls 1\n            -grid 1\n            -imagePlane 1\n            -joints 1\n            -ikHandles 1\n            -deformers 1\n            -dynamics 1\n            -particleInstancers 1\n            -fluids 1\n            -hairSystems 1\n            -follicles 1\n            -nCloths 1\n            -nParticles 1\n            -nRigids 1\n            -dynamicConstraints 1\n            -locators 1\n            -manipulators 1\n            -pluginShapes 1\n            -dimensions 1\n            -handles 1\n            -pivots 1\n            -textures 1\n            -strokes 1\n            -motionTrails 1\n            -clipGhosts 1\n            -bluePencil 1\n            -greasePencils 0\n            -excludeObjectPreset \"All\" \n            -shadows 0\n            -captureSequenceNumber -1\n            -width 1412\n            -height 1380\n            -sceneRenderFilter 0\n            $editorName;\n        modelEditor -e -viewSelected 0 $editorName;\n"
		+ "        modelEditor -e \n            -pluginObjects \"gpuCacheDisplayFilter\" 1 \n            -pluginObjects \"mayaUsdProxyShapeBaseDisplayFilter\" 1 \n            $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"outlinerPanel\" (localizedPanelLabel(\"ToggledOutliner\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\toutlinerPanel -edit -l (localizedPanelLabel(\"ToggledOutliner\")) -mbv $menusOkayInPanels  $panelName;\n\t\t$editorName = $panelName;\n        outlinerEditor -e \n            -showShapes 0\n            -showAssignedMaterials 0\n            -showTimeEditor 1\n            -showReferenceNodes 1\n            -showReferenceMembers 1\n            -showAttributes 0\n            -showConnected 0\n            -showAnimCurvesOnly 0\n            -showMuteInfo 0\n            -organizeByLayer 1\n            -organizeByClip 1\n            -showAnimLayerWeight 1\n            -autoExpandLayers 1\n            -autoExpand 0\n            -showDagOnly 1\n"
		+ "            -showAssets 1\n            -showContainedOnly 1\n            -showPublishedAsConnected 0\n            -showParentContainers 0\n            -showContainerContents 1\n            -ignoreDagHierarchy 0\n            -expandConnections 0\n            -showUpstreamCurves 1\n            -showUnitlessCurves 1\n            -showCompounds 1\n            -showLeafs 1\n            -showNumericAttrsOnly 0\n            -highlightActive 1\n            -autoSelectNewObjects 0\n            -doNotSelectNewObjects 0\n            -dropIsParent 1\n            -transmitFilters 0\n            -setFilter \"defaultSetFilter\" \n            -showSetMembers 1\n            -allowMultiSelection 1\n            -alwaysToggleSelect 0\n            -directSelect 0\n            -isSet 0\n            -isSetMember 0\n            -showUfeItems 1\n            -displayMode \"DAG\" \n            -expandObjects 0\n            -setsIgnoreFilters 1\n            -containersIgnoreFilters 0\n            -editAttrName 0\n            -showAttrValues 0\n            -highlightSecondary 0\n"
		+ "            -showUVAttrsOnly 0\n            -showTextureNodesOnly 0\n            -attrAlphaOrder \"default\" \n            -animLayerFilterOptions \"allAffecting\" \n            -sortOrder \"none\" \n            -longNames 0\n            -niceNames 1\n            -showNamespace 1\n            -showPinIcons 0\n            -mapMotionTrails 0\n            -ignoreHiddenAttribute 0\n            -ignoreOutlinerColor 0\n            -renderFilterVisible 0\n            -renderFilterIndex 0\n            -selectionOrder \"chronological\" \n            -expandAttribute 0\n            $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"outlinerPanel\" (localizedPanelLabel(\"Outliner\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\toutlinerPanel -edit -l (localizedPanelLabel(\"Outliner\")) -mbv $menusOkayInPanels  $panelName;\n\t\t$editorName = $panelName;\n        outlinerEditor -e \n            -showShapes 0\n            -showAssignedMaterials 0\n            -showTimeEditor 1\n"
		+ "            -showReferenceNodes 0\n            -showReferenceMembers 0\n            -showAttributes 0\n            -showConnected 0\n            -showAnimCurvesOnly 0\n            -showMuteInfo 0\n            -organizeByLayer 1\n            -organizeByClip 1\n            -showAnimLayerWeight 1\n            -autoExpandLayers 1\n            -autoExpand 0\n            -showDagOnly 1\n            -showAssets 1\n            -showContainedOnly 1\n            -showPublishedAsConnected 0\n            -showParentContainers 0\n            -showContainerContents 1\n            -ignoreDagHierarchy 0\n            -expandConnections 0\n            -showUpstreamCurves 1\n            -showUnitlessCurves 1\n            -showCompounds 1\n            -showLeafs 1\n            -showNumericAttrsOnly 0\n            -highlightActive 1\n            -autoSelectNewObjects 0\n            -doNotSelectNewObjects 0\n            -dropIsParent 1\n            -transmitFilters 0\n            -setFilter \"defaultSetFilter\" \n            -showSetMembers 1\n            -allowMultiSelection 1\n"
		+ "            -alwaysToggleSelect 0\n            -directSelect 0\n            -showUfeItems 1\n            -displayMode \"DAG\" \n            -expandObjects 0\n            -setsIgnoreFilters 1\n            -containersIgnoreFilters 0\n            -editAttrName 0\n            -showAttrValues 0\n            -highlightSecondary 0\n            -showUVAttrsOnly 0\n            -showTextureNodesOnly 0\n            -attrAlphaOrder \"default\" \n            -animLayerFilterOptions \"allAffecting\" \n            -sortOrder \"none\" \n            -longNames 0\n            -niceNames 1\n            -showNamespace 1\n            -showPinIcons 0\n            -mapMotionTrails 0\n            -ignoreHiddenAttribute 0\n            -ignoreOutlinerColor 0\n            -renderFilterVisible 0\n            $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"graphEditor\" (localizedPanelLabel(\"Graph Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Graph Editor\")) -mbv $menusOkayInPanels  $panelName;\n"
		+ "\n\t\t\t$editorName = ($panelName+\"OutlineEd\");\n            outlinerEditor -e \n                -showShapes 1\n                -showAssignedMaterials 0\n                -showTimeEditor 1\n                -showReferenceNodes 0\n                -showReferenceMembers 0\n                -showAttributes 1\n                -showConnected 1\n                -showAnimCurvesOnly 1\n                -showMuteInfo 0\n                -organizeByLayer 1\n                -organizeByClip 1\n                -showAnimLayerWeight 1\n                -autoExpandLayers 1\n                -autoExpand 1\n                -showDagOnly 0\n                -showAssets 1\n                -showContainedOnly 0\n                -showPublishedAsConnected 0\n                -showParentContainers 0\n                -showContainerContents 0\n                -ignoreDagHierarchy 0\n                -expandConnections 1\n                -showUpstreamCurves 1\n                -showUnitlessCurves 1\n                -showCompounds 0\n                -showLeafs 1\n                -showNumericAttrsOnly 1\n"
		+ "                -highlightActive 0\n                -autoSelectNewObjects 1\n                -doNotSelectNewObjects 0\n                -dropIsParent 1\n                -transmitFilters 1\n                -setFilter \"0\" \n                -showSetMembers 0\n                -allowMultiSelection 1\n                -alwaysToggleSelect 0\n                -directSelect 0\n                -showUfeItems 1\n                -displayMode \"DAG\" \n                -expandObjects 0\n                -setsIgnoreFilters 1\n                -containersIgnoreFilters 0\n                -editAttrName 0\n                -showAttrValues 0\n                -highlightSecondary 0\n                -showUVAttrsOnly 0\n                -showTextureNodesOnly 0\n                -attrAlphaOrder \"default\" \n                -animLayerFilterOptions \"allAffecting\" \n                -sortOrder \"none\" \n                -longNames 0\n                -niceNames 1\n                -showNamespace 1\n                -showPinIcons 1\n                -mapMotionTrails 1\n                -ignoreHiddenAttribute 0\n"
		+ "                -ignoreOutlinerColor 0\n                -renderFilterVisible 0\n                $editorName;\n\n\t\t\t$editorName = ($panelName+\"GraphEd\");\n            animCurveEditor -e \n                -displayValues 0\n                -snapTime \"integer\" \n                -snapValue \"none\" \n                -showPlayRangeShades \"on\" \n                -lockPlayRangeShades \"off\" \n                -smoothness \"fine\" \n                -resultSamples 1\n                -resultScreenSamples 0\n                -resultUpdate \"delayed\" \n                -showUpstreamCurves 1\n                -tangentScale 1\n                -tangentLineThickness 1\n                -keyMinScale 1\n                -stackedCurvesMin -1\n                -stackedCurvesMax 1\n                -stackedCurvesSpace 0.2\n                -preSelectionHighlight 0\n                -limitToSelectedCurves 0\n                -constrainDrag 0\n                -valueLinesToggle 0\n                -outliner \"graphEditor1OutlineEd\" \n                -highlightAffectedCurves 0\n                $editorName;\n"
		+ "\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"dopeSheetPanel\" (localizedPanelLabel(\"Dope Sheet\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Dope Sheet\")) -mbv $menusOkayInPanels  $panelName;\n\n\t\t\t$editorName = ($panelName+\"OutlineEd\");\n            outlinerEditor -e \n                -showShapes 1\n                -showAssignedMaterials 0\n                -showTimeEditor 1\n                -showReferenceNodes 0\n                -showReferenceMembers 0\n                -showAttributes 1\n                -showConnected 1\n                -showAnimCurvesOnly 1\n                -showMuteInfo 0\n                -organizeByLayer 1\n                -organizeByClip 1\n                -showAnimLayerWeight 1\n                -autoExpandLayers 1\n                -autoExpand 1\n                -showDagOnly 0\n                -showAssets 1\n                -showContainedOnly 0\n                -showPublishedAsConnected 0\n"
		+ "                -showParentContainers 0\n                -showContainerContents 0\n                -ignoreDagHierarchy 0\n                -expandConnections 1\n                -showUpstreamCurves 1\n                -showUnitlessCurves 0\n                -showCompounds 0\n                -showLeafs 1\n                -showNumericAttrsOnly 1\n                -highlightActive 0\n                -autoSelectNewObjects 0\n                -doNotSelectNewObjects 1\n                -dropIsParent 1\n                -transmitFilters 0\n                -setFilter \"0\" \n                -showSetMembers 1\n                -allowMultiSelection 1\n                -alwaysToggleSelect 0\n                -directSelect 0\n                -showUfeItems 1\n                -displayMode \"DAG\" \n                -expandObjects 0\n                -setsIgnoreFilters 1\n                -containersIgnoreFilters 0\n                -editAttrName 0\n                -showAttrValues 0\n                -highlightSecondary 0\n                -showUVAttrsOnly 0\n                -showTextureNodesOnly 0\n"
		+ "                -attrAlphaOrder \"default\" \n                -animLayerFilterOptions \"allAffecting\" \n                -sortOrder \"none\" \n                -longNames 0\n                -niceNames 1\n                -showNamespace 1\n                -showPinIcons 0\n                -mapMotionTrails 1\n                -ignoreHiddenAttribute 0\n                -ignoreOutlinerColor 0\n                -renderFilterVisible 0\n                $editorName;\n\n\t\t\t$editorName = ($panelName+\"DopeSheetEd\");\n            dopeSheetEditor -e \n                -displayValues 0\n                -snapTime \"none\" \n                -snapValue \"none\" \n                -outliner \"dopeSheetPanel1OutlineEd\" \n                -hierarchyBelow 0\n                -selectionWindow 0 0 0 0 \n                $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"timeEditorPanel\" (localizedPanelLabel(\"Time Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n"
		+ "\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Time Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"clipEditorPanel\" (localizedPanelLabel(\"Trax Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Trax Editor\")) -mbv $menusOkayInPanels  $panelName;\n\n\t\t\t$editorName = clipEditorNameFromPanel($panelName);\n            clipEditor -e \n                -displayValues 0\n                -snapTime \"none\" \n                -snapValue \"none\" \n                -initialized 0\n                -manageSequencer 0 \n                $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"sequenceEditorPanel\" (localizedPanelLabel(\"Sequencer\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Sequencer\")) -mbv $menusOkayInPanels  $panelName;\n"
		+ "\n\t\t\t$editorName = sequenceEditorNameFromPanel($panelName);\n            cameraSequencer -e \n                -displayValues 0\n                -snapTime \"none\" \n                -snapValue \"none\" \n                -initialized 0\n                -showThumbnail 1\n                $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"hyperGraphPanel\" (localizedPanelLabel(\"Hypergraph Hierarchy\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Hypergraph Hierarchy\")) -mbv $menusOkayInPanels  $panelName;\n\n\t\t\t$editorName = ($panelName+\"HyperGraphEd\");\n            hyperGraph -e \n                -graphLayoutStyle \"hierarchicalLayout\" \n                -orientation \"horiz\" \n                -mergeConnections 0\n                -zoom 1\n                -animateTransition 0\n                -showRelationships 1\n                -showShapes 0\n                -showDeformers 0\n                -showExpressions 0\n"
		+ "                -showConstraints 0\n                -showConnectionFromSelected 0\n                -showConnectionToSelected 0\n                -showConstraintLabels 0\n                -showUnderworld 0\n                -showInvisible 0\n                -transitionFrames 1\n                -opaqueContainers 0\n                -freeform 0\n                -imagePosition 0 0 \n                -imageScale 1\n                -imageEnabled 0\n                -graphType \"DAG\" \n                -heatMapDisplay 0\n                -updateSelection 1\n                -updateNodeAdded 1\n                -useDrawOverrideColor 0\n                -limitGraphTraversal -1\n                -range 0 0 \n                -iconSize \"smallIcons\" \n                -showCachedConnections 0\n                $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"hyperShadePanel\" (localizedPanelLabel(\"Hypershade\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n"
		+ "\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Hypershade\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"visorPanel\" (localizedPanelLabel(\"Visor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Visor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"nodeEditorPanel\" (localizedPanelLabel(\"Node Editor\")) `;\n\tif ($nodeEditorPanelVisible || $nodeEditorWorkspaceControlOpen) {\n\t\tif (\"\" == $panelName) {\n\t\t\tif ($useSceneConfig) {\n\t\t\t\t$panelName = `scriptedPanel -unParent  -type \"nodeEditorPanel\" -l (localizedPanelLabel(\"Node Editor\")) -mbv $menusOkayInPanels `;\n\n\t\t\t$editorName = ($panelName+\"NodeEditorEd\");\n            nodeEditor -e \n                -allAttributes 0\n                -allNodes 0\n                -autoSizeNodes 1\n"
		+ "                -consistentNameSize 1\n                -createNodeCommand \"nodeEdCreateNodeCommand\" \n                -connectNodeOnCreation 0\n                -connectOnDrop 0\n                -copyConnectionsOnPaste 0\n                -connectionStyle \"bezier\" \n                -defaultPinnedState 0\n                -additiveGraphingMode 0\n                -connectedGraphingMode 1\n                -settingsChangedCallback \"nodeEdSyncControls\" \n                -traversalDepthLimit -1\n                -keyPressCommand \"nodeEdKeyPressCommand\" \n                -nodeTitleMode \"name\" \n                -gridSnap 0\n                -gridVisibility 1\n                -crosshairOnEdgeDragging 0\n                -popupMenuScript \"nodeEdBuildPanelMenus\" \n                -showNamespace 1\n                -showShapes 1\n                -showSGShapes 0\n                -showTransforms 1\n                -useAssets 1\n                -syncedSelection 1\n                -extendToShapes 1\n                -showUnitConversions 0\n                -editorMode \"default\" \n"
		+ "                -hasWatchpoint 0\n                $editorName;\n\t\t\t}\n\t\t} else {\n\t\t\t$label = `panel -q -label $panelName`;\n\t\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Node Editor\")) -mbv $menusOkayInPanels  $panelName;\n\n\t\t\t$editorName = ($panelName+\"NodeEditorEd\");\n            nodeEditor -e \n                -allAttributes 0\n                -allNodes 0\n                -autoSizeNodes 1\n                -consistentNameSize 1\n                -createNodeCommand \"nodeEdCreateNodeCommand\" \n                -connectNodeOnCreation 0\n                -connectOnDrop 0\n                -copyConnectionsOnPaste 0\n                -connectionStyle \"bezier\" \n                -defaultPinnedState 0\n                -additiveGraphingMode 0\n                -connectedGraphingMode 1\n                -settingsChangedCallback \"nodeEdSyncControls\" \n                -traversalDepthLimit -1\n                -keyPressCommand \"nodeEdKeyPressCommand\" \n                -nodeTitleMode \"name\" \n                -gridSnap 0\n                -gridVisibility 1\n"
		+ "                -crosshairOnEdgeDragging 0\n                -popupMenuScript \"nodeEdBuildPanelMenus\" \n                -showNamespace 1\n                -showShapes 1\n                -showSGShapes 0\n                -showTransforms 1\n                -useAssets 1\n                -syncedSelection 1\n                -extendToShapes 1\n                -showUnitConversions 0\n                -editorMode \"default\" \n                -hasWatchpoint 0\n                $editorName;\n\t\t\tif (!$useSceneConfig) {\n\t\t\t\tpanel -e -l $label $panelName;\n\t\t\t}\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"createNodePanel\" (localizedPanelLabel(\"Create Node\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Create Node\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"polyTexturePlacementPanel\" (localizedPanelLabel(\"UV Editor\")) `;\n\tif (\"\" != $panelName) {\n"
		+ "\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"UV Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"renderWindowPanel\" (localizedPanelLabel(\"Render View\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Render View\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"shapePanel\" (localizedPanelLabel(\"Shape Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tshapePanel -edit -l (localizedPanelLabel(\"Shape Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"posePanel\" (localizedPanelLabel(\"Pose Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n"
		+ "\t\tposePanel -edit -l (localizedPanelLabel(\"Pose Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"dynRelEdPanel\" (localizedPanelLabel(\"Dynamic Relationships\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Dynamic Relationships\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"relationshipPanel\" (localizedPanelLabel(\"Relationship Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Relationship Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"referenceEditorPanel\" (localizedPanelLabel(\"Reference Editor\")) `;\n\tif (\"\" != $panelName) {\n"
		+ "\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Reference Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"dynPaintScriptedPanelType\" (localizedPanelLabel(\"Paint Effects\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Paint Effects\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"scriptEditorPanel\" (localizedPanelLabel(\"Script Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Script Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"profilerPanel\" (localizedPanelLabel(\"Profiler Tool\")) `;\n"
		+ "\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Profiler Tool\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"motionMakerEditorPanel\" (localizedPanelLabel(\"MotionMaker Editor\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"MotionMaker Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"contentBrowserPanel\" (localizedPanelLabel(\"Content Browser\")) `;\n\tif (\"\" != $panelName) {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Content Browser\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\tif ($useSceneConfig) {\n        string $configName = `getPanel -cwl (localizedPanelLabel(\"Current Layout\"))`;\n"
		+ "        if (\"\" != $configName) {\n\t\t\tpanelConfiguration -edit -label (localizedPanelLabel(\"Current Layout\")) \n\t\t\t\t-userCreated false\n\t\t\t\t-defaultImage \"\"\n\t\t\t\t-image \"\"\n\t\t\t\t-sc false\n\t\t\t\t-configString \"global string $gMainPane; paneLayout -e -cn \\\"single\\\" -ps 1 100 100 $gMainPane;\"\n\t\t\t\t-removeAllPanels\n\t\t\t\t-ap false\n\t\t\t\t\t(localizedPanelLabel(\"Persp View\")) \n\t\t\t\t\t\"modelPanel\"\n"
		+ "\t\t\t\t\t\"$panelName = `modelPanel -unParent -l (localizedPanelLabel(\\\"Persp View\\\")) -mbv $menusOkayInPanels `;\\n$editorName = $panelName;\\nmodelEditor -e \\n    -cam `findStartUpCamera persp` \\n    -useInteractiveMode 0\\n    -displayLights \\\"all\\\" \\n    -displayAppearance \\\"smoothShaded\\\" \\n    -activeOnly 0\\n    -ignorePanZoom 0\\n    -wireframeOnShaded 0\\n    -headsUpDisplay 1\\n    -holdOuts 1\\n    -selectionHiliteDisplay 1\\n    -useDefaultMaterial 0\\n    -bufferMode \\\"double\\\" \\n    -twoSidedLighting 0\\n    -backfaceCulling 0\\n    -xray 0\\n    -jointXray 0\\n    -activeComponentsXray 0\\n    -displayTextures 1\\n    -smoothWireframe 0\\n    -lineWidth 1\\n    -textureAnisotropic 0\\n    -textureHilight 1\\n    -textureSampling 2\\n    -textureDisplay \\\"modulate\\\" \\n    -textureMaxSize 16384\\n    -fogging 0\\n    -fogSource \\\"fragment\\\" \\n    -fogMode \\\"linear\\\" \\n    -fogStart 0\\n    -fogEnd 100\\n    -fogDensity 0.1\\n    -fogColor 0.5 0.5 0.5 1 \\n    -depthOfFieldPreview 1\\n    -maxConstantTransparency 1\\n    -rendererName \\\"vp2Renderer\\\" \\n    -objectFilterShowInHUD 1\\n    -isFiltered 0\\n    -colorResolution 256 256 \\n    -bumpResolution 512 512 \\n    -textureCompression 0\\n    -transparencyAlgorithm \\\"frontAndBackCull\\\" \\n    -transpInShadows 0\\n    -cullingOverride \\\"none\\\" \\n    -lowQualityLighting 0\\n    -maximumNumHardwareLights 1\\n    -occlusionCulling 0\\n    -shadingModel 0\\n    -useBaseRenderer 0\\n    -useReducedRenderer 0\\n    -smallObjectCulling 0\\n    -smallObjectThreshold -1 \\n    -interactiveDisableShadows 0\\n    -interactiveBackFaceCull 0\\n    -sortTransparent 1\\n    -controllers 1\\n    -nurbsCurves 1\\n    -nurbsSurfaces 1\\n    -polymeshes 1\\n    -subdivSurfaces 1\\n    -planes 1\\n    -lights 1\\n    -cameras 1\\n    -controlVertices 1\\n    -hulls 1\\n    -grid 1\\n    -imagePlane 1\\n    -joints 1\\n    -ikHandles 1\\n    -deformers 1\\n    -dynamics 1\\n    -particleInstancers 1\\n    -fluids 1\\n    -hairSystems 1\\n    -follicles 1\\n    -nCloths 1\\n    -nParticles 1\\n    -nRigids 1\\n    -dynamicConstraints 1\\n    -locators 1\\n    -manipulators 1\\n    -pluginShapes 1\\n    -dimensions 1\\n    -handles 1\\n    -pivots 1\\n    -textures 1\\n    -strokes 1\\n    -motionTrails 1\\n    -clipGhosts 1\\n    -bluePencil 1\\n    -greasePencils 0\\n    -excludeObjectPreset \\\"All\\\" \\n    -shadows 0\\n    -captureSequenceNumber -1\\n    -width 1412\\n    -height 1380\\n    -sceneRenderFilter 0\\n    $editorName;\\nmodelEditor -e -viewSelected 0 $editorName;\\nmodelEditor -e \\n    -pluginObjects \\\"gpuCacheDisplayFilter\\\" 1 \\n    -pluginObjects \\\"mayaUsdProxyShapeBaseDisplayFilter\\\" 1 \\n    $editorName\"\n"
		+ "\t\t\t\t\t\"modelPanel -edit -l (localizedPanelLabel(\\\"Persp View\\\")) -mbv $menusOkayInPanels  $panelName;\\n$editorName = $panelName;\\nmodelEditor -e \\n    -cam `findStartUpCamera persp` \\n    -useInteractiveMode 0\\n    -displayLights \\\"all\\\" \\n    -displayAppearance \\\"smoothShaded\\\" \\n    -activeOnly 0\\n    -ignorePanZoom 0\\n    -wireframeOnShaded 0\\n    -headsUpDisplay 1\\n    -holdOuts 1\\n    -selectionHiliteDisplay 1\\n    -useDefaultMaterial 0\\n    -bufferMode \\\"double\\\" \\n    -twoSidedLighting 0\\n    -backfaceCulling 0\\n    -xray 0\\n    -jointXray 0\\n    -activeComponentsXray 0\\n    -displayTextures 1\\n    -smoothWireframe 0\\n    -lineWidth 1\\n    -textureAnisotropic 0\\n    -textureHilight 1\\n    -textureSampling 2\\n    -textureDisplay \\\"modulate\\\" \\n    -textureMaxSize 16384\\n    -fogging 0\\n    -fogSource \\\"fragment\\\" \\n    -fogMode \\\"linear\\\" \\n    -fogStart 0\\n    -fogEnd 100\\n    -fogDensity 0.1\\n    -fogColor 0.5 0.5 0.5 1 \\n    -depthOfFieldPreview 1\\n    -maxConstantTransparency 1\\n    -rendererName \\\"vp2Renderer\\\" \\n    -objectFilterShowInHUD 1\\n    -isFiltered 0\\n    -colorResolution 256 256 \\n    -bumpResolution 512 512 \\n    -textureCompression 0\\n    -transparencyAlgorithm \\\"frontAndBackCull\\\" \\n    -transpInShadows 0\\n    -cullingOverride \\\"none\\\" \\n    -lowQualityLighting 0\\n    -maximumNumHardwareLights 1\\n    -occlusionCulling 0\\n    -shadingModel 0\\n    -useBaseRenderer 0\\n    -useReducedRenderer 0\\n    -smallObjectCulling 0\\n    -smallObjectThreshold -1 \\n    -interactiveDisableShadows 0\\n    -interactiveBackFaceCull 0\\n    -sortTransparent 1\\n    -controllers 1\\n    -nurbsCurves 1\\n    -nurbsSurfaces 1\\n    -polymeshes 1\\n    -subdivSurfaces 1\\n    -planes 1\\n    -lights 1\\n    -cameras 1\\n    -controlVertices 1\\n    -hulls 1\\n    -grid 1\\n    -imagePlane 1\\n    -joints 1\\n    -ikHandles 1\\n    -deformers 1\\n    -dynamics 1\\n    -particleInstancers 1\\n    -fluids 1\\n    -hairSystems 1\\n    -follicles 1\\n    -nCloths 1\\n    -nParticles 1\\n    -nRigids 1\\n    -dynamicConstraints 1\\n    -locators 1\\n    -manipulators 1\\n    -pluginShapes 1\\n    -dimensions 1\\n    -handles 1\\n    -pivots 1\\n    -textures 1\\n    -strokes 1\\n    -motionTrails 1\\n    -clipGhosts 1\\n    -bluePencil 1\\n    -greasePencils 0\\n    -excludeObjectPreset \\\"All\\\" \\n    -shadows 0\\n    -captureSequenceNumber -1\\n    -width 1412\\n    -height 1380\\n    -sceneRenderFilter 0\\n    $editorName;\\nmodelEditor -e -viewSelected 0 $editorName;\\nmodelEditor -e \\n    -pluginObjects \\\"gpuCacheDisplayFilter\\\" 1 \\n    -pluginObjects \\\"mayaUsdProxyShapeBaseDisplayFilter\\\" 1 \\n    $editorName\"\n"
		+ "\t\t\t\t$configName;\n\n            setNamedPanelLayout (localizedPanelLabel(\"Current Layout\"));\n        }\n\n        panelHistory -e -clear mainPanelHistory;\n        sceneUIReplacement -clear;\n\t}\n\n\ngrid -spacing 5 -size 12 -divisions 5 -displayAxes yes -displayGridLines yes -displayDivisionLines yes -displayPerspectiveLabels no -displayOrthographicLabels no -displayAxesBold yes -perspectiveLabelPosition axis -orthographicLabelPosition edge;\nviewManip -drawCompass 0 -compassAngle 0 -frontParameters \"\" -homeParameters \"\" -selectionLockParameters \"\";\n}\n");
	setAttr ".st" 3;
createNode script -n "sceneConfigurationScriptNode";
	rename -uid "43BE1C7F-704A-9542-4072-0BAE67166912";
	setAttr ".b" -type "string" "playbackOptions -min 1 -max 120 -ast 1 -aet 200 ";
	setAttr ".st" 6;
createNode polyCube -n "polyCube1";
	rename -uid "26A415DB-B84B-75FC-75D1-1AA89B25A342";
	setAttr ".sw" 2;
	setAttr ".sh" 2;
	setAttr ".sd" 2;
	setAttr ".cuv" 4;
createNode polyCylinder -n "polyCylinder1";
	rename -uid "C3258E98-4A46-44C7-1FCF-8FB54C8B37CA";
	setAttr ".r" 0.7;
	setAttr ".sc" 1;
	setAttr ".cuv" 3;
createNode polyBoolean -n "polyBoolean7";
	rename -uid "7384CA87-1245-A161-655D-01965D19EE0D";
	setAttr -s 2 ".ip";
	setAttr -s 2 ".im";
	setAttr ".op" -type "Int32Array" 2 2 2 ;
	setAttr ".nio" 4;
	setAttr ".nid" 4;
	setAttr ".ee" -type "Int32Array" 2 1 1 ;
	setAttr ".vs" 1.0750000476837158;
	setAttr ".mg" -type "Int32Array" 2 105 -107 ;
	setAttr ".gav" 16;
createNode groupId -n "groupId1";
	rename -uid "53CD6F8F-714A-8FEB-71EC-539AFDC130B8";
	setAttr ".ihi" 0;
createNode groupParts -n "groupParts1";
	rename -uid "13075616-0240-D5F2-149C-9B96F58AC8ED";
	setAttr ".ihi" 0;
	setAttr ".ic" -type "componentList" 1 "f[0:23]";
createNode groupId -n "groupId2";
	rename -uid "8554149F-4D46-5B28-6A5D-D0B97D0A9358";
	setAttr ".ihi" 0;
createNode groupId -n "groupId3";
	rename -uid "97801E29-4649-E024-CDFB-D581172E5A83";
	setAttr ".ihi" 0;
createNode groupParts -n "groupParts2";
	rename -uid "1AEF338C-6C4E-4D57-6609-A2A1C00C8FA4";
	setAttr ".ihi" 0;
	setAttr ".ic" -type "componentList" 1 "f[0:59]";
createNode groupId -n "groupId4";
	rename -uid "A13BFD62-BA48-BDB7-C224-64AA320A83EF";
	setAttr ".ihi" 0;
createNode groupId -n "groupId5";
	rename -uid "A811EBD8-A24A-D712-92A2-B59F59F6EBA2";
	setAttr ".ihi" 0;
createNode deleteComponent -n "deleteComponent1";
	rename -uid "35B820BB-1E42-D92E-8CD8-1D8EEDC4453B";
	setAttr ".dc" -type "componentList" 1 "f[24:43]";
createNode deleteComponent -n "deleteComponent2";
	rename -uid "535C67E9-3E45-CD8E-91FB-3E8DE7F2BECB";
	setAttr ".dc" -type "componentList" 1 "f[24:43]";
createNode oceanShader -n "oceanShader1";
	rename -uid "B782F433-7142-22B0-260D-009F0862FB55";
	setAttr -s 3 ".env";
	setAttr ".env[0].envp" 0.20000000298023224;
	setAttr ".env[0].envc" -type "float3" 0.015 0.13 0.145 ;
	setAttr ".env[0].envi" 2;
	setAttr ".env[1].envp" 0.55000001192092896;
	setAttr ".env[1].envc" -type "float3" 0.47999999 0.55000001 0.69999999 ;
	setAttr ".env[1].envi" 2;
	setAttr ".env[2].envp" 1;
	setAttr ".env[2].envc" -type "float3" 0 0.1 0.44999999 ;
	setAttr ".env[2].envi" 2;
	setAttr ".wh[0]"  0 0.16 1;
	setAttr ".wtb[0]"  0 1 1;
	setAttr -s 2 ".wp[0:1]"  0 0.30000001 1 1 0.5 1;
	setAttr ".d" -0.016852468252182007;
createNode lambert -n "lambert2";
	rename -uid "936D8DA1-384B-77B8-E714-30BC26225843";
createNode anisotropic -n "anisotropic1";
	rename -uid "5438CDE0-0E45-F46F-8BCD-568863313631";
createNode rampShader -n "rampShader1";
	rename -uid "66861EAF-0E41-A79F-72F9-20AC201C600D";
	setAttr -s 2 ".clr";
	setAttr ".clr[0].clrp" 0;
	setAttr ".clr[0].clrc" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".clr[0].clri" 1;
	setAttr ".clr[1].clrp" 0.24347800016403198;
	setAttr ".clr[1].clrc" -type "float3" 1 0 0.81029999 ;
	setAttr ".clr[1].clri" 1;
	setAttr ".it[0].itp" 0;
	setAttr ".it[0].itc" -type "float3" 0 0 0 ;
	setAttr ".it[0].iti" 1;
	setAttr ".ic[0].icp" 0;
	setAttr ".ic[0].icc" -type "float3" 0 0 0 ;
	setAttr ".ic[0].ici" 1;
	setAttr -s 2 ".sro[0:1]"  0 1 2 0.5 0.5 2;
	setAttr ".sc[0].scp" 0;
	setAttr ".sc[0].scc" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".sc[0].sci" 1;
	setAttr ".rfl[0]"  0 1 1;
	setAttr ".env[0].envp" 0;
	setAttr ".env[0].envc" -type "float3" 0 0 0 ;
	setAttr ".env[0].envi" 1;
createNode shadingEngine -n "rampShader1SG";
	rename -uid "4E793DDC-9945-E814-B498-74A702B00A35";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo4";
	rename -uid "0B59846B-2C4E-8688-7CB4-5593EC26BE3A";
createNode aiOptions -s -n "defaultArnoldRenderOptions";
	rename -uid "67E6B6C4-C144-C87B-A46A-648734CF9932";
	addAttr -ci true -sn "ARV_options" -ln "ARV_options" -dt "string";
	setAttr ".AA_samples" 8;
	setAttr ".GI_diffuse_samples" 4;
	setAttr ".GI_specular_samples" 5;
	setAttr ".GI_transmission_samples" 4;
	setAttr ".GI_sss_samples" 0;
	setAttr ".GI_volume_samples" 0;
	setAttr ".GI_diffuse_depth" 5;
	setAttr ".GI_specular_depth" 3;
	setAttr ".GI_transmission_depth" 0;
	setAttr ".GI_total_depth" 12;
	setAttr ".version" -type "string" "5.6.0";
	setAttr ".ARV_options" -type "string" "Test Resolution=100%;Camera=cameraShape1;Color Management.Gamma=1;Color Management.Exposure=1.6;Background.BG=BG Color;Background.Color=0 0 0;Background.Image=;Background.Scale=1 1;Background.Offset=0 0;Background.Apply Color Management=1;Foreground.Enable FG=0;Foreground.Image=;Foreground.Scale=1 1;Foreground.Offset=0 0;Foreground.Apply Color Management=1;Interactive.FPS=16";
createNode aiAOVFilter -s -n "defaultArnoldFilter";
	rename -uid "16D8F326-8448-E19C-B7B1-2DB9544CA7FB";
	setAttr ".ai_translator" -type "string" "gaussian";
createNode aiAOVDriver -s -n "defaultArnoldDriver";
	rename -uid "9C2E40FB-C145-0676-217D-34B32EC94949";
	setAttr ".ai_translator" -type "string" "tif";
	setAttr ".tiff_format" 1;
createNode aiAOVDriver -s -n "defaultArnoldDisplayDriver";
	rename -uid "0B524E19-F442-71A5-FDD0-1C995F151518";
	setAttr ".ai_translator" -type "string" "maya";
	setAttr ".output_mode" 0;
createNode aiImagerDenoiserOidn -s -n "defaultArnoldDenoiser";
	rename -uid "E38A1165-4B4E-B851-C4F5-AF8B45B81ED2";
	setAttr ".enable" no;
createNode MaterialXSurfaceShader -n "Standard_Surface1";
	rename -uid "72BD2B88-B449-66FF-A290-A899DAB6204F";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document1%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface1SG";
	rename -uid "DC50E648-0243-5162-2CDF-6DB9E4ADB424";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo5";
	rename -uid "5C64D15F-2847-CE0D-0A12-709205A252D0";
createNode MaterialXSurfaceShader -n "Standard_Surface2";
	rename -uid "1543F1FC-2242-0521-41F7-8C942E4B8449";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document2%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface2SG";
	rename -uid "9AF6E8EE-224D-6BE0-D6B9-76BEBE4876CE";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo6";
	rename -uid "8E014571-8443-2673-2548-19AA9151B882";
createNode groupId -n "pasted__groupId10";
	rename -uid "E98BE931-FB42-7DFF-B017-C79E8F836398";
	setAttr ".ihi" 0;
createNode groupId -n "pasted__groupId3";
	rename -uid "6C0FF81E-B141-CF1C-5A2F-CCBC06489BA8";
	setAttr ".ihi" 0;
createNode polySphere -n "polySphere1";
	rename -uid "A56CA3ED-D148-0FD1-C636-DC9636E7E9E9";
createNode polyCylinder -n "polyCylinder2";
	rename -uid "9FDBF2E7-364D-41CF-5E7F-F29477AB8849";
	setAttr ".sc" 1;
	setAttr ".cuv" 3;
createNode polyBevel3 -n "polyBevel1";
	rename -uid "0BD361DC-CD48-883F-46CF-A290CE1960DB";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "e[20:39]";
	setAttr ".ix" -type "matrix" 0.29894816277731873 0.022265741397370128 -0.011585885037025508 0
		 -0.0046514595604199536 0.068778877040914621 0.012158535970606227 0 0.015251185429484155 -0.051155438782189665 0.29521267321373101 0
		 -0.048446199986339256 0.68053397219860057 7.1024374600139986 1;
	setAttr ".ws" yes;
	setAttr ".oaf" yes;
	setAttr ".f" 0.099999999999999978;
	setAttr ".sg" 2;
	setAttr ".at" 180;
	setAttr ".sn" yes;
	setAttr ".mv" yes;
	setAttr ".mvt" 0.0001;
	setAttr ".sa" 30;
createNode polyBevel3 -n "polyBevel2";
	rename -uid "B31F4E74-CA46-3DEE-39B1-4B91D0483DA2";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "e[0:19]";
	setAttr ".ix" -type "matrix" 0.29894816277731873 0.022265741397370128 -0.011585885037025508 0
		 -0.0046514595604199536 0.068778877040914621 0.012158535970606227 0 0.015251185429484155 -0.051155438782189665 0.29521267321373101 0
		 -0.048446199986339256 0.82387595435206029 7.1024374600139986 1;
	setAttr ".ws" yes;
	setAttr ".oaf" yes;
	setAttr ".f" 0.099999999999999978;
	setAttr ".sg" 2;
	setAttr ".at" 180;
	setAttr ".sn" yes;
	setAttr ".mv" yes;
	setAttr ".mvt" 0.0001;
	setAttr ".sa" 30;
createNode polySphere -n "polySphere2";
	rename -uid "B878B22C-2A4E-462C-C3F4-1DBC109AEFAD";
createNode polyMirror -n "polyMirror1";
	rename -uid "84C1D834-5B43-B786-D5AC-CF86A73A775F";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[*]";
	setAttr ".ix" -type "matrix" 0.10583523234017266 -0.0017527834773752816 0.0085591697471270132 0
		 -0.0056540288347373437 0.14818988182165463 0.10025975148368792 0 -0.0058100729480755663 -0.042885708531006705 0.063059978361267963 0
		 -0.25394734034937272 0.4136418798049486 6.4762369954974899 1;
	setAttr ".ws" yes;
	setAttr ".ad" 0;
	setAttr ".mtt" 1;
	setAttr ".cm" yes;
	setAttr ".fnf" 400;
	setAttr ".lnf" 799;
createNode polyCylinder -n "polyCylinder4";
	rename -uid "D9E2BF75-7B4B-8D03-103A-FCAA6079EBC6";
	setAttr ".sc" 1;
	setAttr ".cuv" 3;
createNode polyBevel3 -n "polyBevel4";
	rename -uid "C44827ED-6640-D5FF-3543-BF90EF34105C";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "e[20:39]";
	setAttr ".ix" -type "matrix" -0.045791587039671004 -0.12058142101322943 -0.016225025818732967 0
		 0.0041780736603129476 -0.024220930710710249 0.1682138229040526 0 -0.1216261589763141 0.044911697410444595 0.0094877230345870988 0
		 0.030857831402830327 -0.046984746305056807 7.7669336132323199 1;
	setAttr ".ws" yes;
	setAttr ".oaf" yes;
	setAttr ".sg" 4;
	setAttr ".at" 180;
	setAttr ".sn" yes;
	setAttr ".mv" yes;
	setAttr ".mvt" 0.0001;
	setAttr ".sa" 30;
createNode polyTweak -n "polyTweak2";
	rename -uid "2EC3E64A-2947-692A-DD2A-B1937F746A8B";
	setAttr ".uopa" yes;
	setAttr -s 42 ".tk[0:41]" -type "float3"  0.0019586759 -0.0023822919
		 0.0039739893 0.0019490856 -0.0023706274 0.0039545312 0.0019490856 -0.0023706274 0.0039545312
		 0.0019586759 -0.0023822919 0.0039739893 0.0019736746 -0.0024005345 0.0040044202 0.0019926815
		 -0.0024236522 0.004042984 0.0020138905 -0.0024494482 0.0040860153 0.0020352493 -0.0024754263
		 0.0041293497 0.0020546445 -0.0024990162 0.0041687014 0.0020701236 -0.0025178432 0.0042001074
		 0.0020801022 -0.0025299799 0.004220353 0.0020835483 -0.0025341711 0.0042273444 0.0020835483
		 -0.0025341711 0.0042273444 0.0020801022 -0.0025299799 0.004220353 0.0020701236 -0.0025178432
		 0.0042001074 0.0020546445 -0.0024990162 0.0041687014 0.0020352493 -0.0024754263 0.0041293497
		 0.0020138905 -0.0024494482 0.0040860153 0.0019926815 -0.0024236522 0.004042984 0.0019736746
		 -0.0024005345 0.0040044202 0.0021990947 -0.0026747079 0.0044617788 0.0021887412 -0.002662115
		 0.0044407723 0.0021887412 -0.002662115 0.0044407723 0.0021990947 -0.0026747079 0.0044617788
		 0.0022152858 -0.0026944005 0.0044946289 0.0022358 -0.0027193516 0.0045362506 0.0022586873
		 -0.0027471886 0.0045826868 0.0022817301 -0.0027752151 0.0046294387 0.0023026508 -0.0028006604
		 0.0046718852 0.0023193443 -0.0028209644 0.004705755 0.0023301046 -0.0028340518 0.0047275866
		 0.0023338201 -0.0028385709 0.0047351252 0.0023338201 -0.0028385709 0.0047351252 0.0023301046
		 -0.0028340518 0.0047275866 0.0023193443 -0.0028209644 0.004705755 0.0023026508 -0.0028006604
		 0.0046718852 0.0022817301 -0.0027752151 0.0046294387 0.0022586873 -0.0027471886 0.0045826868
		 0.0022358 -0.0027193516 0.0045362506 0.0022152858 -0.0026944005 0.0044946289 0.0020485234
		 -0.0024915712 0.0041562822 0.0022960489 -0.002792631 0.0046584909;
createNode polyCube -n "polyCube2";
	rename -uid "761E6AF4-364E-8D62-4B68-19B4A4CC26A5";
	setAttr ".cuv" 4;
createNode polySmoothFace -n "polySmoothFace1";
	rename -uid "7812523E-5E48-AE25-37B1-C18F36D96817";
	setAttr ".ics" -type "componentList" 1 "f[*]";
	setAttr ".sdt" 2;
	setAttr ".ovb" 2;
	setAttr ".suv" yes;
	setAttr ".ps" 0.10000000149011612;
	setAttr ".ro" 1;
	setAttr ".ma" yes;
	setAttr ".m08" yes;
createNode polyExtrudeFace -n "polyExtrudeFace3";
	rename -uid "EFC983A6-354B-EBDD-14EB-B0802A96BF8E";
	setAttr ".ics" -type "componentList" 1 "f[0:3]";
	setAttr ".ix" -type "matrix" 1 0 0 0 0 1 0 0 0 0 1 0 4.8632791960179578 0 2.3725197211636244 1;
	setAttr ".ws" yes;
	setAttr ".pvt" -type "float3" 4.8632793 0.0069441795 2.7614086 ;
	setAttr ".rs" 1875089601;
	setAttr ".c[0]"  0 1 1;
	setAttr ".cbn" -type "double3" 4.4882791960179578 -0.36111164093017578 2.6502973929775893 ;
	setAttr ".cbx" -type "double3" 5.2382791960179578 0.375 2.8725196317566573 ;
createNode polyTweak -n "polyTweak4";
	rename -uid "2F70A2DD-724A-6AFB-0653-8BAD60425CEE";
	setAttr ".uopa" yes;
	setAttr -s 15 ".tk";
	setAttr ".tk[0]" -type "float3" 0 -0.08333385 -8.9406967e-08 ;
	setAttr ".tk[1]" -type "float3" 0 0 -8.9406967e-08 ;
	setAttr ".tk[2]" -type "float3" 0 0 -8.9406967e-08 ;
	setAttr ".tk[3]" -type "float3" 0 0 -8.9406967e-08 ;
	setAttr ".tk[6]" -type "float3" 0 -0.083333291 0 ;
	setAttr ".tk[7]" -type "float3" 0 -0.055556014 0 ;
	setAttr ".tk[10]" -type "float3" 0 0.013888923 0 ;
	setAttr ".tk[12]" -type "float3" 0 0.04166602 0 ;
	setAttr ".tk[13]" -type "float3" 0 0.013888359 0 ;
	setAttr ".tk[14]" -type "float3" 0 0.013888359 -8.9406967e-08 ;
	setAttr ".tk[15]" -type "float3" 0 0 -8.9406967e-08 ;
	setAttr ".tk[16]" -type "float3" 0 0 -8.9406967e-08 ;
	setAttr ".tk[17]" -type "float3" 0 0 -8.9406967e-08 ;
	setAttr ".tk[20]" -type "float3" 0 0 -8.9406967e-08 ;
	setAttr ".tk[23]" -type "float3" 0 0.16666599 0 ;
createNode polyExtrudeFace -n "polyExtrudeFace4";
	rename -uid "53189320-F548-0156-5D53-F984FA822A3E";
	setAttr ".ics" -type "componentList" 1 "f[0:3]";
	setAttr ".ix" -type "matrix" 1 0 0 0 0 1 0 0 0 0 1 0 4.8632791960179578 0 2.3725197211636244 1;
	setAttr ".ws" yes;
	setAttr ".pvt" -type "float3" 4.8632793 0.0069441795 2.7614086 ;
	setAttr ".rs" 501546972;
	setAttr ".c[0]"  0 1 1;
	setAttr ".cbn" -type "double3" 4.4882791960179578 -0.36111164093017578 2.6502973929775893 ;
	setAttr ".cbx" -type "double3" 5.2382791960179578 0.375 2.8725197211636244 ;
createNode polyExtrudeFace -n "polyExtrudeFace5";
	rename -uid "C3E9D6D3-0C4C-ABF1-2EFF-C189E00B754F";
	setAttr ".ics" -type "componentList" 5 "f[12:15]" "f[24]" "f[26]" "f[32]" "f[34]";
	setAttr ".ix" -type "matrix" 1 0 0 0 0 1 0 0 0 0 1 0 4.8632791960179578 0 2.3725197211636244 1;
	setAttr ".ws" yes;
	setAttr ".pvt" -type "float3" 4.8632793 -0.31944472 2.6531074 ;
	setAttr ".rs" 175452021;
	setAttr ".lt" -type "double3" 1.4667391921244916e-16 -8.2225892761300656e-16 0.078629127968942336 ;
	setAttr ".c[0]"  0 1 1;
	setAttr ".cbn" -type "double3" 4.4882791960179578 -0.36111164093017578 1.9975197211636244 ;
	setAttr ".cbx" -type "double3" 5.2382791960179578 -0.27777779102325439 3.3086953059567152 ;
createNode polyTweak -n "polyTweak5";
	rename -uid "DAD0E73F-C041-B088-22D2-18827063969C";
	setAttr ".uopa" yes;
	setAttr -s 9 ".tk[33:41]" -type "float3"  0 0 0.56117558 0 0 0.56117558
		 0 0 0.56117558 0 0 0.56117558 0 0 0.56117558 0 0 0.56117558 0 0 0.56117558 0 0 0.56117558
		 0 0 0.56117558;
createNode polyCylinder -n "polyCylinder6";
	rename -uid "6C0B5106-0B4C-2234-213B-E48581FDB5B5";
	setAttr ".sc" 1;
	setAttr ".cuv" 3;
createNode polyBevel3 -n "polyBevel7";
	rename -uid "BA42D8DA-BD40-89D1-83AE-C1A2A44AE580";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "e[20:39]";
	setAttr ".ix" -type "matrix" 0.10000000000000001 0 0 0 0 0.25 0 0 0 0 0.10000000000000001 0
		 4.801077654566817 0.7698615121827157 2.6872442613935905 1;
	setAttr ".ws" yes;
	setAttr ".oaf" yes;
	setAttr ".f" 0.19999999999999998;
	setAttr ".sg" 3;
	setAttr ".at" 180;
	setAttr ".sn" yes;
	setAttr ".mv" yes;
	setAttr ".mvt" 0.0001;
	setAttr ".sa" 30;
createNode polyBevel3 -n "polyBevel8";
	rename -uid "915F77F4-DC46-20BC-95F0-0DBA235A0BB5";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "e[0:19]";
	setAttr ".ix" -type "matrix" 0.10000000000000001 0 0 0 0 0.25 0 0 0 0 0.10000000000000001 0
		 4.801077654566817 0.7698615121827157 2.6872442613935905 1;
	setAttr ".ws" yes;
	setAttr ".oaf" yes;
	setAttr ".f" 0.19999999999999998;
	setAttr ".sg" 3;
	setAttr ".at" 180;
	setAttr ".sn" yes;
	setAttr ".mv" yes;
	setAttr ".mvt" 0.0001;
	setAttr ".sa" 30;
createNode polyCylinder -n "polyCylinder5";
	rename -uid "1E99B4B2-3345-060B-ABE6-B4979F3C0A91";
	setAttr ".sc" 1;
	setAttr ".cuv" 3;
createNode polyExtrudeFace -n "polyExtrudeFace1";
	rename -uid "20D82DF3-4048-A0D5-02E2-688EB53D3031";
	setAttr ".ics" -type "componentList" 1 "f[0:19]";
	setAttr ".ix" -type "matrix" 0 5.5511151231257827e-17 -0.25 0 -0.13 2.8865798640254071e-17 0 0
		 5.5511151231257827e-17 0.25 5.5511151231257827e-17 0 0.85446164398484203 0.21308682596393835 8.1255951849416537 1;
	setAttr ".ws" yes;
	setAttr ".pvt" -type "float3" 0.85446167 0.21308678 8.1255951 ;
	setAttr ".rs" 1169486606;
	setAttr ".lt" -type "double3" -4.4408920985006262e-16 -3.5943470422239443e-15 0.26528630409222065 ;
	setAttr ".ls" -type "double3" 1 1 1.206207922939408 ;
	setAttr ".c[0]"  0 1 1;
	setAttr ".cbn" -type "double3" 0.72446164398484192 -0.036913293245351253 7.8755951849416537 ;
	setAttr ".cbx" -type "double3" 0.98446164398484215 0.4630868557662608 8.3755952445462984 ;
createNode deleteComponent -n "deleteComponent3";
	rename -uid "CFB3D591-CB42-8BD6-6806-AFB9D684BA32";
	setAttr ".dc" -type "componentList" 1 "f[40:59]";
createNode deleteComponent -n "deleteComponent4";
	rename -uid "8BF79DEA-674F-7FAA-C60B-269C3B13EF40";
	setAttr ".dc" -type "componentList" 1 "f[20:39]";
createNode polyBridgeEdge -n "polyBridgeEdge1";
	rename -uid "EE3164C6-4D44-6889-F68A-709C5AEEB81B";
	setAttr ".ics" -type "componentList" 1 "e[0:39]";
	setAttr ".ix" -type "matrix" 0 3.3306690738754695e-17 -0.14999999999999999 0 -0.13 2.8865798640254071e-17 0 0
		 3.3306690738754695e-17 0.14999999999999999 3.3306690738754695e-17 0 0.85446164398484203 0.21308682596393835 8.1255951849416537 1;
	setAttr ".c[0]"  0 1 1;
	setAttr ".dv" 0;
	setAttr ".sv1" 1;
	setAttr ".sv2" 21;
	setAttr ".d" 1;
	setAttr ".sd" 1;
	setAttr ".td" 1;
createNode polyExtrudeFace -n "polyExtrudeFace2";
	rename -uid "D7CC8999-184E-BA4C-D560-A6993C0B1152";
	setAttr ".ics" -type "componentList" 2 "f[0:5]" "f[19]";
	setAttr ".ix" -type "matrix" 0 3.3306690738754695e-17 -0.14999999999999999 0 -0.13 2.8865798640254071e-17 0 0
		 3.3306690738754695e-17 0.14999999999999999 3.3306690738754695e-17 0 0.85446164398484203 0.21308682596393835 8.6895197149968926 1;
	setAttr ".ws" yes;
	setAttr ".pvt" -type "float3" 0.85446167 0.059480514 8.6262007 ;
	setAttr ".rs" 1644422121;
	setAttr ".c[0]"  0 1 1;
	setAttr ".cbn" -type "double3" 0.7244616284876344 -0.094125526788747249 8.3823076483465027 ;
	setAttr ".cbx" -type "double3" 0.98446165948204967 0.21308655886062405 8.8700938042856041 ;
createNode polyTweak -n "polyTweak3";
	rename -uid "0C8A7134-0A40-2B53-C168-3B870F940DD9";
	setAttr ".uopa" yes;
	setAttr -s 96 ".tk[0:95]" -type "float3"  7.4651325e-08 -1.7601997e-07
		 -5.2452087e-06 7.3050614e-09 -3.5949051e-07 -5.2750111e-06 3.0035153e-08 -3.5669655e-07
		 -4.2617321e-06 3.608875e-09 -3.6694109e-07 -4.3213367e-06 3.3527613e-08 -3.7066638e-07
		 -4.2319298e-06 2.910383e-11 -3.5762787e-07 -4.1723251e-06 -1.6615377e-07 -3.5949051e-07
		 -5.1856041e-06 1.1897646e-07 3.7252903e-09 5.2154064e-07 -1.3399404e-07 5.9604645e-08
		 5.0663948e-07 1.7735874e-07 1.0114163e-06 -5.8114529e-07 -9.4587449e-08 -2.9988587e-07
		 1.3709068e-06 -1.2468081e-07 0 4.9173832e-07 1.1525117e-07 -1.7508864e-07 7.4505806e-09
		 -3.5768608e-08 -1.8067658e-07 -9.4622374e-07 -1.1731754e-07 5.9604645e-08 7.4505806e-08
		 1.5832484e-07 -7.2643161e-08 -4.4703484e-07 -1.2863893e-07 8.251518e-07 -5.5134296e-07
		 1.7904676e-07 -2.970919e-07 -4.4703484e-07 -1.6778358e-07 -1.2107193e-07 1.4156103e-06
		 4.1123712e-08 -4.1443855e-07 -5.2452087e-06 7.4651325e-08 -1.1641532e-07 -5.2452087e-06
		 7.3050614e-09 -3.5949051e-07 -5.2750111e-06 3.0035153e-08 -3.5669655e-07 -4.2617321e-06
		 3.608875e-09 -3.0733645e-07 -4.3213367e-06 -2.6077032e-08 -3.1106174e-07 -4.2319298e-06
		 2.9831426e-08 -3.5762787e-07 -4.1723251e-06 -1.9595609e-07 -2.9988587e-07 -5.1856041e-06
		 8.9174137e-08 3.7252903e-09 5.2154064e-07 -1.3399404e-07 5.9604645e-08 5.0663948e-07
		 2.3696339e-07 1.0114163e-06 -5.8114529e-07 -1.5419209e-07 -2.9988587e-07 4.1723251e-07
		 -9.4878487e-08 -5.9604645e-08 1.4901161e-08 8.5448846e-08 -1.7508864e-07 -4.6938658e-07
		 -5.0669769e-08 -1.8067658e-07 -9.4622374e-07 -8.7515218e-08 5.9604645e-08 7.4505806e-08
		 1.8812716e-07 -7.2643161e-08 -4.4703484e-07 -1.2863893e-07 8.251518e-07 -5.5134296e-07
		 1.7904676e-07 -2.970919e-07 -4.4703484e-07 -1.6778358e-07 -1.2107193e-07 1.4156103e-06
		 4.1123712e-08 -4.1443855e-07 -5.2452087e-06 1.4930265e-08 5.3085387e-08 -9.5367432e-07
		 7.8201992e-08 3.7252903e-09 -9.2387199e-07 7.8201992e-08 3.7252903e-09 -9.2387199e-07
		 7.453491e-08 5.3085387e-08 -9.5367432e-07 -7.4505806e-09 6.4261258e-08 -1.9669533e-06
		 2.2351742e-08 6.4261258e-08 -1.013279e-06 4.8574293e-08 -1.2107193e-07 -9.8347664e-07
		 4.8574293e-08 -1.2107193e-07 -9.8347664e-07 4.8603397e-08 -1.1175871e-07 -9.5367432e-07
		 4.8603397e-08 -1.1175871e-07 -9.5367432e-07 2.264278e-08 6.6123903e-08 -9.8347664e-07
		 8.2247425e-08 6.6123903e-08 -9.8347664e-07 -2.8676004e-07 5.4016709e-08 -1.013279e-06
		 -3.4636469e-07 5.4016709e-08 -1.013279e-06 9.1560651e-08 -2.7939677e-09 -9.6857548e-07
		 9.1560651e-08 -2.7939677e-09 -9.6857548e-07 1.5096157e-07 5.3085387e-08 -7.4505806e-08
		 1.8076389e-07 5.3085387e-08 -7.4505806e-08 -7.6368451e-08 1.2433156e-07 -1.4603138e-06
		 -1.6577542e-07 1.2433156e-07 -1.4603138e-06 -5.0291419e-08 -1.7369166e-07 1.4603138e-06
		 -2.0489097e-08 -1.7369166e-07 1.4603138e-06 1.6213744e-07 5.3085387e-08 -5.2154064e-08
		 1.3233512e-07 5.3085387e-08 4.2468309e-07 -7.2352123e-08 1.1641532e-07 2.630055e-06
		 -5.7450961e-08 1.1641532e-07 2.1532178e-06 1.6586273e-07 5.4016709e-08 3.0472875e-06
		 1.9566505e-07 5.4016709e-08 2.5704503e-06 -1.002918e-07 -1.1269003e-07 -4.991889e-07
		 -8.5390639e-08 -1.1269003e-07 -4.991889e-07 -7.6193828e-08 -1.7136335e-07 5.0663948e-07
		 -7.6193828e-08 -1.7136335e-07 2.9802322e-08 1.7523416e-07 5.7742e-08 -1.013279e-06
		 2.0503649e-07 5.7742e-08 -1.013279e-06 1.0058284e-07 6.4261258e-08 9.0897083e-07
		 1.0058284e-07 6.4261258e-08 9.0897083e-07 -2.309971e-07 -2.3469329e-07 -1.4156103e-06
		 -2.9060175e-07 -2.3469329e-07 -1.4156103e-06 5.9633749e-08 1.7229468e-07 -1.9073486e-06
		 2.9831426e-08 1.1269003e-07 -1.9073486e-06 1.4930265e-08 5.3085387e-08 -1.80103934
		 4.839967e-08 3.7252903e-09 -1.23010361 4.839967e-08 3.7252903e-09 -1.23010361 1.4930265e-08
		 5.3085387e-08 -1.80103934 -7.4505806e-09 6.4261258e-08 -0.77700818 5.2154064e-08
		 6.4261258e-08 -0.77700818 4.8574293e-08 -1.2107193e-07 -0.48610216 4.8574293e-08
		 -1.2107193e-07 -0.48610216 7.8405719e-08 -1.1175871e-07 -0.38586318 4.8603397e-08
		 -1.1175871e-07 -0.38586318 2.264278e-08 6.6123903e-08 -0.48610312 8.2247425e-08 6.6123903e-08
		 -0.48610312 8.7311491e-11 1.73226e-07 -0.77700764 8.7311491e-11 1.1362135e-07 -0.77700764
		 7.4796844e-09 1.1269003e-07 -2.43392444 7.4796844e-09 1.1269003e-07 -2.43392444;
createNode deleteComponent -n "deleteComponent5";
	rename -uid "52FDF445-EF46-74C7-CD3E-32A6EB8763CD";
	setAttr ".dc" -type "componentList" 2 "f[0:5]" "f[19]";
createNode polyMirror -n "polyMirror2";
	rename -uid "97628D51-6948-3FFA-8828-63B3A95AB817";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[*]";
	setAttr ".ix" -type "matrix" 0 3.3306690738754695e-17 -0.14999999999999999 0 -0.13 2.8865798640254071e-17 0 0
		 3.3306690738754695e-17 0.14999999999999999 3.3306690738754695e-17 0 0.85446164398484203 0.21308682596393835 8.6895197149968926 1;
	setAttr ".ws" yes;
	setAttr ".p" -type "double3" 0.85446164398484203 -0.15200488531879175 8.6895197149968926 ;
	setAttr ".a" 1;
	setAttr ".ma" 0;
	setAttr ".mps" -0.3650917112827301;
	setAttr ".mtt" 1;
	setAttr ".cm" yes;
	setAttr ".fnf" 89;
	setAttr ".lnf" 177;
	setAttr ".pc" -type "double3" 0.85446164398484203 -0.15200488531879175 8.6895197149968926 ;
createNode polyBevel3 -n "polyBevel5";
	rename -uid "F389208C-E443-E607-92E8-35878B870670";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 85 "e[0:39]" "e[68]" "e[71]" "e[73]" "e[76]" "e[78]" "e[81]" "e[83]" "e[86]" "e[88]" "e[91]" "e[93]" "e[96]" "e[98]" "e[101]" "e[103]" "e[106]" "e[108]" "e[111]" "e[113]" "e[116]" "e[118]" "e[121]" "e[123]" "e[126]" "e[128]" "e[131]" "e[176]" "e[178]" "e[181]" "e[183]" "e[186]" "e[188]" "e[190]" "e[192:193]" "e[195:196]" "e[198:199]" "e[201:202]" "e[204:205]" "e[207:208]" "e[210:211]" "e[213:214]" "e[216:217]" "e[219:220]" "e[222:223]" "e[225:226]" "e[230]" "e[234]" "e[237]" "e[240]" "e[243]" "e[246]" "e[249]" "e[252]" "e[255]" "e[258]" "e[261]" "e[264]" "e[266]" "e[268]" "e[270]" "e[272]" "e[274]" "e[276]" "e[278]" "e[280]" "e[282]" "e[284]" "e[286]" "e[288]" "e[290]" "e[292]" "e[294]" "e[296]" "e[298]" "e[300]" "e[302]" "e[304]" "e[306]" "e[308]" "e[310]" "e[312]" "e[314]" "e[316:318]" "e[352:355]";
	setAttr ".ix" -type "matrix" 0 3.3306690738754695e-17 -0.14999999999999999 0 -0.13 2.8865798640254071e-17 0 0
		 3.3306690738754695e-17 0.14999999999999999 3.3306690738754695e-17 0 0.85446164398484203 0.21308682596393835 10.342044345855944 1;
	setAttr ".ws" yes;
	setAttr ".oaf" yes;
	setAttr ".f" 1;
	setAttr ".sg" 3;
	setAttr ".at" 180;
	setAttr ".sn" yes;
	setAttr ".mv" yes;
	setAttr ".mvt" 0.0001;
	setAttr ".sa" 30;
createNode polyBevel3 -n "polyBevel6";
	rename -uid "2264642E-1040-5971-073D-DBB8A618EFEC";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "e[*]";
	setAttr ".ix" -type "matrix" 0.0021450574417377307 0.012223912464729581 -0.11483324746695671 0
		 -0.10141250533628952 -0.0012156132353280935 -0.0020237623176455532 0 -0.0016199836464097347 0.11484493977061656 0.012194896196764702 0
		 0.023655242105940499 0.19704052105441078 7.9092959412585246 1;
	setAttr ".ws" yes;
	setAttr ".oaf" yes;
	setAttr ".f" 0;
	setAttr ".at" 180;
	setAttr ".sn" yes;
	setAttr ".mv" yes;
	setAttr ".mvt" 0.0001;
	setAttr ".sa" 30;
createNode MaterialXSurfaceShader -n "Standard_Surface3";
	rename -uid "DE4C0B7D-E64A-EA56-ABA4-CA954042ACEF";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document3%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface3SG";
	rename -uid "5D04B3C9-3F4A-5E58-063B-E9A3C26FEDFE";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo7";
	rename -uid "69E686DF-2D4B-CF0B-50BB-909E772A1685";
createNode MaterialXSurfaceShader -n "Standard_Surface4";
	rename -uid "D4BE3FE0-F24B-7368-CCCA-31BBAA451D3E";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document4%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface4SG";
	rename -uid "224703CC-FD4C-0C97-D016-FAAEE27F9B70";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo8";
	rename -uid "16F9DEB3-1D49-885D-F0B8-2482DD4EE900";
createNode MaterialXSurfaceShader -n "Standard_Surface5";
	rename -uid "FDCCA60A-4640-A019-0FD1-2380F4D32FCF";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document5%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface5SG";
	rename -uid "AA3B525C-DE46-2CCA-9131-C782707ED8A1";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo9";
	rename -uid "2C91D5B9-5F40-1868-83DD-5882885BD602";
createNode MaterialXSurfaceShader -n "Standard_Surface6";
	rename -uid "C2721997-6F43-DF97-7990-36BA8EA8036A";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document6%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface6SG";
	rename -uid "42F1EA5C-AA4D-57E1-9A22-7495C502D736";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo10";
	rename -uid "52C16981-F64F-1697-DE13-B3835E020DA2";
createNode MaterialXSurfaceShader -n "Standard_Surface7";
	rename -uid "1EC420CB-C241-F75E-D154-5A83E65095D8";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document7%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface7SG";
	rename -uid "881716B3-224D-5442-2025-FD8FCDD64D7A";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo11";
	rename -uid "0A3AAF73-5347-1626-B9BC-8F8DC63256A9";
createNode MaterialXSurfaceShader -n "Standard_Surface8";
	rename -uid "6F0A08DC-6842-3902-5B6D-C8BFCF9AFA0C";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document8%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface8SG";
	rename -uid "97385C4A-174F-528E-890A-3DA8737ACD9D";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo12";
	rename -uid "828A1D67-9448-D652-AA35-29A8A3943E2E";
createNode MaterialXSurfaceShader -n "Standard_Surface9";
	rename -uid "C723A876-D642-0CED-56F7-2382EA82DC9E";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document9%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface9SG";
	rename -uid "80C48A95-F744-D42A-90D2-55A9EB924F23";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo13";
	rename -uid "98C1AA44-B14B-E909-B074-34A5DD680D1B";
createNode MaterialXSurfaceShader -n "Standard_Surface10";
	rename -uid "DBE43FF8-4F4F-FD79-AA13-E9B64CC1B3A3";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document10%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface10SG";
	rename -uid "0B020F03-5143-631A-344C-B9BE12F7AFD8";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo14";
	rename -uid "91971995-CF4C-AED2-40BF-D0AB2E94A415";
createNode MaterialXSurfaceShader -n "Standard_Surface11";
	rename -uid "D62C703E-3447-3B75-1A72-FABA7E65FFF6";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document11%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface11SG";
	rename -uid "E8DA8EDC-604E-5CE3-2EED-1EB9B221A986";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo15";
	rename -uid "079095E1-1844-6AB2-30D3-2C90DAD97A41";
createNode MaterialXSurfaceShader -n "Standard_Surface12";
	rename -uid "23AC3611-5943-87DE-92D1-938F6C6DC97F";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document12%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface12SG";
	rename -uid "AC57E8FF-D541-3B36-B24A-5E99798A38F3";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo16";
	rename -uid "FEB337F9-5B46-75EF-1616-B4A74949FD46";
createNode MaterialXSurfaceShader -n "Standard_Surface13";
	rename -uid "27E57500-7C4E-4074-BFF8-ECB48C7849FD";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document13%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface13SG";
	rename -uid "BC24236D-D44F-71DD-347A-648280B0942E";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo17";
	rename -uid "16272585-E544-A833-3D64-B99CFD403884";
createNode animCurveTU -n "polySurface7_visibility";
	rename -uid "DCF84227-4CAF-8DF5-7E3A-2AA90A1519F3";
	setAttr ".tan" 9;
	setAttr ".wgt" no;
	setAttr ".ktv[0]"  1 1;
	setAttr ".kot[0]"  5;
	setAttr ".kox[0]"  0;
	setAttr ".koy[0]"  0;
	setAttr ".ots[0]"  9;
createNode animCurveTL -n "polySurface7_translateX";
	rename -uid "FD559C27-486C-1DAE-1456-228AA52BF71C";
	setAttr ".tan" 18;
	setAttr ".wgt" no;
	setAttr ".ktv[0]"  1 0;
createNode animCurveTL -n "polySurface7_translateY";
	rename -uid "B1EFDEE1-4FF5-7B8E-D8E3-E191D981F795";
	setAttr ".tan" 18;
	setAttr ".wgt" no;
	setAttr ".ktv[0]"  1 0;
createNode animCurveTL -n "polySurface7_translateZ";
	rename -uid "D6ACA173-4E25-E233-AF3E-6685C03E14F7";
	setAttr ".tan" 18;
	setAttr ".wgt" no;
	setAttr ".ktv[0]"  1 0;
createNode animCurveTA -n "polySurface7_rotateX";
	rename -uid "5DA6B9A6-4385-CA6D-5B45-FF954ED4A3C1";
	setAttr ".tan" 18;
	setAttr ".wgt" no;
	setAttr ".ktv[0]"  1 0;
createNode animCurveTA -n "polySurface7_rotateY";
	rename -uid "A8617FCC-40BB-E972-8401-83AF4A2533A0";
	setAttr ".tan" 18;
	setAttr ".wgt" no;
	setAttr ".ktv[0]"  1 0;
createNode animCurveTA -n "polySurface7_rotateZ";
	rename -uid "FCFE92BC-4C99-67EF-EBFF-1C99F6E8CD26";
	setAttr ".tan" 18;
	setAttr ".wgt" no;
	setAttr ".ktv[0]"  1 0;
createNode animCurveTU -n "polySurface7_scaleX";
	rename -uid "790C54B6-4ACB-DF4D-A86C-2C9FDE26348C";
	setAttr ".tan" 18;
	setAttr ".wgt" no;
	setAttr ".ktv[0]"  1 1;
createNode animCurveTU -n "polySurface7_scaleY";
	rename -uid "9026E454-4619-69A4-50B2-BA99606FDAD3";
	setAttr ".tan" 18;
	setAttr ".wgt" no;
	setAttr ".ktv[0]"  1 1;
createNode animCurveTU -n "polySurface7_scaleZ";
	rename -uid "2FF5E968-44FC-AFC8-C998-89B52D6771CF";
	setAttr ".tan" 18;
	setAttr ".wgt" no;
	setAttr ".ktv[0]"  1 1;
createNode transformGeometry -n "transformGeometry2";
	rename -uid "1082BA7B-41DE-C41D-CCEF-E7B7506A8AC2";
createNode polyCylinder -n "polyCylinder7";
	rename -uid "B57148F8-4161-5A50-E778-1ABF15852C0A";
	setAttr ".sh" 20;
	setAttr ".sc" 1;
	setAttr ".cuv" 3;
createNode nonLinear -n "bend1";
	rename -uid "542D217C-4CB1-D2CC-6117-21A0D3E23196";
	addAttr -is true -ci true -k true -sn "cur" -ln "curvature" -smn -3.14159 -smx 
		3.14159 -at "doubleAngle";
	addAttr -is true -ci true -k true -sn "lb" -ln "lowBound" -dv -1 -max 0 -smn -10 
		-smx 0 -at "double";
	addAttr -is true -ci true -k true -sn "hb" -ln "highBound" -dv 1 -min 0 -smn 0 -smx 
		10 -at "double";
	setAttr -k on ".cur" 40;
	setAttr -k on ".lb";
	setAttr -k on ".hb";
createNode MaterialXSurfaceShader -n "Standard_Surface14";
	rename -uid "B250B599-43A6-1F41-02C2-D7A24B13AA95";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document14%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface14SG";
	rename -uid "D7C31054-472D-D969-5071-D9A0961B6E01";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo18";
	rename -uid "5EDF9DBA-4616-EE85-1A05-1ABE94744846";
createNode MaterialXSurfaceShader -n "Standard_Surface15";
	rename -uid "BFE3E2B9-45E6-B6DC-9CD7-50852A5655A4";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document15%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface15SG";
	rename -uid "6C7EAABF-4990-FBBF-2325-0D8CDFB12C87";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo19";
	rename -uid "6F98CF25-4BBC-A777-ACCD-E6B42ABE3967";
createNode MaterialXSurfaceShader -n "Standard_Surface16";
	rename -uid "8A9992A6-4CEE-5689-DD60-EEA22910D114";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document16%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface16SG";
	rename -uid "31B5FD1E-482F-34E2-83C2-CBB8E394F517";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo20";
	rename -uid "41457E6C-4D82-F321-313C-8CA204C66E3D";
createNode MaterialXSurfaceShader -n "Standard_Surface17";
	rename -uid "F5069CCD-4FF5-6C10-FA59-7CBB28750D86";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document17%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface17SG";
	rename -uid "FE95F173-4A73-CE8A-D795-1B8AEB7321BE";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo21";
	rename -uid "70366B09-4CAA-64B8-679A-61AF28EE80E3";
createNode polyExtrudeFace -n "polyExtrudeFace6";
	rename -uid "AE6AC50B-46CE-2B05-8FAC-92951EBEF8CA";
	setAttr ".ics" -type "componentList" 7 "f[140:159]" "f[180:199]" "f[220:239]" "f[260:279]" "f[300:319]" "f[340:359]" "f[380:399]";
	setAttr ".ix" -type "matrix" 0.059999999999999998 0 0 0 0 0.23364535125876285 0 0
		 0 0 0.059999999999999998 0 -0.011928891753115789 0.79008754004604764 8.8605787842974113 1;
	setAttr ".ws" yes;
	setAttr ".pvt" -type "float3" -0.033666164 0.88956416 8.9142694 ;
	setAttr ".rs" 36398;
	setAttr ".c[0]"  0 1 1;
	setAttr ".cbn" -type "double3" -0.11536954841510309 0.71304592359370111 8.8003165858492309 ;
	setAttr ".cbx" -type "double3" 0.048037219430050709 1.0660823868739531 9.0282229130968492 ;
createNode polyExtrudeFace -n "polyExtrudeFace7";
	rename -uid "D09A447A-46EF-23D9-945C-81B66CCD5227";
	setAttr ".ics" -type "componentList" 7 "f[140:159]" "f[180:199]" "f[220:239]" "f[260:279]" "f[300:319]" "f[340:359]" "f[380:399]";
	setAttr ".ix" -type "matrix" 0.059999999999999998 0 0 0 0 0.23364535125876285 0 0
		 0 0 0.059999999999999998 0 -0.011928891753115789 0.79008754004604764 8.8605787842974113 1;
	setAttr ".ws" yes;
	setAttr ".pvt" -type "float3" -0.033666167 0.88956422 8.9142694 ;
	setAttr ".rs" 41203;
	setAttr ".c[0]"  0 1 1;
	setAttr ".cbn" -type "double3" -0.11536954841510309 0.71304592359370111 8.800316027949755 ;
	setAttr ".cbx" -type "double3" 0.048037215853772026 1.0660824704320422 9.0282228272661609 ;
createNode polyBevel3 -n "polyBevel9";
	rename -uid "63A6DB2C-4B48-B167-9156-C183DA1C895E";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 266 "e[1282]" "e[1286]" "e[1289]" "e[1292]" "e[1294]" "e[1297]" "e[1299]" "e[1302]" "e[1304]" "e[1307]" "e[1309]" "e[1312]" "e[1314]" "e[1317]" "e[1319]" "e[1322]" "e[1324]" "e[1327]" "e[1329]" "e[1332]" "e[1334]" "e[1337]" "e[1339]" "e[1342]" "e[1344]" "e[1347]" "e[1349]" "e[1352]" "e[1354]" "e[1357]" "e[1359]" "e[1362]" "e[1364]" "e[1367]" "e[1369]" "e[1372]" "e[1374]" "e[1377:1379]" "e[1382]" "e[1386]" "e[1389]" "e[1392]" "e[1394]" "e[1397]" "e[1399]" "e[1402]" "e[1404]" "e[1407]" "e[1409]" "e[1412]" "e[1414]" "e[1417]" "e[1419]" "e[1422]" "e[1424]" "e[1427]" "e[1429]" "e[1432]" "e[1434]" "e[1437]" "e[1439]" "e[1442]" "e[1444]" "e[1447]" "e[1449]" "e[1452]" "e[1454]" "e[1457]" "e[1459]" "e[1462]" "e[1464]" "e[1467]" "e[1469]" "e[1472]" "e[1474]" "e[1477:1479]" "e[1482]" "e[1486]" "e[1489]" "e[1492]" "e[1494]" "e[1497]" "e[1499]" "e[1502]" "e[1504]" "e[1507]" "e[1509]" "e[1512]" "e[1514]" "e[1517]" "e[1519]" "e[1522]" "e[1524]" "e[1527]" "e[1529]" "e[1532]" "e[1534]" "e[1537]" "e[1539]" "e[1542]" "e[1544]" "e[1547]" "e[1549]" "e[1552]" "e[1554]" "e[1557]" "e[1559]" "e[1562]" "e[1564]" "e[1567]" "e[1569]" "e[1572]" "e[1574]" "e[1577:1579]" "e[1582]" "e[1586]" "e[1589]" "e[1592]" "e[1594]" "e[1597]" "e[1599]" "e[1602]" "e[1604]" "e[1607]" "e[1609]" "e[1612]" "e[1614]" "e[1617]" "e[1619]" "e[1622]" "e[1624]" "e[1627]" "e[1629]" "e[1632]" "e[1634]" "e[1637]" "e[1639]" "e[1642]" "e[1644]" "e[1647]" "e[1649]" "e[1652]" "e[1654]" "e[1657]" "e[1659]" "e[1662]" "e[1664]" "e[1667]" "e[1669]" "e[1672]" "e[1674]" "e[1677:1679]" "e[1682]" "e[1686]" "e[1689]" "e[1692]" "e[1694]" "e[1697]" "e[1699]" "e[1702]" "e[1704]" "e[1707]" "e[1709]" "e[1712]" "e[1714]" "e[1717]" "e[1719]" "e[1722]" "e[1724]" "e[1727]" "e[1729]" "e[1732]" "e[1734]" "e[1737]" "e[1739]" "e[1742]" "e[1744]" "e[1747]" "e[1749]" "e[1752]" "e[1754]" "e[1757]" "e[1759]" "e[1762]" "e[1764]" "e[1767]" "e[1769]" "e[1772]" "e[1774]" "e[1777:1779]" "e[1782]" "e[1786]" "e[1789]" "e[1792]" "e[1794]" "e[1797]" "e[1799]" "e[1802]" "e[1804]" "e[1807]" "e[1809]" "e[1812]" "e[1814]" "e[1817]" "e[1819]" "e[1822]" "e[1824]" "e[1827]" "e[1829]" "e[1832]" "e[1834]" "e[1837]" "e[1839]" "e[1842]" "e[1844]" "e[1847]" "e[1849]" "e[1852]" "e[1854]" "e[1857]" "e[1859]" "e[1862]" "e[1864]" "e[1867]" "e[1869]" "e[1872]" "e[1874]" "e[1877:1879]" "e[1882]" "e[1886]" "e[1889]" "e[1892]" "e[1894]" "e[1897]" "e[1899]" "e[1902]" "e[1904]" "e[1907]" "e[1909]" "e[1912]" "e[1914]" "e[1917]" "e[1919]" "e[1922]" "e[1924]" "e[1927]" "e[1929]" "e[1932]" "e[1934]" "e[1937]" "e[1939]" "e[1942]" "e[1944]" "e[1947]" "e[1949]" "e[1952]" "e[1954]" "e[1957]" "e[1959]" "e[1962]" "e[1964]" "e[1967]" "e[1969]" "e[1972]" "e[1974]" "e[1977:1979]";
	setAttr ".ix" -type "matrix" 0.059999999999999998 0 0 0 0 0.23364535125876285 0 0
		 0 0 0.059999999999999998 0 -0.011928891753115789 0.79008754004604764 8.8605787842974113 1;
	setAttr ".ws" yes;
	setAttr ".oaf" yes;
	setAttr ".at" 180;
	setAttr ".sn" yes;
	setAttr ".mv" yes;
	setAttr ".mvt" 0.0001;
	setAttr ".sa" 30;
createNode polyExtrudeFace -n "polyExtrudeFace8";
	rename -uid "860C850D-4877-5AE9-0D1E-549EF687317B";
	setAttr ".ics" -type "componentList" 18 "f[583:585]" "f[587]" "f[589]" "f[591]" "f[593]" "f[595]" "f[597]" "f[599]" "f[601]" "f[603]" "f[605]" "f[607]" "f[609]" "f[611]" "f[613]" "f[615]" "f[617]" "f[619:859]";
	setAttr ".ix" -type "matrix" 0.059999999999999998 0 0 0 0 0.23364535125876285 0 0
		 0 0 0.059999999999999998 0 -0.011928891753115789 0.79008754004604764 8.8605787842974113 1;
	setAttr ".ws" yes;
	setAttr ".pvt" -type "float3" -0.033666167 0.90122724 8.9142685 ;
	setAttr ".rs" 45490;
	setAttr ".lt" -type "double3" -8.2572837456496018e-16 -2.7712207528729493e-16 -0.0093079592650622787 ;
	setAttr ".ls" -type "double3" 1 1 0.64912316177787388 ;
	setAttr ".c[0]"  0 1 1;
	setAttr ".cbn" -type "double3" -0.11536954841510309 0.7363717211895211 8.800313281367723 ;
	setAttr ".cbx" -type "double3" 0.048037215853772026 1.0660828046643982 9.0282228272661609 ;
createNode polyExtrudeFace -n "polyExtrudeFace9";
	rename -uid "D94D5631-474E-3896-1405-338CCB861B35";
	setAttr ".ics" -type "componentList" 18 "f[583:585]" "f[587]" "f[589]" "f[591]" "f[593]" "f[595]" "f[597]" "f[599]" "f[601]" "f[603]" "f[605]" "f[607]" "f[609]" "f[611]" "f[613]" "f[615]" "f[617]" "f[619:859]";
	setAttr ".ix" -type "matrix" 0.059999999999999998 0 0 0 0 0.23364535125876285 0 0
		 0 0 0.059999999999999998 0 -0.011928891753115789 0.79008754004604764 8.8605787842974113 1;
	setAttr ".ws" yes;
	setAttr ".pvt" -type "float3" -0.033803061 0.89823484 8.9152079 ;
	setAttr ".rs" 33936;
	setAttr ".lt" -type "double3" 1.457167719820518e-16 7.5162315607557595e-17 0.0032973626946060722 ;
	setAttr ".c[0]"  0 1 1;
	setAttr ".cbn" -type "double3" -0.10644890031711114 0.73640052087752672 8.8095042603716305 ;
	setAttr ".cbx" -type "double3" 0.038842782164654595 1.0600691847050943 9.0209114258989747 ;
createNode polySmartExtrude -n "polySmartExtrude1";
	rename -uid "C0591DC2-4D39-B3CE-ACAB-E2807176BE84";
	setAttr ".ics" -type "componentList" 18 "f[583:585]" "f[587]" "f[589]" "f[591]" "f[593]" "f[595]" "f[597]" "f[599]" "f[601]" "f[603]" "f[605]" "f[607]" "f[609]" "f[611]" "f[613]" "f[615]" "f[617]" "f[619:859]";
	setAttr ".ix" -type "matrix" 0.059999999999999998 0 0 0 0 0.23364535125876285 0 0
		 0 0 0.059999999999999998 0 -0.011928891753115789 0.79008754004604764 8.8605787842974113 1;
	setAttr ".ws" yes;
	setAttr ".gav" 16;
	setAttr ".cbn" -type "double3" -0.10960901460544123 0.73639021537988447 8.8062468140825683 ;
	setAttr ".cbx" -type "double3" 0.042100042487225396 1.0621990246880872 9.0235005372270987 ;
	setAttr ".pvt" -type "float3" -0.033754487 0.89929461 8.9148741 ;
	setAttr ".por" -type "double3" -53.940721028349863 -1.2293769140379507 -90.995758748940844 ;
	setAttr ".cpr" -type "double3" -53.940721028349863 -1.2293769140379507 -90.995758748940844 ;
createNode polyBevel3 -n "polyBevel10";
	rename -uid "2FAE0BE7-4B37-3EFD-3B52-92B7CD6E11BD";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 295 "e[261]" "e[264]" "e[266]" "e[268]" "e[270]" "e[272]" "e[274]" "e[276]" "e[278]" "e[280]" "e[282]" "e[284]" "e[286]" "e[288]" "e[290]" "e[292]" "e[294]" "e[296]" "e[298:299]" "e[1501]" "e[1504]" "e[1506]" "e[1508]" "e[1510:1511]" "e[1513:1514]" "e[1516]" "e[1518:1519]" "e[1521]" "e[1523:1524]" "e[1526]" "e[1528:1529]" "e[1531]" "e[1533:1534]" "e[1536]" "e[1538:1539]" "e[1541]" "e[1543:1544]" "e[1546]" "e[1548:1549]" "e[1551]" "e[1553:1554]" "e[1556]" "e[1558:1559]" "e[1561]" "e[1563:1564]" "e[1566]" "e[1568:1569]" "e[1571]" "e[1573:1574]" "e[1576]" "e[1578:1579]" "e[1581]" "e[1583:1584]" "e[1586]" "e[1588:1589]" "e[1591]" "e[1593:1594]" "e[1596:1599]" "e[1601]" "e[1603:1604]" "e[1606:1607]" "e[1609]" "e[1611]" "e[1613:1614]" "e[1616:1617]" "e[1619:1620]" "e[1622:1623]" "e[1625:1626]" "e[1628:1629]" "e[1631:1632]" "e[1634:1635]" "e[1637:1638]" "e[1640:1641]" "e[1643:1644]" "e[1646:1647]" "e[1649:1650]" "e[1652:1653]" "e[1655:1656]" "e[1658:1659]" "e[1661:1662]" "e[1664:1665]" "e[1667:1668]" "e[1670:1671]" "e[1673:1674]" "e[1676:1677]" "e[1679:1680]" "e[1682:1683]" "e[1685:1686]" "e[1688:1689]" "e[1691:1692]" "e[1694:1695]" "e[1697:1698]" "e[1700:1701]" "e[1703:1704]" "e[1706:1707]" "e[1709:1710]" "e[1712:1713]" "e[1715:1719]" "e[1721]" "e[1723:1724]" "e[1726:1727]" "e[1729]" "e[1731]" "e[1733:1734]" "e[1736:1737]" "e[1739:1740]" "e[1742:1743]" "e[1745:1746]" "e[1748:1749]" "e[1751:1752]" "e[1754:1755]" "e[1757:1758]" "e[1760:1761]" "e[1763:1764]" "e[1766:1767]" "e[1769:1770]" "e[1772:1773]" "e[1775:1776]" "e[1778:1779]" "e[1781:1782]" "e[1784:1785]" "e[1787:1788]" "e[1790:1791]" "e[1793:1794]" "e[1796:1797]" "e[1799:1800]" "e[1802:1803]" "e[1805:1806]" "e[1808:1809]" "e[1811:1812]" "e[1814:1815]" "e[1817:1818]" "e[1820:1821]" "e[1823:1824]" "e[1826:1827]" "e[1829:1830]" "e[1832:1833]" "e[1835:1839]" "e[1841]" "e[1843:1844]" "e[1846:1847]" "e[1849]" "e[1851]" "e[1853:1854]" "e[1856:1857]" "e[1859:1860]" "e[1862:1863]" "e[1865:1866]" "e[1868:1869]" "e[1871:1872]" "e[1874:1875]" "e[1877:1878]" "e[1880:1881]" "e[1883:1884]" "e[1886:1887]" "e[1889:1890]" "e[1892:1893]" "e[1895:1896]" "e[1898:1899]" "e[1901:1902]" "e[1904:1905]" "e[1907:1908]" "e[1910:1911]" "e[1913:1914]" "e[1916:1917]" "e[1919:1920]" "e[1922:1923]" "e[1925:1926]" "e[1928:1929]" "e[1931:1932]" "e[1934:1935]" "e[1937:1938]" "e[1940:1941]" "e[1943:1944]" "e[1946:1947]" "e[1949:1950]" "e[1952:1953]" "e[1955:1959]" "e[1961]" "e[1963:1964]" "e[1966:1967]" "e[1969]" "e[1971]" "e[1973:1974]" "e[1976:1977]" "e[1979:1980]" "e[1982:1983]" "e[1985:1986]" "e[1988:1989]" "e[1991:1992]" "e[1994:1995]" "e[1997:1998]" "e[2000:2001]" "e[2003:2004]" "e[2006:2007]" "e[2009:2010]" "e[2012:2013]" "e[2015:2016]" "e[2018:2019]" "e[2021:2022]" "e[2024:2025]" "e[2027:2028]" "e[2030:2031]" "e[2033:2034]" "e[2036:2037]" "e[2039:2040]" "e[2042:2043]" "e[2045:2046]" "e[2048:2049]" "e[2051:2052]" "e[2054:2055]" "e[2057:2058]" "e[2060:2061]" "e[2063:2064]" "e[2066:2067]" "e[2069:2070]" "e[2072:2073]" "e[2075:2079]" "e[2081]" "e[2083:2084]" "e[2086:2087]" "e[2089]" "e[2091]" "e[2093:2094]" "e[2096:2097]" "e[2099:2100]" "e[2102:2103]" "e[2105:2106]" "e[2108:2109]" "e[2111:2112]" "e[2114:2115]" "e[2117:2118]" "e[2120:2121]" "e[2123:2124]" "e[2126:2127]" "e[2129:2130]" "e[2132:2133]" "e[2135:2136]" "e[2138:2139]" "e[2141:2142]" "e[2144:2145]" "e[2147:2148]" "e[2150:2151]" "e[2153:2154]" "e[2156:2157]" "e[2159:2160]" "e[2162:2163]" "e[2165:2166]" "e[2168:2169]" "e[2171:2172]" "e[2174:2175]" "e[2177:2178]" "e[2180:2181]" "e[2183:2184]" "e[2186:2187]" "e[2189:2190]" "e[2192:2193]" "e[2195:2199]" "e[2211]" "e[2213:2214]" "e[2216:2217]" "e[2219]" "e[2223]" "e[2225]" "e[2229]" "e[2231]" "e[2235]" "e[2237]" "e[2241]" "e[2243]" "e[2247]" "e[2249]" "e[2253]" "e[2255]" "e[2259]" "e[2261]" "e[2265]" "e[2267]" "e[2271]" "e[2273]" "e[2277]" "e[2279]" "e[2283]" "e[2285]" "e[2289]" "e[2291]" "e[2295]" "e[2297]" "e[2301]" "e[2303]" "e[2307]" "e[2309]" "e[2313]" "e[2315]" "e[2318:2319]";
	setAttr ".ix" -type "matrix" 0.059999999999999998 0 0 0 0 0.23364535125876285 0 0
		 0 0 0.059999999999999998 0 -0.011928891753115789 0.79008754004604764 8.8605787842974113 1;
	setAttr ".ws" yes;
	setAttr ".oaf" yes;
	setAttr ".f" 1;
	setAttr ".sg" 3;
	setAttr ".d" 3;
	setAttr ".m" 2;
	setAttr ".at" 180;
	setAttr ".sn" yes;
	setAttr ".mv" yes;
	setAttr ".mvt" 0.0001;
	setAttr ".sa" 30;
createNode MaterialXSurfaceShader -n "Standard_Surface18";
	rename -uid "647643C4-4884-D016-8B8D-10B41964595C";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document18%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface18SG";
	rename -uid "24801C4A-4B81-0F2F-2199-0184967B4272";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo22";
	rename -uid "5923311F-46D0-B808-4739-79AC353C16B9";
createNode MaterialXSurfaceShader -n "Standard_Surface19";
	rename -uid "5CFABAC2-473F-223B-92E8-8A99DCD431E0";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document19%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface19SG";
	rename -uid "DAA95F7B-4BA9-C20D-FF40-038BA9FFAA81";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo23";
	rename -uid "99761799-4510-1B38-E929-F3912141019F";
createNode MaterialXSurfaceShader -n "Standard_Surface20";
	rename -uid "B38928AD-4F8A-B5D0-CEBE-39BC323A4AD6";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document20%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface20SG";
	rename -uid "8EBC08AB-42BB-89A6-CF22-5BBAE808782E";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo24";
	rename -uid "32572487-41FE-B8E2-A456-80A83EC66257";
createNode MaterialXSurfaceShader -n "Standard_Surface21";
	rename -uid "7351D758-4308-65B7-5304-E89A63A230C7";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document21%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface21SG";
	rename -uid "4DC751E7-4C12-E139-4169-72AD63337B5B";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo25";
	rename -uid "C87F461A-4980-0809-C52F-D7BEC0C05C50";
createNode aiStandardSurface -n "aiStandardSurface1";
	rename -uid "9E4CED1D-47A8-9563-C67D-829C80EFFD28";
createNode shadingEngine -n "aiStandardSurface1SG";
	rename -uid "AE61BE33-4D36-2EB3-CF83-F391095E028D";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo26";
	rename -uid "DAD5D7C3-45A1-E32E-A0E9-BBB59E3685A0";
createNode ramp -n "ramp1";
	rename -uid "7D2ADD9D-4243-1058-D890-429EB3933763";
	setAttr -s 2 ".cel";
	setAttr ".cel[0].ep" 0;
	setAttr ".cel[0].ec" -type "float3" 0 0 0 ;
	setAttr ".cel[1].ep" 1;
	setAttr ".cel[1].ec" -type "float3" 1 1 1 ;
createNode place2dTexture -n "place2dTexture1";
	rename -uid "23BBB470-4FF5-7ABB-1323-1094BFF188B6";
createNode shadingEngine -n "aiStandardSurface1SG1";
	rename -uid "5A446D1A-427F-105B-B6B8-61910F55D315";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo27";
	rename -uid "11E09ADF-47B8-1B20-E5B7-5EA1CA86AAD3";
createNode nodeGraphEditorInfo -n "hyperShadePrimaryNodeEditorSavedTabsInfo";
	rename -uid "D09409BF-4522-6573-1B1D-6CBD35358732";
	setAttr ".tgi[0].tn" -type "string" "Untitled_1";
	setAttr ".tgi[0].vl" -type "double2" -43.45237922573854 -526.19045528154606 ;
	setAttr ".tgi[0].vh" -type "double2" 605.35711880241217 40.476188867811246 ;
	setAttr -s 8 ".tgi[0].ni";
	setAttr ".tgi[0].ni[0].x" 670;
	setAttr ".tgi[0].ni[0].y" 92.857139587402344;
	setAttr ".tgi[0].ni[0].nvs" 1923;
	setAttr ".tgi[0].ni[1].x" 321.42855834960938;
	setAttr ".tgi[0].ni[1].y" -12.857142448425293;
	setAttr ".tgi[0].ni[1].nvs" 2387;
	setAttr ".tgi[0].ni[2].x" 14.285714149475098;
	setAttr ".tgi[0].ni[2].y" 15.714285850524902;
	setAttr ".tgi[0].ni[2].nvs" 1923;
	setAttr ".tgi[0].ni[3].x" -292.85714721679688;
	setAttr ".tgi[0].ni[3].y" -7.1428570747375488;
	setAttr ".tgi[0].ni[3].nvs" 1923;
	setAttr ".tgi[0].ni[4].x" 25.714284896850586;
	setAttr ".tgi[0].ni[4].y" -88.571426391601562;
	setAttr ".tgi[0].ni[4].nvs" 2067;
	setAttr ".tgi[0].ni[5].x" 31.428571701049805;
	setAttr ".tgi[0].ni[5].y" -160;
	setAttr ".tgi[0].ni[5].nvs" 1923;
	setAttr ".tgi[0].ni[6].x" 31.428571701049805;
	setAttr ".tgi[0].ni[6].y" -157.14285278320312;
	setAttr ".tgi[0].ni[6].nvs" 1923;
	setAttr ".tgi[0].ni[7].x" 670;
	setAttr ".tgi[0].ni[7].y" -82.857139587402344;
	setAttr ".tgi[0].ni[7].nvs" 1923;
createNode polyCylProj -n "polyCylProj1";
	rename -uid "03278DC4-45F9-6549-AC2F-ED91A90174C0";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[0:3099]";
	setAttr ".ix" -type "matrix" 0.059999999999999998 0 0 0 0 0.23364535125876285 0 0
		 0 0 0.059999999999999998 0 -0.011928891753115789 0.79008754004604764 8.8605787842974113 1;
	setAttr ".ws" yes;
	setAttr ".pc" -type "double3" -0.033666167408227921 0.79761940240859985 8.9142656326293945 ;
	setAttr ".ps" -type "double2" 180 0.53692662715911865 ;
	setAttr ".r" 0.22791481018066406;
createNode MaterialXSurfaceShader -n "Standard_Surface22";
	rename -uid "7598B395-4933-A55F-CFD8-C7B21CC3F7B2";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document22%Standard_Surface1";
createNode shadingEngine -n "Standard_Surface22SG";
	rename -uid "68A0A314-43E2-B790-A57A-FE89B1A46F78";
	setAttr ".ihi" 0;
	setAttr -s 2 ".dsm";
	setAttr ".ro" yes;
	setAttr -s 2 ".gn";
createNode materialInfo -n "materialInfo28";
	rename -uid "76210717-4B40-B372-3804-D4A13193FFCD";
createNode rampShader -n "rampShader2";
	rename -uid "F9A59841-4708-2D0F-4E3A-A58D3009CA21";
	setAttr -s 2 ".clr";
	setAttr ".clr[0].clrp" 0;
	setAttr ".clr[0].clrc" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".clr[0].clri" 1;
	setAttr ".clr[1].clrp" 0.40000000596046448;
	setAttr ".clr[1].clrc" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".clr[1].clri" 1;
	setAttr ".it[0].itp" 0;
	setAttr ".it[0].itc" -type "float3" 0 0 0 ;
	setAttr ".it[0].iti" 1;
	setAttr ".ic[0].icp" 0;
	setAttr ".ic[0].icc" -type "float3" 0 0 0 ;
	setAttr ".ic[0].ici" 1;
	setAttr -s 2 ".sro[0:1]"  0 1 2 0.5 0.5 2;
	setAttr ".sc[0].scp" 0;
	setAttr ".sc[0].scc" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".sc[0].sci" 1;
	setAttr ".rfl[0]"  0 1 1;
	setAttr ".env[0].envp" 0;
	setAttr ".env[0].envc" -type "float3" 0 0 0 ;
	setAttr ".env[0].envi" 1;
createNode shadingEngine -n "rampShader2SG";
	rename -uid "61E4FC27-4383-B75E-6ADC-00946B68E192";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo29";
	rename -uid "F8A80AF3-4C23-AEFF-938C-08AC1A5C8C45";
createNode groupId -n "groupId6";
	rename -uid "6FEB4305-40E1-91FC-A21C-FEBD68669404";
	setAttr ".ihi" 0;
createNode groupParts -n "groupParts3";
	rename -uid "7E0873C7-4B06-C72F-0D24-17B142A89C7E";
	setAttr ".ihi" 0;
	setAttr ".ic" -type "componentList" 25 "f[0:199]" "f[203:216]" "f[297]" "f[329:345]" "f[365:391]" "f[400:519]" "f[540:619]" "f[626:634]" "f[660:1019]" "f[1028]" "f[1030:1054]" "f[1074:1090]" "f[1122]" "f[1180:1419]" "f[1440]" "f[1442]" "f[1444]" "f[1460:1479]" "f[1500:2739]" "f[2788:2790]" "f[2800:2805]" "f[2812:2817]" "f[2824:2832]" "f[2836:2937]" "f[2944:2949]";
	setAttr ".irc" -type "componentList" 25 "f[200:202]" "f[217:296]" "f[298:328]" "f[346:364]" "f[392:399]" "f[520:539]" "f[620:625]" "f[635:659]" "f[1020:1027]" "f[1029]" "f[1055:1073]" "f[1091:1121]" "f[1123:1179]" "f[1420:1439]" "f[1441]" "f[1443]" "f[1445:1459]" "f[1480:1499]" "f[2740:2787]" "f[2791:2799]" "f[2806:2811]" "f[2818:2823]" "f[2833:2835]" "f[2938:2943]" "f[2950:3099]";
createNode groupId -n "groupId7";
	rename -uid "3062CF29-41C8-B66B-DFBE-4C843510709F";
	setAttr ".ihi" 0;
createNode groupId -n "groupId8";
	rename -uid "8952CB3A-459C-CD07-BD3B-55B3D76B8F37";
	setAttr ".ihi" 0;
createNode groupParts -n "groupParts4";
	rename -uid "AB42ECDC-44AC-B450-D768-4E82E3A6E964";
	setAttr ".ihi" 0;
	setAttr ".ic" -type "componentList" 27 "f[200:202]" "f[217:219]" "f[240:296]" "f[298:328]" "f[346:364]" "f[392:399]" "f[620:625]" "f[635:639]" "f[1020:1027]" "f[1029]" "f[1055:1073]" "f[1091:1121]" "f[1123:1179]" "f[1420:1439]" "f[1441]" "f[1443]" "f[1445:1459]" "f[1480:1499]" "f[2740:2787]" "f[2791:2799]" "f[2806:2811]" "f[2818:2823]" "f[2833:2835]" "f[2938:2943]" "f[2950:3022]" "f[3024:3038]" "f[3040:3099]";
	setAttr ".irc" -type "componentList" 6 "f[220:228]" "f[232:239]" "f[520:539]" "f[640:659]" "f[3023]" "f[3039]";
createNode rampShader -n "rampShader3";
	rename -uid "42D9E6EC-4834-89DA-C4D7-A1B1E244970C";
	setAttr -s 4 ".clr";
	setAttr ".clr[0].clrp" 0;
	setAttr ".clr[0].clrc" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".clr[0].clri" 1;
	setAttr ".clr[1].clrp" 0.51304346323013306;
	setAttr ".clr[1].clrc" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".clr[1].clri" 1;
	setAttr ".clr[2].clrp" 0.6608700156211853;
	setAttr ".clr[2].clrc" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".clr[2].clri" 1;
	setAttr ".clr[3].clrp" 0.32173898816108704;
	setAttr ".clr[3].clrc" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".clr[3].clri" 1;
	setAttr -s 5 ".it";
	setAttr ".it[0].itp" 0;
	setAttr ".it[0].itc" -type "float3" 0 0 0 ;
	setAttr ".it[0].iti" 1;
	setAttr ".it[1].itp" 0.77391302585601807;
	setAttr ".it[1].itc" -type "float3" 0 0 0 ;
	setAttr ".it[1].iti" 1;
	setAttr ".it[2].itp" 0.42608696222305298;
	setAttr ".it[2].itc" -type "float3" 0 0 0 ;
	setAttr ".it[2].iti" 1;
	setAttr ".it[3].itp" 0.25217399001121521;
	setAttr ".it[3].itc" -type "float3" 0 0 0 ;
	setAttr ".it[3].iti" 1;
	setAttr ".it[4].itp" 0.53043478727340698;
	setAttr ".it[4].itc" -type "float3" 0 0 0 ;
	setAttr ".it[4].iti" 1;
	setAttr -s 2 ".ic";
	setAttr ".ic[0].icp" 0;
	setAttr ".ic[0].icc" -type "float3" 0 0 0 ;
	setAttr ".ic[0].ici" 1;
	setAttr ".ic[1].icp" 0.46086955070495605;
	setAttr ".ic[1].icc" -type "float3" 0 0 0 ;
	setAttr ".ic[1].ici" 1;
	setAttr -s 2 ".sro[0:1]"  0 1 2 0.5 0.5 2;
	setAttr ".sc[0].scp" 0;
	setAttr ".sc[0].scc" -type "float3" 0.5 0.5 0.5 ;
	setAttr ".sc[0].sci" 1;
	setAttr ".rfl[0]"  0 1 1;
	setAttr ".env[0].envp" 0;
	setAttr ".env[0].envc" -type "float3" 0 0 0 ;
	setAttr ".env[0].envi" 1;
createNode shadingEngine -n "rampShader3SG";
	rename -uid "F23FAEAA-4EC1-5EAD-B42C-4596B51045E7";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo30";
	rename -uid "90EDB251-4DB2-A26B-1160-8F98A1C1376D";
createNode groupId -n "groupId9";
	rename -uid "51B71B76-4AF2-98CC-07E4-EE807766B9F5";
	setAttr ".ihi" 0;
createNode groupParts -n "groupParts5";
	rename -uid "33DDC932-46FB-EB2E-2324-D186C81FA127";
	setAttr ".ihi" 0;
	setAttr ".ic" -type "componentList" 5 "f[220:239]" "f[520:539]" "f[640:659]" "f[3023]" "f[3039]";
createNode polyAutoProj -n "polyAutoProj1";
	rename -uid "CB43C811-AF4B-F757-FFF0-60987892A717";
	setAttr ".cch" yes;
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[0:1816]";
	setAttr ".ix" -type "matrix" 0.059999999999999998 0 0 0 0 0.23364535125876285 0 0
		 0 0 0.059999999999999998 0 -0.011928891753115789 0.79008754004604764 8.8605787842974113 1;
	setAttr ".s" -type "double3" 0.53692689977493824 0.53692689977493824 0.53692689977493824 ;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".dl" yes;
createNode polyTweak -n "polyTweak6";
	rename -uid "8D113C40-9B4E-B911-0C6B-42B5C4EAA605";
	setAttr ".uopa" yes;
	setAttr -s 4 ".tk[906:909]" -type "float3"  0.0064107422 -0.0010171494
		 4.2382369e-05 0.0042260461 0.00076972414 0.0056263325 -0.0041476903 -0.00082730566
		 -0.0056263325 -0.0064107422 0.0010171494 0.00017683678;
createNode polyMapDel -n "polyMapDel1";
	rename -uid "98CE8041-1849-6B02-5AAC-A9ACB338FCEA";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[643]";
createNode polyMapDel -n "polyMapDel2";
	rename -uid "39D2B925-E94A-77E7-8BC5-E0BEAB0166E3";
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[1691]";
createNode polyAutoProj -n "polyAutoProj2";
	rename -uid "4532B2EB-C14A-62E8-F85A-EE9C5C62FB66";
	setAttr ".cch" yes;
	setAttr ".uopa" yes;
	setAttr ".ics" -type "componentList" 1 "f[0:1816]";
	setAttr ".ix" -type "matrix" 0.059999999999999998 0 0 0 0 0.23364535125876285 0 0
		 0 0 0.059999999999999998 0 -0.011928891753115789 0.79008754004604764 8.8605787842974113 1;
	setAttr ".s" -type "double3" 0.53692689977493824 0.53692689977493824 0.53692689977493824 ;
	setAttr ".ps" 0.20000000298023224;
	setAttr ".dl" yes;
createNode materialInfo -n "pasted__materialInfo15";
	rename -uid "7A6E3731-A74D-5C20-5200-3F906DED3C45";
createNode shadingEngine -n "pasted__Standard_Surface11SG";
	rename -uid "DE989EB4-DF48-8989-2905-F8A385AEFC0B";
	setAttr ".ihi" 0;
	setAttr ".ro" yes;
createNode MaterialXSurfaceShader -n "pasted__Standard_Surface11";
	rename -uid "9E23F15B-BF43-7F92-6C54-A1BE3F469752";
	setAttr ".up" -type "string" "|materialXStack1|materialXStackShape1,%document11%Standard_Surface1";
select -ne :time1;
	setAttr ".o" 1;
	setAttr ".unw" 1;
select -ne :hardwareRenderingGlobals;
	setAttr ".otfna" -type "stringArray" 22 "NURBS Curves" "NURBS Surfaces" "Polygons" "Subdiv Surface" "Particles" "Particle Instance" "Fluids" "Strokes" "Image Planes" "UI" "Lights" "Cameras" "Locators" "Joints" "IK Handles" "Deformers" "Motion Trails" "Components" "Hair Systems" "Follicles" "Misc. UI" "Ornaments"  ;
	setAttr ".otfva" -type "Int32Array" 22 0 1 1 1 1 1
		 1 1 1 0 0 0 0 0 0 0 0 0
		 0 0 0 0 ;
	setAttr ".fprt" yes;
	setAttr ".rtfm" 3;
select -ne :renderPartition;
	setAttr -s 30 ".st";
select -ne :renderGlobalsList1;
select -ne :defaultShaderList1;
	setAttr -s 36 ".s";
select -ne :postProcessList1;
	setAttr -s 2 ".p";
select -ne :defaultRenderUtilityList1;
select -ne :defaultRenderingList1;
select -ne :lightList1;
	setAttr -s 3 ".l";
select -ne :defaultTextureList1;
select -ne :standardSurface1;
	setAttr ".bc" -type "float3" 0.40000001 0.40000001 0.40000001 ;
	setAttr ".sr" 0.5;
select -ne :openPBR_shader1;
	setAttr ".bc" -type "float3" 0.40000001 0.40000001 0.40000001 ;
	setAttr ".sr" 0.5;
select -ne :initialShadingGroup;
	setAttr -s 7 ".dsm";
	setAttr ".ro" yes;
	setAttr -s 6 ".gn";
select -ne :initialParticleSE;
	setAttr ".ro" yes;
select -ne :defaultRenderGlobals;
	addAttr -ci true -h true -sn "dss" -ln "defaultSurfaceShader" -dt "string";
	setAttr ".ren" -type "string" "arnold";
	setAttr ".outf" 51;
	setAttr ".imfkey" -type "string" "tif";
	setAttr ".dss" -type "string" "openPBR_shader1";
select -ne :defaultResolution;
	setAttr ".w" 1920;
	setAttr ".h" 1080;
	setAttr ".pa" 1;
	setAttr ".dar" 1.7769999504089355;
select -ne :defaultLightSet;
	setAttr -s 3 ".dsm";
select -ne :defaultColorMgtGlobals;
	setAttr ".cfe" yes;
	setAttr ".cfp" -type "string" "<MAYA_RESOURCES>/OCIO-configs/Maya2022-default/config.ocio";
	setAttr ".vtn" -type "string" "ACES 1.0 SDR-video (sRGB)";
	setAttr ".vn" -type "string" "ACES 1.0 SDR-video";
	setAttr ".dn" -type "string" "sRGB";
	setAttr ".wsn" -type "string" "ACEScg";
	setAttr ".otn" -type "string" "ACES 1.0 SDR-video (sRGB)";
	setAttr ".potn" -type "string" "ACES 1.0 SDR-video (sRGB)";
select -ne :hardwareRenderGlobals;
	setAttr ".ctrs" 256;
	setAttr ".btrs" 512;
connectAttr "polyBoolean1.out" "polySurfaceShape1.i";
connectAttr "polyBoolean2.out" "polySurfaceShape2.i";
connectAttr "polyBoolean3.out" "polySurfaceShape3.i";
connectAttr "polyBoolean4.out" "polySurfaceShape4.i";
connectAttr "polyBoolean5.out" "polySurfaceShape5.i";
connectAttr "polyBoolean6.out" "polySurfaceShape6.i";
connectAttr "groupId1.id" "pCubeShape1.iog.og[0].gid";
connectAttr ":initialShadingGroup.mwc" "pCubeShape1.iog.og[0].gco";
connectAttr "groupParts1.og" "pCubeShape1.i";
connectAttr "groupId2.id" "pCubeShape1.ciog.cog[0].cgid";
connectAttr "groupId3.id" "pCylinderShape1.iog.og[0].gid";
connectAttr ":initialShadingGroup.mwc" "pCylinderShape1.iog.og[0].gco";
connectAttr "groupParts2.og" "pCylinderShape1.i";
connectAttr "groupId4.id" "pCylinderShape1.ciog.cog[0].cgid";
connectAttr "polySurface7_translateX.o" "polySurface7.tx";
connectAttr "polySurface7_translateY.o" "polySurface7.ty";
connectAttr "polySurface7_translateZ.o" "polySurface7.tz";
connectAttr "polySurface7_visibility.o" "polySurface7.v";
connectAttr "polySurface7_rotateX.o" "polySurface7.rx";
connectAttr "polySurface7_rotateY.o" "polySurface7.ry";
connectAttr "polySurface7_rotateZ.o" "polySurface7.rz";
connectAttr "polySurface7_scaleX.o" "polySurface7.sx";
connectAttr "polySurface7_scaleY.o" "polySurface7.sy";
connectAttr "polySurface7_scaleZ.o" "polySurface7.sz";
connectAttr "deleteComponent2.og" "polySurfaceShape7.i";
connectAttr "groupId1.id" "polySurfaceShape7.iog.og[0].gid";
connectAttr "groupId3.id" "polySurfaceShape7.iog.og[1].gid";
connectAttr "groupId5.id" "polySurfaceShape7.ciog.cog[0].cgid";
connectAttr "polyMirror1.out" "pSphereShape2.i";
connectAttr "polyExtrudeFace5.out" "pCubeShape2.i";
connectAttr "polyBevel2.out" "pCylinderShape2.i";
connectAttr "polySphere1.out" "pSphereShape1.i";
connectAttr "polyBevel4.out" "pCylinderShape4.i";
connectAttr "polyBevel6.out" "pCylinderShape5.i";
connectAttr "polyAutoProj2.out" "pCylinderShape8.i";
connectAttr "groupId6.id" "pCylinderShape8.iog.og[0].gid";
connectAttr "Standard_Surface22SG.mwc" "pCylinderShape8.iog.og[0].gco";
connectAttr "groupId8.id" "pCylinderShape8.iog.og[1].gid";
connectAttr "rampShader2SG.mwc" "pCylinderShape8.iog.og[1].gco";
connectAttr "groupId9.id" "pCylinderShape8.iog.og[2].gid";
connectAttr "rampShader3SG.mwc" "pCylinderShape8.iog.og[2].gco";
connectAttr "groupId7.id" "pCylinderShape8.ciog.cog[0].cgid";
connectAttr "polyCylinder7.out" "pCylinderShape8Orig.i";
connectAttr "polyBevel8.out" "pCylinderShape6.i";
connectAttr "bend1.msg" "bend1Handle.sml";
connectAttr "bend1.cur" "bend1HandleShape.cur";
connectAttr "bend1.lb" "bend1HandleShape.lb";
connectAttr "bend1.hb" "bend1HandleShape.hb";
relationship "link" ":lightLinker1" ":initialShadingGroup.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" ":initialParticleSE.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "aiStandardSurface1SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "aiStandardSurface1SG1.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface22SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "rampShader1SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface1SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface2SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface3SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface4SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface5SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface6SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface7SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface8SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface9SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface10SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface11SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface12SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface13SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface14SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface15SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface16SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface17SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface18SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface19SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface20SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "Standard_Surface21SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "rampShader2SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "rampShader3SG.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "pasted__Standard_Surface11SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" ":initialShadingGroup.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" ":initialParticleSE.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "aiStandardSurface1SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "aiStandardSurface1SG1.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface22SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "rampShader1SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface1SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface2SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface3SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface4SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface5SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface6SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface7SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface8SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface9SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface10SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface11SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface12SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface13SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface14SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface15SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface16SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface17SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface18SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface19SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface20SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "Standard_Surface21SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "rampShader2SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "rampShader3SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "pasted__Standard_Surface11SG.message" ":defaultLightSet.message";
connectAttr "layerManager.dli[0]" "defaultLayer.id";
connectAttr "renderLayerManager.rlmi[0]" "defaultRenderLayer.rlid";
connectAttr "pCubeShape1.o" "polyBoolean7.ip[0]";
connectAttr "pCylinderShape1.o" "polyBoolean7.ip[1]";
connectAttr "pCubeShape1.wm" "polyBoolean7.im[0]";
connectAttr "pCylinderShape1.wm" "polyBoolean7.im[1]";
connectAttr "polyCube1.out" "groupParts1.ig";
connectAttr "groupId1.id" "groupParts1.gi";
connectAttr "polyCylinder1.out" "groupParts2.ig";
connectAttr "groupId3.id" "groupParts2.gi";
connectAttr "polyBoolean7.out" "deleteComponent1.ig";
connectAttr "deleteComponent1.og" "deleteComponent2.ig";
connectAttr ":time1.o" "oceanShader1.ti";
connectAttr "rampShader1.oc" "rampShader1SG.ss";
connectAttr "rampShader1SG.msg" "materialInfo4.sg";
connectAttr "rampShader1.msg" "materialInfo4.m";
connectAttr "rampShader1.msg" "materialInfo4.t" -na;
connectAttr ":defaultArnoldDisplayDriver.msg" ":defaultArnoldRenderOptions.drivers"
		 -na;
connectAttr ":defaultArnoldFilter.msg" ":defaultArnoldRenderOptions.filt";
connectAttr ":defaultArnoldDriver.msg" ":defaultArnoldRenderOptions.drvr";
connectAttr "materialXStackShape1.sk" "Standard_Surface1.sk";
connectAttr "Standard_Surface1.oc" "Standard_Surface1SG.ss";
connectAttr "Standard_Surface1SG.msg" "materialInfo5.sg";
connectAttr "Standard_Surface1.msg" "materialInfo5.m";
connectAttr "Standard_Surface1.msg" "materialInfo5.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface2.sk";
connectAttr "Standard_Surface2.oc" "Standard_Surface2SG.ss";
connectAttr "Standard_Surface2SG.msg" "materialInfo6.sg";
connectAttr "Standard_Surface2.msg" "materialInfo6.m";
connectAttr "Standard_Surface2.msg" "materialInfo6.t" -na;
connectAttr "polyCylinder2.out" "polyBevel1.ip";
connectAttr "pCylinderShape2.wm" "polyBevel1.mp";
connectAttr "polyBevel1.out" "polyBevel2.ip";
connectAttr "pCylinderShape2.wm" "polyBevel2.mp";
connectAttr "polySphere2.out" "polyMirror1.ip";
connectAttr "pSphereShape2.wm" "polyMirror1.mp";
connectAttr "polyTweak2.out" "polyBevel4.ip";
connectAttr "pCylinderShape4.wm" "polyBevel4.mp";
connectAttr "polyCylinder4.out" "polyTweak2.ip";
connectAttr "polyCube2.out" "polySmoothFace1.ip";
connectAttr "polyTweak4.out" "polyExtrudeFace3.ip";
connectAttr "pCubeShape2.wm" "polyExtrudeFace3.mp";
connectAttr "polySmoothFace1.out" "polyTweak4.ip";
connectAttr "polyExtrudeFace3.out" "polyExtrudeFace4.ip";
connectAttr "pCubeShape2.wm" "polyExtrudeFace4.mp";
connectAttr "polyTweak5.out" "polyExtrudeFace5.ip";
connectAttr "pCubeShape2.wm" "polyExtrudeFace5.mp";
connectAttr "polyExtrudeFace4.out" "polyTweak5.ip";
connectAttr "polyCylinder6.out" "polyBevel7.ip";
connectAttr "pCylinderShape6.wm" "polyBevel7.mp";
connectAttr "polyBevel7.out" "polyBevel8.ip";
connectAttr "pCylinderShape6.wm" "polyBevel8.mp";
connectAttr "polyCylinder5.out" "polyExtrudeFace1.ip";
connectAttr "pCylinderShape5.wm" "polyExtrudeFace1.mp";
connectAttr "polyExtrudeFace1.out" "deleteComponent3.ig";
connectAttr "deleteComponent3.og" "deleteComponent4.ig";
connectAttr "deleteComponent4.og" "polyBridgeEdge1.ip";
connectAttr "pCylinderShape5.wm" "polyBridgeEdge1.mp";
connectAttr "polyBridgeEdge1.out" "polyExtrudeFace2.ip";
connectAttr "pCylinderShape5.wm" "polyExtrudeFace2.mp";
connectAttr "polyExtrudeFace2.out" "polyTweak3.ip";
connectAttr "polyTweak3.out" "deleteComponent5.ig";
connectAttr "deleteComponent5.og" "polyMirror2.ip";
connectAttr "pCylinderShape5.wm" "polyMirror2.mp";
connectAttr "polyMirror2.out" "polyBevel5.ip";
connectAttr "pCylinderShape5.wm" "polyBevel5.mp";
connectAttr "polyBevel5.out" "polyBevel6.ip";
connectAttr "pCylinderShape5.wm" "polyBevel6.mp";
connectAttr "materialXStackShape1.sk" "Standard_Surface3.sk";
connectAttr "Standard_Surface3.oc" "Standard_Surface3SG.ss";
connectAttr "Standard_Surface3SG.msg" "materialInfo7.sg";
connectAttr "Standard_Surface3.msg" "materialInfo7.m";
connectAttr "Standard_Surface3.msg" "materialInfo7.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface4.sk";
connectAttr "Standard_Surface4.oc" "Standard_Surface4SG.ss";
connectAttr "Standard_Surface4SG.msg" "materialInfo8.sg";
connectAttr "Standard_Surface4.msg" "materialInfo8.m";
connectAttr "Standard_Surface4.msg" "materialInfo8.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface5.sk";
connectAttr "Standard_Surface5.oc" "Standard_Surface5SG.ss";
connectAttr "pCylinderShape4.iog" "Standard_Surface5SG.dsm" -na;
connectAttr "Standard_Surface5SG.msg" "materialInfo9.sg";
connectAttr "Standard_Surface5.msg" "materialInfo9.m";
connectAttr "Standard_Surface5.msg" "materialInfo9.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface6.sk";
connectAttr "Standard_Surface6.oc" "Standard_Surface6SG.ss";
connectAttr "pCylinderShape5.iog" "Standard_Surface6SG.dsm" -na;
connectAttr "Standard_Surface6SG.msg" "materialInfo10.sg";
connectAttr "Standard_Surface6.msg" "materialInfo10.m";
connectAttr "Standard_Surface6.msg" "materialInfo10.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface7.sk";
connectAttr "Standard_Surface7.oc" "Standard_Surface7SG.ss";
connectAttr "pSphereShape1.iog" "Standard_Surface7SG.dsm" -na;
connectAttr "Standard_Surface7SG.msg" "materialInfo11.sg";
connectAttr "Standard_Surface7.msg" "materialInfo11.m";
connectAttr "Standard_Surface7.msg" "materialInfo11.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface8.sk";
connectAttr "Standard_Surface8.oc" "Standard_Surface8SG.ss";
connectAttr "pSphereShape2.iog" "Standard_Surface8SG.dsm" -na;
connectAttr "Standard_Surface8SG.msg" "materialInfo12.sg";
connectAttr "Standard_Surface8.msg" "materialInfo12.m";
connectAttr "Standard_Surface8.msg" "materialInfo12.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface9.sk";
connectAttr "Standard_Surface9.oc" "Standard_Surface9SG.ss";
connectAttr "pCylinderShape2.iog" "Standard_Surface9SG.dsm" -na;
connectAttr "Standard_Surface9SG.msg" "materialInfo13.sg";
connectAttr "Standard_Surface9.msg" "materialInfo13.m";
connectAttr "Standard_Surface9.msg" "materialInfo13.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface10.sk";
connectAttr "Standard_Surface10.oc" "Standard_Surface10SG.ss";
connectAttr "pCubeShape3.iog" "Standard_Surface10SG.dsm" -na;
connectAttr "Standard_Surface10SG.msg" "materialInfo14.sg";
connectAttr "Standard_Surface10.msg" "materialInfo14.m";
connectAttr "Standard_Surface10.msg" "materialInfo14.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface11.sk";
connectAttr "Standard_Surface11.oc" "Standard_Surface11SG.ss";
connectAttr "pCylinderShape7.iog" "Standard_Surface11SG.dsm" -na;
connectAttr "Standard_Surface11SG.msg" "materialInfo15.sg";
connectAttr "Standard_Surface11.msg" "materialInfo15.m";
connectAttr "Standard_Surface11.msg" "materialInfo15.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface12.sk";
connectAttr "Standard_Surface12.oc" "Standard_Surface12SG.ss";
connectAttr "pCubeShape2.iog" "Standard_Surface12SG.dsm" -na;
connectAttr "Standard_Surface12SG.msg" "materialInfo16.sg";
connectAttr "Standard_Surface12.msg" "materialInfo16.m";
connectAttr "Standard_Surface12.msg" "materialInfo16.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface13.sk";
connectAttr "Standard_Surface13.oc" "Standard_Surface13SG.ss";
connectAttr "pCylinderShape6.iog" "Standard_Surface13SG.dsm" -na;
connectAttr "Standard_Surface13SG.msg" "materialInfo17.sg";
connectAttr "Standard_Surface13.msg" "materialInfo17.m";
connectAttr "Standard_Surface13.msg" "materialInfo17.t" -na;
connectAttr "polyAutoProj1.out" "bend1.ip[0].ig";
connectAttr "pCylinderShape8Orig.o" "bend1.orggeom[0]";
connectAttr "bend1HandleShape.dd" "bend1.dd";
connectAttr "bend1Handle.wm" "bend1.ma";
connectAttr "materialXStackShape1.sk" "Standard_Surface14.sk";
connectAttr "Standard_Surface14.oc" "Standard_Surface14SG.ss";
connectAttr "Standard_Surface14SG.msg" "materialInfo18.sg";
connectAttr "Standard_Surface14.msg" "materialInfo18.m";
connectAttr "Standard_Surface14.msg" "materialInfo18.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface15.sk";
connectAttr "Standard_Surface15.oc" "Standard_Surface15SG.ss";
connectAttr "Standard_Surface15SG.msg" "materialInfo19.sg";
connectAttr "Standard_Surface15.msg" "materialInfo19.m";
connectAttr "Standard_Surface15.msg" "materialInfo19.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface16.sk";
connectAttr "Standard_Surface16.oc" "Standard_Surface16SG.ss";
connectAttr "Standard_Surface16SG.msg" "materialInfo20.sg";
connectAttr "Standard_Surface16.msg" "materialInfo20.m";
connectAttr "Standard_Surface16.msg" "materialInfo20.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface17.sk";
connectAttr "Standard_Surface17.oc" "Standard_Surface17SG.ss";
connectAttr "Standard_Surface17SG.msg" "materialInfo21.sg";
connectAttr "Standard_Surface17.msg" "materialInfo21.m";
connectAttr "Standard_Surface17.msg" "materialInfo21.t" -na;
connectAttr "bend1.og[0]" "polyExtrudeFace6.ip";
connectAttr "pCylinderShape8.wm" "polyExtrudeFace6.mp";
connectAttr "polyExtrudeFace6.out" "polyExtrudeFace7.ip";
connectAttr "pCylinderShape8.wm" "polyExtrudeFace7.mp";
connectAttr "polyExtrudeFace7.out" "polyBevel9.ip";
connectAttr "pCylinderShape8.wm" "polyBevel9.mp";
connectAttr "polyBevel9.out" "polyExtrudeFace8.ip";
connectAttr "pCylinderShape8.wm" "polyExtrudeFace8.mp";
connectAttr "polyExtrudeFace8.out" "polyExtrudeFace9.ip";
connectAttr "pCylinderShape8.wm" "polyExtrudeFace9.mp";
connectAttr "polyExtrudeFace9.out" "polySmartExtrude1.ip";
connectAttr "pCylinderShape8.wm" "polySmartExtrude1.mp";
connectAttr "polySmartExtrude1.out" "polyBevel10.ip";
connectAttr "pCylinderShape8.wm" "polyBevel10.mp";
connectAttr "materialXStackShape1.sk" "Standard_Surface18.sk";
connectAttr "Standard_Surface18.oc" "Standard_Surface18SG.ss";
connectAttr "Standard_Surface18SG.msg" "materialInfo22.sg";
connectAttr "Standard_Surface18.msg" "materialInfo22.m";
connectAttr "Standard_Surface18.msg" "materialInfo22.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface19.sk";
connectAttr "Standard_Surface19.oc" "Standard_Surface19SG.ss";
connectAttr "Standard_Surface19SG.msg" "materialInfo23.sg";
connectAttr "Standard_Surface19.msg" "materialInfo23.m";
connectAttr "Standard_Surface19.msg" "materialInfo23.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface20.sk";
connectAttr "Standard_Surface20.oc" "Standard_Surface20SG.ss";
connectAttr "Standard_Surface20SG.msg" "materialInfo24.sg";
connectAttr "Standard_Surface20.msg" "materialInfo24.m";
connectAttr "Standard_Surface20.msg" "materialInfo24.t" -na;
connectAttr "materialXStackShape1.sk" "Standard_Surface21.sk";
connectAttr "Standard_Surface21.oc" "Standard_Surface21SG.ss";
connectAttr "Standard_Surface21SG.msg" "materialInfo25.sg";
connectAttr "Standard_Surface21.msg" "materialInfo25.m";
connectAttr "Standard_Surface21.msg" "materialInfo25.t" -na;
connectAttr "ramp1.oc" "aiStandardSurface1.base_color";
connectAttr "ramp1.oc" "aiStandardSurface1SG.ss";
connectAttr "aiStandardSurface1SG.msg" "materialInfo26.sg";
connectAttr "ramp1.msg" "materialInfo26.m";
connectAttr "ramp1.msg" "materialInfo26.t" -na;
connectAttr "place2dTexture1.o" "ramp1.uv";
connectAttr "place2dTexture1.ofs" "ramp1.fs";
connectAttr "aiStandardSurface1.out" "aiStandardSurface1SG1.ss";
connectAttr "aiStandardSurface1SG1.msg" "materialInfo27.sg";
connectAttr "aiStandardSurface1.msg" "materialInfo27.m";
connectAttr "aiStandardSurface1.msg" "materialInfo27.t" -na;
connectAttr "aiStandardSurface1SG.msg" "hyperShadePrimaryNodeEditorSavedTabsInfo.tgi[0].ni[0].dn"
		;
connectAttr "aiStandardSurface1.msg" "hyperShadePrimaryNodeEditorSavedTabsInfo.tgi[0].ni[1].dn"
		;
connectAttr "ramp1.msg" "hyperShadePrimaryNodeEditorSavedTabsInfo.tgi[0].ni[2].dn"
		;
connectAttr "place2dTexture1.msg" "hyperShadePrimaryNodeEditorSavedTabsInfo.tgi[0].ni[3].dn"
		;
connectAttr "anisotropic1.msg" "hyperShadePrimaryNodeEditorSavedTabsInfo.tgi[0].ni[4].dn"
		;
connectAttr "lambert2.msg" "hyperShadePrimaryNodeEditorSavedTabsInfo.tgi[0].ni[5].dn"
		;
connectAttr "oceanShader1.msg" "hyperShadePrimaryNodeEditorSavedTabsInfo.tgi[0].ni[6].dn"
		;
connectAttr "aiStandardSurface1SG1.msg" "hyperShadePrimaryNodeEditorSavedTabsInfo.tgi[0].ni[7].dn"
		;
connectAttr "pCylinderShape8Orig.w" "polyCylProj1.ip";
connectAttr "pCylinderShape8.wm" "polyCylProj1.mp";
connectAttr "materialXStackShape1.sk" "Standard_Surface22.sk";
connectAttr "Standard_Surface22.oc" "Standard_Surface22SG.ss";
connectAttr "pCylinderShape8.iog.og[0]" "Standard_Surface22SG.dsm" -na;
connectAttr "pCylinderShape8.ciog.cog[0]" "Standard_Surface22SG.dsm" -na;
connectAttr "groupId6.msg" "Standard_Surface22SG.gn" -na;
connectAttr "groupId7.msg" "Standard_Surface22SG.gn" -na;
connectAttr "Standard_Surface22SG.msg" "materialInfo28.sg";
connectAttr "Standard_Surface22.msg" "materialInfo28.m";
connectAttr "Standard_Surface22.msg" "materialInfo28.t" -na;
connectAttr "rampShader2.oc" "rampShader2SG.ss";
connectAttr "groupId8.msg" "rampShader2SG.gn" -na;
connectAttr "pCylinderShape8.iog.og[1]" "rampShader2SG.dsm" -na;
connectAttr "rampShader2SG.msg" "materialInfo29.sg";
connectAttr "rampShader2.msg" "materialInfo29.m";
connectAttr "rampShader2.msg" "materialInfo29.t" -na;
connectAttr "polyBevel10.out" "groupParts3.ig";
connectAttr "groupId6.id" "groupParts3.gi";
connectAttr "groupParts3.og" "groupParts4.ig";
connectAttr "groupId8.id" "groupParts4.gi";
connectAttr "rampShader3.oc" "rampShader3SG.ss";
connectAttr "groupId9.msg" "rampShader3SG.gn" -na;
connectAttr "pCylinderShape8.iog.og[2]" "rampShader3SG.dsm" -na;
connectAttr "rampShader3SG.msg" "materialInfo30.sg";
connectAttr "rampShader3.msg" "materialInfo30.m";
connectAttr "rampShader3.msg" "materialInfo30.t" -na;
connectAttr "groupParts4.og" "groupParts5.ig";
connectAttr "groupId9.id" "groupParts5.gi";
connectAttr "polyCylProj1.out" "polyAutoProj1.ip";
connectAttr "pCylinderShape8.wm" "polyAutoProj1.mp";
connectAttr "groupParts5.og" "polyTweak6.ip";
connectAttr "polyTweak6.out" "polyMapDel1.ip";
connectAttr "polyMapDel1.out" "polyMapDel2.ip";
connectAttr "polyMapDel2.out" "polyAutoProj2.ip";
connectAttr "pCylinderShape8.wm" "polyAutoProj2.mp";
connectAttr "pasted__Standard_Surface11SG.msg" "pasted__materialInfo15.sg";
connectAttr "pasted__Standard_Surface11.msg" "pasted__materialInfo15.m";
connectAttr "pasted__Standard_Surface11.msg" "pasted__materialInfo15.t" -na;
connectAttr "pasted__Standard_Surface11.oc" "pasted__Standard_Surface11SG.ss";
connectAttr "pasted__materialXStackShape1.sk" "pasted__Standard_Surface11.sk";
connectAttr "rampShader1SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface1SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface2SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface3SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface4SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface5SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface6SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface7SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface8SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface9SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface10SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface11SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface12SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface13SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface14SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface15SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface16SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface17SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface18SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface19SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface20SG.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface21SG.pa" ":renderPartition.st" -na;
connectAttr "aiStandardSurface1SG.pa" ":renderPartition.st" -na;
connectAttr "aiStandardSurface1SG1.pa" ":renderPartition.st" -na;
connectAttr "Standard_Surface22SG.pa" ":renderPartition.st" -na;
connectAttr "rampShader2SG.pa" ":renderPartition.st" -na;
connectAttr "rampShader3SG.pa" ":renderPartition.st" -na;
connectAttr "pasted__Standard_Surface11SG.pa" ":renderPartition.st" -na;
connectAttr "oceanShader1.msg" ":defaultShaderList1.s" -na;
connectAttr "lambert2.msg" ":defaultShaderList1.s" -na;
connectAttr "anisotropic1.msg" ":defaultShaderList1.s" -na;
connectAttr "rampShader1.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface1.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface2.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface3.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface4.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface5.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface6.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface7.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface8.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface9.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface10.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface11.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface12.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface13.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface14.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface15.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface16.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface17.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface18.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface19.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface20.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface21.msg" ":defaultShaderList1.s" -na;
connectAttr "aiStandardSurface1.msg" ":defaultShaderList1.s" -na;
connectAttr "Standard_Surface22.msg" ":defaultShaderList1.s" -na;
connectAttr "rampShader2.msg" ":defaultShaderList1.s" -na;
connectAttr "rampShader3.msg" ":defaultShaderList1.s" -na;
connectAttr "pasted__Standard_Surface11.msg" ":defaultShaderList1.s" -na;
connectAttr "place2dTexture1.msg" ":defaultRenderUtilityList1.u" -na;
connectAttr "defaultRenderLayer.msg" ":defaultRenderingList1.r" -na;
connectAttr "directionalLightShape1.ltd" ":lightList1.l" -na;
connectAttr "directionalLightShape2.ltd" ":lightList1.l" -na;
connectAttr "directionalLightShape3.ltd" ":lightList1.l" -na;
connectAttr "ramp1.msg" ":defaultTextureList1.tx" -na;
connectAttr "pCubeShape1.iog.og[0]" ":initialShadingGroup.dsm" -na;
connectAttr "pCubeShape1.ciog.cog[0]" ":initialShadingGroup.dsm" -na;
connectAttr "pCylinderShape1.iog.og[0]" ":initialShadingGroup.dsm" -na;
connectAttr "pCylinderShape1.ciog.cog[0]" ":initialShadingGroup.dsm" -na;
connectAttr "polySurfaceShape7.iog.og[0]" ":initialShadingGroup.dsm" -na;
connectAttr "polySurfaceShape7.iog.og[1]" ":initialShadingGroup.dsm" -na;
connectAttr "polySurfaceShape7.ciog.cog[0]" ":initialShadingGroup.dsm" -na;
connectAttr "groupId1.msg" ":initialShadingGroup.gn" -na;
connectAttr "groupId2.msg" ":initialShadingGroup.gn" -na;
connectAttr "groupId3.msg" ":initialShadingGroup.gn" -na;
connectAttr "groupId4.msg" ":initialShadingGroup.gn" -na;
connectAttr "pasted__groupId3.msg" ":initialShadingGroup.gn" -na;
connectAttr "pasted__groupId10.msg" ":initialShadingGroup.gn" -na;
connectAttr "directionalLight1.iog" ":defaultLightSet.dsm" -na;
connectAttr "directionalLight2.iog" ":defaultLightSet.dsm" -na;
connectAttr "directionalLight3.iog" ":defaultLightSet.dsm" -na;
// End of INFM212MI_Übung1_Möller.Julia_CameraObscura3D.ma
